#include <iostream>
#include <cstring>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/shm.h>

using namespace std;

int main() {
   
    int shmid = shmget(IPC_PRIVATE, 1024, 0666|IPC_CREAT);
    char* shared_memory = (char*) shmat(shmid, NULL, 0);

    cout << "Enter a string to send: ";
    string input;
    getline(cin, input);

    strcpy(shared_memory, input.c_str());

    pid_t pid = fork();
    if (pid == 0) {
        cout << "Received: " << shared_memory << endl;
        shmdt(shared_memory);
    } else {
        wait(NULL);
        shmctl(shmid, IPC_RMID, NULL);
    }

    return 0;
}

