#include <iostream>
#include <fstream>
#include <cstdlib>
#include <unistd.h>
#include <sys/wait.h>

using namespace std;

int main() {
    srand(time(NULL));
    int rnumb = rand() % 90 + 10;
    int sid = 0507;
    int mnumb = rnumb * (sid % 10);
    int n = ((sid / mnumb) % 25) + 15;
    int matrix[n][n];

    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            matrix[i][j] = rand() % 10 + 1;

    ofstream outfile("resmx.txt");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++)
            outfile << matrix[i][j] << " ";
        outfile << endl;
    }
    outfile.close();

    for (int i = 0; i < n; i++) {
        int pid = fork();
        if (pid == 0) {
            ofstream outfile( to_string(i) + ".txt");
            for (int j = 0; j < n; j++) {
                int elsum = 0;
                for (int k = 0; k < n; k++)
                    elsum += matrix[i][k] * matrix[k][j];
                outfile << elsum << " ";
            }
            outfile << endl;
            outfile.close();
            exit(0);
        }
    }

    while (wait(NULL) > 0);
    return 0;
}

