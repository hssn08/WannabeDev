#!/bin/bash

create_user() {
    sudo useradd -m -p $(openssl passwd -1 "12345") -s /bin/bash OS_Assignment_1
    sudo usermod -aG sudo OS_Assignment_1
    echo "User OS_Assignment_1 is created and administrator privileges are assigned."
}

list_apps() {
    dpkg --list
}

install_dropbox() {
    sudo apt-get update
    sudo apt-get -y install nautilus-dropbox
}

set_ip() {
    sudo ifconfig eth0 10.0.0.1 netmask 255.255.255.0
    sudo route add default gw 10.0.0.254
    echo "nameserver 8.8.8.8" | sudo tee /etc/resolv.conf > /dev/null
}


display_help() {
    echo "Usage: ./OS_Assignment_1.sh [OPTIONS]"
    echo "Options:"
    echo "  -uc     create a new user and assign admin privileges"
    echo "  -ld     list all installed applications"
    echo "  -ins    install Dropbox"
    echo "  -ipcon  set IP address, mask, gateway, and DNS"
    echo "  -h      display this help information"
}


echo "21-0507-Hassan"


if [[ $# -eq 0 ]]; then
    display_help
fi


while [[ $# -gt 0 ]]; do
    option="$1"
    case $option in
        -uc)
            create_user
            shift ;;
        -ld)
            list_apps
            shift ;;
        -ins)
            install_dropbox
            shift ;;
        -ipcon)
            set_ip
            shift ;;
        -h)
            display_help
            exit ;;
        *)
            echo "Invalid option: $option"
            display_help
            exit 1 ;;
    esac
done

