#ifndef RushHour_CPP_
#define RushHour_CPP_
#include "util.h"
#include <iostream>
#include <string>
#include <pthread.h>
#include <GL/glut.h>
#include <ctime>
#include <cstdlib>
#include <cmath>
using namespace std;

int n;
float width = 1000, height = 1000;
float xI = 0, yI = 0;
bool gulag = true;
float xI2 = 0, yI2 = 0;
int scoreone, scoretwo = 0;
int thread1pr, thread2pr = 0;
float thingx = 0, thingy = 0;

float m = n;

void SetCanvasSize(int width, int height)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, width, 0, height, -1, 1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

int score;
void drawCar(int x1, int y1, int m)
{
    if (m == 1)
        DrawSquare(x1, y1, (width / n), colors[BLUE]);
    else if (m == 0)
        DrawSquare(x1, y1, (width / n), colors[RED]);
    else
        DrawSquare(x1, y1, (width / n), colors[WHITE]);
    glutPostRedisplay();
}

bool flag = true;

void GameDisplay() /**/
{

    glClearColor(1, 0.5,
                 0.7, 1);
    glClear(GL_COLOR_BUFFER_BIT);

    string s1 = "Scoreone = ";
    s1 = s1 + to_string(scoreone);
    DrawString(230, 970, s1, colors[BLACK]);
    string s2 = "Scoretwo = ";
    s2 = s2 + to_string(scoretwo);
    DrawString(730, 970, s2, colors[BLACK]);

    string s = "Score = ";
    s = s + to_string(score);

    int vdst = width / n;
    int init = 0;
    int threshold = 0;
    threshold = n - n / 2 - n / 4 - n / 16;
    for (int i = 0; i <= n; i++)
    {
        DrawLine(0, init + threshold, width, init + threshold, 5, colors[MISTY_ROSE]);
        init = init + vdst;
    }

    int hdst = height / n;
    init = 0;
    for (int i = 0; i <= n; i++)
    {
        DrawLine(init + threshold, 0, init + threshold, height, n / 5, colors[MISTY_ROSE]);
        init = init + hdst;
    }

    if (gulag == true)
    {
        xI2 += width / n;
        yI2 += width / n;
        thingx += (rand() % n) * width / n;
        thingy += (rand() % n) * width / n;
        gulag = false;
    }

    if (xI > 1000 - width / n)
    {
        xI -= width / n;
    }
    if (yI > 1000 - width / n)
    {
        yI -= width / n;
    }
    if (xI < 0)
    {
        xI += width / n;
    }
    if (yI < 0)
    {
        yI += width / n;
    }

    if (xI2 > 1000 - width / n)
    {
        xI2 -= width / n;
    }
    if (yI2 > 1000 - width / n)
    {
        yI2 -= width / n;
    }
    if (xI2 < 0)
    {
        xI2 += width / n;
    }
    if (yI2 < 0)
    {
        yI2 += width / n;
    }

    drawCar(xI, yI, 1);
    drawCar(xI2, yI2, 0);
    drawCar(thingx, thingy, 3);

    glutSwapBuffers();
}
void *threadFunc(void *arg)
{
    while (true)
    {
        GameDisplay();
    }
    return nullptr;
}

void *ArrowKeysThread(void *arg)
{
    int key = *(int *)arg;

    if (key == GLUT_KEY_LEFT)
    {
        xI2 -= width / n;
    }
    else if (key == GLUT_KEY_RIGHT)
    {
        xI2 += width / n;
    }
    else if (key == GLUT_KEY_UP)
    {
        yI2 += width / n;
    }
    else if (key == GLUT_KEY_DOWN)
    {
        yI2 -= width / n;
    }

    if (xI == xI2 && yI == yI2)
    {
        if (key == GLUT_KEY_LEFT)
        {
            xI2 += width / n;
        }
        else if (key == GLUT_KEY_RIGHT)
        {
            xI2 -= width / n;
        }
        else if (key == GLUT_KEY_UP)
        {
            yI2 -= width / n;
        }
        else if (key == GLUT_KEY_DOWN)
        {
            yI2 += width / n;
        }
        else if (key == 'a')
        {
            xI += width / n;
        }
        else if (key == 'd')
        {
            xI -= width / n;
        }
        else if (key == 'w')
        {
            yI -= width / n;
        }
        else if (key == 's')
        {
            yI += width / n;
        }
    }

    if (xI2 == thingx && yI2 == thingy)
    {
        scoreone += 10;

        cout << "The thread priority of thread 1 is:" << thread1pr << endl;
        cout << "The thread priority of thread 2 is:" << thread2pr << endl;
        cout << "-------------------------------------;" << endl;
        thingx = (rand() % n) * width / n;
        thingy = (rand() % n) * width / n;
    }

    if (key == 27)
    {
        exit(1);
    }

    glutPostRedisplay();
}

void *WASDKeysThread(void *arg)
{
    char key = *(char *)arg;

    if (key == 'a')
    {
        xI -= width / n;
    }
    else if (key == 'd')
    {
        xI += width / n;
    }
    else if (key == 'w')
    {
        yI += width / n;
    }
    else if (key == 's')
    {
        yI -= width / n;
    }

    if (xI == xI2 && yI == yI2)
    {
        if (key == GLUT_KEY_LEFT)
        {
            xI2 += width / n;
        }
        else if (key == GLUT_KEY_RIGHT)
        {
            xI2 -= width / n;
        }
        else if (key == GLUT_KEY_UP)
        {
            yI2 -= width / n;
        }
        else if (key == GLUT_KEY_DOWN)
        {
            yI2 += width / n;
        }
        else if (key == 'a')
        {
            xI += width / n;
        }
        else if (key == 'd')
        {
            xI -= width / n;
        }
        else if (key == 'w')
        {
            yI -= width / n;
        }
        else if (key == 's')
        {
            yI += width / n;
        }
    }

    if (xI == thingx && yI == thingy)
    {
        scoretwo += 10;

        cout << "The thread priority of thread 1 is:" << thread1pr << endl;
        cout << "The thread priority of thread 2 is:" << thread2pr << endl;
        cout << "-------------------------------------;" << endl;
        thingx = (rand() % n) * width / n;
        thingy = (rand() % n) * width / n;
    }

    if (key == 27)
    {
        exit(1);
    }

    glutPostRedisplay();
}
void SetThreadPriority(pthread_t thread, int priority, int threadn)
{
    struct sched_param param;
    int policy;

    pthread_getschedparam(thread, &policy, &param);
    param.sched_priority = priority;
    pthread_setschedparam(thread, policy, &param);

    if (threadn == 1)
    {
        thread1pr = priority + 10;
    }
    else
    {
        thread2pr = priority + 10;
    }
}

void NonPrintableKeys(int key, int x, int y)
{
    pthread_t thread1;
    int *arg = new int(key);

    if (pthread_create(&thread1, NULL, ArrowKeysThread, (void *)arg) != 0)
    {

        fprintf(stderr, "Failed to create thread\n");
        exit(1);
    }

    SetThreadPriority(thread1, scoreone, 1);
}
void NormalKeys(unsigned char key, int x, int y)
{
    pthread_t thread2;
    char *arg = new char(key);

    if (pthread_create(&thread2, NULL, WASDKeysThread, (void *)arg) != 0)
    {

        fprintf(stderr, "Failed to create thread\n");
        exit(1);
    }

    SetThreadPriority(thread2, scoretwo, 2);
}

void Timer(int m)
{

    glutTimerFunc(100, Timer, 0);
}

int main(int argc, char *argv[])
{

    srand(time(NULL));
    int randomNum = rand() % 90 + 10;
    int rollNum = 0507;

    int product = randomNum * (rollNum % 10);
    float quotient = (float)rollNum / (float)randomNum;

    int modResult = (int)quotient % 25;
    if (modResult < 10)
    {
        modResult += 15;
    }

    n = modResult;
    n = 16;
    cout << "The Board size is" << n << "x" << n << endl;
    cout << "-------------------------------------;" << endl;

    InitRandomizer();
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
    glutInitWindowPosition(50, 50);
    glutInitWindowSize(width, height);
    glutCreateWindow("Board Game by Hassan Abbas");
    SetCanvasSize(width, height);

    glutDisplayFunc(GameDisplay);
    glutSpecialFunc(NonPrintableKeys);
    glutKeyboardFunc(NormalKeys);

    glutTimerFunc(1000.0, Timer, 0);
    glutMainLoop();
    return 1;
}

#endif
