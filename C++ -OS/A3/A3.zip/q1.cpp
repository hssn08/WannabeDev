#include <iostream>
#include <pthread.h>

using namespace std;

// Block is a lock based on bakery algorithm that is a data structure for ticket and flag mechanism.
class Block {
public:
    Block(int n) {
        // tickets is for priority and flags is for checking if the ticket is still being assigned
        tickets = new int[n];
        flags = new bool[n];
        for (int i = 0; i < n; i++) {
            tickets[i] = 0;
            flags[i] = false;
        }
        this->threadcount = n;
    }

    // this uses thread id to make it wait till critical section is not free from lower ticker number.
    void lock(int thread_id) {
        // this flag indicates that the ticket number is still being assigned.
        flags[thread_id] = true;

        // Find the maximum ticket number.
        int max_ticket = 0;
        for (int i = 0; i < threadcount; i++) {
            int ticket = tickets[i];
            if (ticket > max_ticket) {
                max_ticket = ticket;
            }
        }

        // ticket number one higher than max.
        tickets[thread_id] = max_ticket + 1;

        // the ticket number is assigned and choosing state is completed.
        flags[thread_id] = false;

        
        for (int i = 0; i < threadcount; i++) {
            while (flags[i]);  //have all other flags completed choosing a ticket number
            while ((tickets[i] != 0) && ((tickets[i] < tickets[thread_id]) || ((tickets[i] == tickets[thread_id]) && (i < thread_id))));
  //               if ticket number |     |if ticket number is greater than  |    |if ticket number is same|     |the other thread has
 //                  is not zero    | and |  any other thread ticket number  | OR |        for the         | and |       a lower
//    (critical section is not free)|     |(which case it will hold this one)|    |   both of the threads  |     |specific assigned thread id

//basically it holds the specific thread if the critical section is not free and the ticket number of this thread is greater and if 
//the critical section is not free and the ticket number is same and the thread id is greater
//it makes the smaller thread ids and ticket numbers do the process first
        }
    }

    // Unlock the critical section 
    void unlock(int thread_id) {
        //making it 0 signifies kay thread nay critical section leave krdia he
        tickets[thread_id] = 0;
    }

private:
    int threadcount;
    int* tickets;
    bool* flags;
};

//basic test set function used to lock critical sections instructions because cout is multithreaded
bool TestAndSet(bool* target) {
    bool result = *target;
    *target = true;
    return result;
}


Block obj(4);
bool testsetlock = false;

// the critical section of the program  is protected by the Block and TestAndSet functions.
void* critical_section(void* arg) {
    int thread_id = *((int*) arg);
    obj.lock(thread_id);
    // test and set is used because cout is not an atomic instruction, while the Bakery lock (block) mechanism makes sure to 
    // lock the whole critical section and give it to the smallest ticket number,
    // the contents of critical section need to be locked by test and set so that
    // cout instruction is not messed up
    while(TestAndSet(&testsetlock));
    cout << "Process " << thread_id + 1 << " is in the critical section." << endl;
    testsetlock = false;
    obj.unlock(thread_id);
    pthread_exit(NULL);
}
int main() {
    pthread_t threads[4]; //this holds the threads
    int thread_ids[4] = {0, 1, 2, 3}; //this holds the specific thread ids assigned
    
        pthread_create(&threads[0], NULL, critical_section, &thread_ids[1]); //make 4 threads and give them thread ids
        pthread_create(&threads[1], NULL, critical_section, &thread_ids[0]);
        pthread_create(&threads[2], NULL, critical_section, &thread_ids[2]);
        pthread_create(&threads[3], NULL, critical_section, &thread_ids[3]);

    for (int i = 0; i < 4; i++) {
        pthread_join(threads[i], NULL);
    } //wait for all 4 of them to complete 
    return 0;
}
