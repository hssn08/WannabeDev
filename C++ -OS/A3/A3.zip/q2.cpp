#include <iostream>
#include <cstdlib>
#include <ctime>
#include <pthread.h>
#include <unistd.h>
using namespace std;
const int MAX_THREADS = 100;
const int maxcar = 4;
const int maxbus = 1;
const int maxbuscar = 2;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;        // this is for exitthebridge function
pthread_mutex_t arrivalmutex = PTHREAD_MUTEX_INITIALIZER; // this is for arrivalonbridge function
int carsonbridge = 0;
int busonbridge = 0;
int waitingcars = 0;
int waitingbus = 0;

char direction;

class Info
{ // this struct is used to pass vehicle attributes to thread function
public:
    char direction;
    int vehicleType;

    Info(char dir, int type)
    {
        direction = dir;
        vehicleType = type;
    }
};
void ExitTheBridge(string vehicleStr, string directionStr)
{
    pthread_mutex_lock(&mutex);
    if (vehicleStr == "car")
    {
        carsonbridge--;
    }
    else
    {
        busonbridge--;
    }

    cout << vehicleStr << " from " << directionStr << " side exits the bridge" << endl;

    // check for waiting cars and space for cars on the bridge, signal one waiting car
    if (waitingcars > 0 && carsonbridge < maxcar && busonbridge == 0)
    {
        pthread_yield();
    }
    // check for waiting buses and space for buses on the bridge, signal one waiting bus
    else if (waitingbus > 0 && busonbridge < maxbus && carsonbridge == 0)
    {
        pthread_yield();
    }
    // check for waiting cars and space for cars on the bridge, and no waiting buses, signal one waiting car
    else if (waitingcars > 0 && waitingbus == 0 && carsonbridge < maxbuscar)
    {
        pthread_yield();
    }

    // yield function gives other threads priority
    pthread_mutex_unlock(&mutex);
    pthread_yield();
}

void ArriveAtBridge(string vehicleStr, string directionStr)
{
    pthread_mutex_lock(&arrivalmutex);
    if (vehicleStr == "car")
    {
        // if there are already four cars on the bridge or there's a bus on the bridge, wait
        while (carsonbridge == maxcar || busonbridge > 0)
        {
            waitingcars++;
            pthread_mutex_unlock(&arrivalmutex);
            sleep(1);
            pthread_mutex_lock(&arrivalmutex);
            waitingcars--;
        }
        carsonbridge++;
    }
    else
    {
        // wait if there are already two buses on the bridge or there are two cars on the bridge, wait
        while (busonbridge == maxbus || carsonbridge == maxbuscar)
        {
            waitingbus++;
            pthread_mutex_unlock(&arrivalmutex);
            sleep(1);
            pthread_mutex_lock(&arrivalmutex);
            waitingbus--;
        }
        busonbridge++;
    }
    cout << vehicleStr << " from " << directionStr << " side enters the bridge." << endl;
    pthread_mutex_unlock(&arrivalmutex);
    pthread_yield();

    // signal the exit of the vehicle from the bridge
    ExitTheBridge(vehicleStr, directionStr);
}

void *spawnvehicle(void *arg)
{
    Info *info = (Info *)arg;
    // i used complex logic here instead of 0 and 1 i convert them into strings
    string directionStr = (info->direction == 'l') ? "left" : (info->direction == 'r') ? "right"
                                                                                       : "invalid";
    string vehicleStr = (info->vehicleType == 0) ? "car" : (info->vehicleType == 1) ? "bus"
                                                                                    : "invalid";

    ArriveAtBridge(vehicleStr, directionStr);
    pthread_exit(NULL);
}

int main()
{
    srand(time(NULL));
    pthread_mutex_init(&mutex, NULL);
    pthread_mutex_init(&arrivalmutex, NULL);
    time_t startTime = time(NULL);
    time_t currentTime = startTime;
    int threadsCreated = 0;
    pthread_t threads[MAX_THREADS];

    while (currentTime - startTime < 60 && threadsCreated < MAX_THREADS)
    {                                                   // loop for one minute or until max threads created
        char direction = (rand() % 2 == 0) ? 'l' : 'r'; // randomly choose direction
        int vehicleType = rand() % 2;                   // randomly choose vehicle type

        Info *info = new Info(direction, vehicleType);

        pthread_create(&threads[threadsCreated], NULL, spawnvehicle, (void *)info);

        threadsCreated++;

        // wait one second before generating next thread

        currentTime = time(NULL);
    }

    for (int i = 0; i < threadsCreated; i++)
    {
        pthread_join(threads[i], NULL);
    }

    pthread_mutex_destroy(&mutex);
    pthread_mutex_destroy(&arrivalmutex);

    return 0;
}
