create database final;
use final
CREATE TABLE Dataset (
   dataset_id INT PRIMARY KEY,
   dataset_name VARCHAR(20),
   dataset_descripton VARCHAR(100),
   dataset_source VARCHAR(50),
   size int
);
CREATE TABLE Researcher (
    researcher_id INT PRIMARY KEY,
    researcher_name VARCHAR(20),
    researcher_email VARCHAR(50),
	researcher_phone VARCHAR(20),
	researcher_area_of_expertise VARCHAR(100),

);

CREATE TABLE Projects (
    project_id INT PRIMARY KEY,
    project_title VARCHAR(30),
    project_description VARCHAR(100),
	start_date date,
	end_date date,
	funding_source  VARCHAR(30),
		dataset_id INT,
	 FOREIGN KEY (dataset_id) REFERENCES Dataset(dataset_id)
);
CREATE TABLE Result (
   project_id int,
   result_id INT PRIMARY KEY,
   result_description VARCHAR(100),
   metrics VARCHAR(100),
   insights VARCHAR(100),
   FOREIGN KEY (project_id) REFERENCES Projects(project_id)
);
create table Researcher_Project
(
   project_id int,
   researcher_id int,
   FOREIGN KEY (project_id) REFERENCES Projects(project_id),
   FOREIGN KEY (researcher_id) REFERENCES Researcher(researcher_id)
);

drop table Projects
drop table Dataset
drop table Researcher
drop table Result
drop table Researcher_Project
