
--Query1
select Projects.project_title, Researcher.researcher_name, Dataset.dataset_name
from Dataset
JOIN Projects ON Dataset.dataset_id = Projects.dataset_id
JOIN Researcher_Project r ON r.project_id=Projects.project_id
JOIN Researcher ON Researcher.researcher_id = r.researcher_id
where size>200

--Query2
SELECT Projects.project_title, DATEDIFF(DAY, Projects.start_date, Projects.end_date) AS completion_time
from Projects
ORDER BY completion_time desc

--Query3
select Researcher.researcher_name, count(*) AS no_of_projects, REPLACE(researcher_name,substring(researcher_name,2,len(researcher_name)),'*') as masked_name
from Researcher
JOIN Researcher_Project ON Researcher_Project.researcher_id=Researcher.researcher_id
group by Researcher.researcher_name

--Query4
select Researcher.researcher_name, Researcher.researcher_area_of_expertise,concat('Researcher: ',researcher_name,', Expertise: ',researcher_area_of_expertise)
from Researcher

--Query5
CREATE TRIGGER trg_UpdateEndDate
ON Projects
AFTER INSERT
AS
BEGIN
update project set end_date=GetDate()
END

--Query6
SELECT UPPER(Projects.project_title) AS Project_Title, UPPER(Dataset.dataset_name) AS Dataset_Title
FROM Projects
JOIN Researcher_Project on Projects.project_id = Researcher_Project.project_id 
JOIN Dataset on Dataset.dataset_id = Projects.project_id
where Dataset.dataset_name like '_e%' 
and Dataset.size IS NOT NULL
order by Dataset.dataset_name desc

--Query7
CREATE VIEW viewquery7 AS
Select Researcher.researcher_id, Researcher.researcher_name, Projects.project_id, Projects.project_title, Dataset.dataset_name
from Researcher 
Join Researcher_Project on Researcher.researcher_id= Researcher_Project.researcher_id
join Projects on Projects.project_id= Researcher_Project.project_id
join Dataset on Dataset.dataset_id= Projects.dataset_id

select * from viewquery7


--Query8
select top 1 Result.result_id,Result.result_description, Result.metrics, Result.insights, Dataset.size
from Dataset
JOIN Projects on Projects.dataset_id=Dataset.dataset_id
JOIN Result on Result.project_id=Projects.project_id
order by size desc


--Query9
SELECT Projects.project_id,Projects.project_title, Result.result_description, Result.metrics, Result.insights
FROM  Result
JOIN Projects ON Result.project_id=Projects.project_id
where Result.result_description like '%accuracy%' 
OR Result.metrics  like '%accuracy%' 
OR  Result.insights  like '%accuracy%' 
order by Projects.project_title

--Query10

