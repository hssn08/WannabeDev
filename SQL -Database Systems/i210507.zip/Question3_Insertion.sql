
INSERT INTO Projects (project_id, project_title, project_description, start_date,end_date,funding_source,dataset_id) VALUES
(1, 'Data Analysis','Analyzing customer behaviour patterns','2022-01-01','2022-06-30','ABC Company',1),
(2, 'Machine Learning','Predictive maintenance for machinery','2022-03-15','2022-12-31','XYZ Corporation',2),
(3, 'Natural Language Processing','Sentiment Analysis for social media','2022-06-01','2022-11-30','DEF Organization',3),
(4, 'Image Processing','Object recognition in medical Images','2022-09-10','2022-03-31','GHI Industries',4),
(5, 'Big Data Analytics','Analyzing large scale datasets','2022-12-01','2022-05-31','JKL Solutions',5);

INSERT INTO Researcher(researcher_id, researcher_name, researcher_email, researcher_phone,researcher_area_of_expertise) VALUES
(1, 'Shujaat Hussain','shujaat.hussain@nu.edu.pk','1234567890','Data Mining'),
(2, 'Kifayat Alizai','kifayat.alizai@nu.edu.pk','9876543210','Machine Learning'),
(3, 'Urooj Ghani','urooj.ghani@nu.edu.pk','5555555555','Natural Language Processing'),
(4, 'Amina Siddique','amina.siddique@nu.edu.pk','1111111111','Image Processing'),
(5, 'Hammad Naveed','hammad.naveed@nu.edu.pk','9999999999','Big Data Analytics');

INSERT INTO Dataset(dataset_id, dataset_name, dataset_descripton, dataset_source,size) VALUES
(1, 'Customer Data','Customer Demographic and transactional Data','Internal',250),
(2, 'Sensor Data','Real time sensors for machinery','External',500),
(3, 'Social Media Posts','Textual Data from social media platforms','External',150),
(4, 'Medical Images','Digital Images of medical scans','Internal',350),
(5, 'Web Clickstream Data','User Clickstream data from website logs','Internal',200);

INSERT INTO Result(result_id, result_description, metrics, insights, project_id) VALUES
(1, 'Customer Segmentation','Cluster Analysis, RFM metrics','Identified high-value customer segments',1),
(2, 'Predictive Maintenance Model','Accuracy, precision, recall','Predicted Machinery Failures with high accuracy',2),
(3, 'Sentiment Analysis Scores','Positive,negative,neutral','Identified trends in social media sentiment',3),
(4, 'Object Recognition Accuracy','Intersection over Union (IoU)','Acheived High accuracy in detecting objects',4),
(5, 'Data Visualization Dashboard','Charts,graphs,KPIs','Provided interactive Visualizations for large data',5);

INSERT INTO Researcher_Project(project_id,researcher_id) VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

