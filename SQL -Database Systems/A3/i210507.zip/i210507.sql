use ASSIGNMENT_03


--creating Schema

CREATE TABLE stadiums (
  ID INT PRIMARY KEY,
  NAME VARCHAR(50) NOT NULL,
  CITY VARCHAR(50) NOT NULL,
  COUNTRY VARCHAR(50) NOT NULL,
  CAPACITY INT
);

CREATE TABLE teams (
  id INT PRIMARY KEY,
  team_name VARCHAR(50) NOT NULL,
  country VARCHAR(50) NOT NULL,
  home_stadium_id INT,
  FOREIGN KEY (home_stadium_id) REFERENCES stadiums(id)
);

--attributes
CREATE TABLE players (
  player_id varchar(10) PRIMARY KEY,
  first_name VARCHAR(50) ,
  last_name VARCHAR(50) NOT NULL,
  nationality VARCHAR(50) NOT NULL,
  DOB DATE ,
  team_id INT,
  jersey_no int ,
  position varchar(20),
  height int ,
  weight int,
  foot char,
  FOREIGN KEY (team_id) REFERENCES teams(id)
);

CREATE TABLE managers (
  id INT PRIMARY KEY,
  first_name VARCHAR(50),
  last_name VARCHAR(50) NOT NULL,
  nationality VARCHAR(50) NOT NULL,
  DOB DATE NOT NULL,
  team_id INT,
  FOREIGN KEY (team_id) REFERENCES teams(id)
);

CREATE TABLE matches (
  match_id varchar(10) PRIMARY KEY,
  season VARCHAR(50) NOT NULL,
  date_time varchar(100) NOT NULL,
  home_team_id INT,
  away_team_id INT,
  stadium_id INT,
  home_team_score INT,
  away_team_score INT,
  penalty_shoot_out int,
  attendance INT,
  FOREIGN KEY (home_team_id) REFERENCES teams(id),
  FOREIGN KEY (away_team_id) REFERENCES teams(id),
  FOREIGN KEY (stadium_id) REFERENCES stadiums(id)
);

CREATE TABLE goals (
  goal_id Varchar(10) PRIMARY KEY,
  match_id varchar(10) ,
  PID varchar(10),
  duration INT,
  assist VARCHAR(50),
  goal_desc VARCHAR(255),
  FOREIGN KEY (match_id) REFERENCES matches(match_id),
  FOREIGN KEY (PID) REFERENCES players(player_id)
);

--IMPORTING DATA

SELECT * FROM [dbo].[stadiums ];
INSERT INTO [dbo].[STADIUMS](ID, NAME, CITY, COUNTRY, CAPACITY)
SELECT ID, NAME, CITY, COUNTRY, CAPACITY FROM [dbo].[stadiums ];
SELECT * FROM STADIUMS;

SELECT * FROM [dbo].[teams ];
ALTER TABLE [dbo].[teams ] DROP COLUMN F5, F6, F7, F8, F9, F10
INSERT INTO [dbo].[TEAMS](ID, TEAM_NAME, COUNTRY, HOME_STADIUM_ID)
SELECT ID, TEAM_NAME, COUNTRY, HOME_STADIUM_ID FROM [dbo].[teams ] WHERE ID IS NOT NULL
SELECT * FROM TEAMS

SELECT * FROM [dbo].[players ]
INSERT INTO [dbo].[PLAYERS](PLAYER_ID, FIRST_NAME, LAST_NAME, NATIONALITY, DOB, TEAM_ID, JERSEY_No, POSITION, HEIGHT, WEIGHT, FOOT)
SELECT PLAYER_ID, FIRST_NAME, LAST_NAME, NATIONALITY, DOB, TEAM_ID, JERSEY_NUMBER, POSITION, HEIGHT, WEIGHT, FOOT FROM [dbo].[players ]
SELECT * FROM PLAYERS

SELECT * FROM [dbo].[managers ]
INSERT INTO [dbo].[MANAGERS](ID, FIRST_NAME, LAST_NAME, NATIONALITY, DOB, TEAM_ID)
SELECT ID, FIRST_NAME, LAST_NAME, NATIONALITY, DOB, TEAM_ID FROM [dbo].[managers ]
SELECT * FROM MANAGERS

SELECT * FROM [dbo].[matches ]
INSERT INTO [dbo].[MATCHES](MATCH_ID, SEASON, DATE_TIME, HOME_TEAM_ID, AWAY_TEAM_ID, STADIUM_ID, HOME_TEAM_SCORE, AWAY_TEAM_SCORE, PENALTY_SHOOT_OUT, ATTENDANCE)
SELECT MATCH_ID, SEASON, DATE_TIME, HOME_TEAM_ID, AWAY_TEAM_ID, STADIUM_ID, HOME_TEAM_SCORE, AWAY_TEAM_SCORE, PENALTY_SHOOT_OUT, ATTENDANCE FROM [dbo].[matches ]
SELECT * FROM MATCHES

SELECT * FROM [dbo].[goals ]
INSERT INTO [dbo].[GOALS](GOAL_ID, MATCH_ID, PID, DURATION, ASSIST, GOAL_DESC)
SELECT GOAL_ID, MATCH_ID, PID, DURATION, ASSIST, GOAL_DESC FROM [dbo].[goals ]
SELECT * FROM GOALS

--DELETING DATA IMPORT DUMMY TABLES

DROP TABLE [dbo].[goals ]
DROP TABLE [dbo].[managers ]
DROP TABLE [dbo].[matches$]
DROP TABLE [dbo].[players$]
DROP TABLE [dbo].[stadiums$]
DROP TABLE [dbo].[teams$]

--Queries





--SPECIFIC players
--1
SELECT players.PLAYER_ID,CONCAT(players.FIRST_NAME, ' ', players.LAST_NAME) AS FULL_NAME,players.jersey_no, m.ID AS Manager_Id
FROM players
JOIN dbo.managers m ON m.TEAM_ID = players .TEAM_ID
where  m.FIRST_NAME = 'Stefano' AND m.last_name = 'Pioli';

--Matches In a Specific Country   
--2
select  m.MATCH_ID,s.COUNTRY ,s.NAME
from dbo.stadiums  s 
join dbo.matches  m on m.STADIUM_ID = s.ID
where s.country =  'Spain'
order by MATCH_ID;

--NAMES OF TEAMS WON 3 Matches In home ground
--3
SELECT t.ID,t.TEAM_NAME,t.COUNTRY
from dbo.teams  t 
JOIN dbo.matches  m ON t.id = m.HOME_TEAM_ID
join dbo.stadiums  s on s.ID = m.STADIUM_ID
WHERE m.HOME_TEAM_SCORE> m.AWAY_TEAM_SCORE
GROUP BY t.TEAM_NAME,t.ID,t.COUNTRY
HAVING COUNT(*) > 3;

--ALL teams Having foreign Manager
--4
SELECT t.TEAM_NAME, CONCAT(m.FIRST_NAME, ' ', m.LAST_NAME) AS MANAGER_NAME, m.ID AS Manager_Id,m.NATIONALITY,t.COUNTRY
from dbo.managers  m
join dbo.teams  t on t.ID = m.TEAM_ID
where m.NATIONALITY <> t.COUNTRY

--Matches held in Stadium With capacity Greater Than 60000
--5
select m.MATCH_ID ,s.NAME as Stadium_Name,s.CAPACITY,m.HOME_TEAM_ID,m.AWAY_TEAM_ID
from matches  m
join stadiums  s on s.ID=m.STADIUM_ID
where s.CAPACITY > 60000;

---------------------------------------------------------------------------------------
--Goals made without Assist in 2020 haing height greater than 180
--6

select p.PLAYER_ID, CONCAT(p.FIRST_NAME, ' ', p.LAST_NAME) AS FULL_NAME,p.HEIGHT,m.MATCH_ID,p.TEAM_ID,g.ASSIST
FROM dbo.goals  g
JOIN dbo.players  p ON g.PID = p.PLAYER_ID
join dbo.matches  m on m.MATCH_ID = g.MATCH_ID
WHERE g.ASSIST IS NULL
AND m.DATE_TIME like  '%-20 %'
AND p.height > 180
order by p.HEIGHT;

--Russian teams with win percentage less than 50%
--7
SELECT t.ID,t.TEAM_NAME,count(*) as no_of_wins,t.COUNTRY
FROM dbo.teams  t
JOIN dbo.matches  m ON t.ID = m.HOME_TEAM_ID
where t.COUNTRY = 'Russia' 
GROUP BY t.TEAM_NAME,t.COUNTRY,t.ID
HAVING  SUM(CASE WHEN m.HOME_TEAM_SCORE > m.AWAY_TEAM_SCORE THEN 1 ELSE 0 END)/COUNT(*) < 0.5

--Stadiums that have hosted more than 6 matches with host team having a win percentage less than 50%.
--8
SELECT s.ID,s.NAME,m.HOME_TEAM_ID
FROM dbo.matches  m
join stadiums  s on s.ID = m.STADIUM_ID
JOIN dbo.teams  t ON m.HOME_TEAM_ID = t.ID
WHERE t.COUNTRY = s.COUNTRY
GROUP BY s.NAME,s.ID,m.HOME_TEAM_ID
HAVING COUNT(*) > 6 AND SUM(CASE WHEN m.HOME_TEAM_SCORE > m.AWAY_TEAM_SCORE THEN 1 ELSE 0 END)  / COUNT(*) < 0.5

--season with the greatest number of left-foot goals.
--9
select top 1 matches .SEASON,count(goals .GOAL_DESC) as goals
from matches 
join goals  on matches .MATCH_ID = goals .MATCH_ID
where goals .GOAL_DESC = 'left-footed shot'
group by matches .SEASON
order by count(goals .GOAL_DESC) desc;

--country with maximum number of players with at least one goal.
--10
SELECT top 1 p.NATIONALITY,COUNT(DISTINCT g.PID) AS total_players_with_goals
FROM dbo.players  p
JOIN dbo.goals  g ON p.PLAYER_ID = g.PID
GROUP BY p.Nationality
ORDER BY total_players_with_goals DESC;

---------------------------------------------------------------------------------------
--11
SELECT s.NAME AS stadium_name,s.CITY,s.COUNTRY,SUM(CASE WHEN g.GOAL_DESC = 'left-footed shot' THEN 1 ELSE 0 END) as left_footed ,
SUM(CASE WHEN g.GOAL_DESC = 'right-footed shot' THEN 1 ELSE 0 END) as Right_footed
FROM matches  m
JOIN goals  g ON m.MATCH_ID = g.match_id
JOIN stadiums  s ON m.STADIUM_ID = s.ID
GROUP BY s.NAME,s.CITY,s.COUNTRY
HAVING SUM(CASE WHEN g.GOAL_DESC = 'left-footed shot' THEN 1 ELSE 0 END) > SUM(CASE WHEN g.GOAL_DESC = 'right-footed shot' THEN 1 ELSE 0 END);


--12
SELECT m.MATCH_ID, s.COUNTRY, CONVERT(date, SUBSTRING(m.DATE_TIME, 1, 10), 111) as Match_date,
SUBSTRING(m.DATE_TIME, 10, 11) as match_time,
s.CAPACITY,s.ID as stadium_id ,s.NAME as Stadium_Nmae
FROM dbo.matches  m
JOIN dbo.stadiums  s ON m.STADIUM_ID = s.ID
WHERE s.COUNTRY = (
    SELECT TOP 1 s2.COUNTRY
    FROM dbo.stadiums  s2
    GROUP BY s2.COUNTRY
    ORDER BY SUM(s2.CAPACITY) DESC
)
ORDER BY CONVERT(date, SUBSTRING(m.DATE_TIME, 1, 10), 111) DESC,SUBSTRING(m.DATE_TIME, 10, 11) DESC;


--13
SELECT DISTINCT
	CASE WHEN GA.PID < GA.ASSIST THEN GA.PID ELSE GA.ASSIST END AS PLAYER_1,
    CASE WHEN GA.PID < GA.ASSIST THEN GA.ASSIST ELSE GA.PID END AS PLAYER_2, COUNT(*) AS GOAL_ASSIST_COUNT
FROM (
    SELECT p1.PID, p1.ASSIST
    FROM goals p1
    WHERE p1.PID IS NOT NULL AND p1.ASSIST IS NOT NULL
    UNION ALL
    SELECT p2.ASSIST, p2.PID
    FROM goals p2
    WHERE p2.PID IS NOT NULL AND p2.ASSIST IS NOT NULL

) AS GA
GROUP BY GA.PID, GA.ASSIST
HAVING COUNT(*) = (
    SELECT MAX(GOAL_ASSIST)
    FROM (
        SELECT COUNT(*) AS GOAL_ASSIST
        FROM (
            SELECT p1.PID, p1.ASSIST
            FROM goals p1
            WHERE p1.PID IS NOT NULL AND p1.ASSIST IS NOT NULL
            UNION ALL
            SELECT p2.ASSIST, p2.PID
            FROM goals p2
            WHERE p2.PID IS NOT NULL AND p2.ASSIST IS NOT NULL
        ) AS GA2
        GROUP BY GA2.PID, GA2.ASSIST
    ) AS SUB
);	

--14
SELECT t.ID,t.TEAM_NAME,t.country,
		SUM(CASE WHEN g.GOAL_DESC = 'header' THEN 1 ELSE 0 END) / (COUNT(*) ) AS header_goal_percentage
	FROM dbo.teams  t
	inner JOIN dbo.players  p ON t.ID = p.TEAM_ID
	JOIN dbo.goals  g ON g.PID = p.PLAYER_ID
	JOIN dbo.matches  m ON m.MATCH_ID = g.MATCH_ID
	WHERE m.DATE_TIME like  '%-20 %'
	GROUP BY t.ID,t.TEAM_NAME,t.country
HAVING SUM(CASE WHEN g.GOAL_DESC = 'header' THEN 1 ELSE 0 END) / (COUNT(*)) =
       (SELECT Max(header_goal_percentage)
        FROM (
            SELECT t.TEAM_NAME, 
                   SUM(CASE WHEN g.GOAL_DESC = 'header' THEN 1 ELSE 0 END) / (COUNT(*)) AS header_goal_percentage
            FROM dbo.teams  t
            JOIN dbo.players  p ON t.ID = p.TEAM_ID
            JOIN dbo.goals  g ON g.PID = p.PLAYER_ID
            JOIN dbo.matches  m ON m.MATCH_ID = g.MATCH_ID
            WHERE m.DATE_TIME like  '%-20 %'
            GROUP BY t.TEAM_NAME
        ) AS header_percentages
       )

--15
select m.ID,concat(m.FIRST_NAME,' ',m.LAST_NAME)  as Full_Name,m.TEAM_ID,t.TEAM_NAME,count(*) as won  
	from dbo.managers  m
	inner join dbo.teams  t on t.ID = m.TEAM_ID
	join dbo.matches  mt on mt.AWAY_TEAM_ID = t.ID or mt.HOME_TEAM_ID = t.ID 
	where (mt.AWAY_TEAM_ID = t.ID And mt.AWAY_TEAM_SCORE > mt.HOME_TEAM_SCORE) 
	OR (mt.HOME_TEAM_ID = t.ID And mt.HOME_TEAM_SCORE > mt.AWAY_TEAM_SCORE)
	group by m.ID,m.TEAM_ID,t.TEAM_NAME,concat(m.FIRST_NAME,' ',m.LAST_NAME)
having count(*) =
	(select max(won)
	from (select m.ID,concat(m.FIRST_NAME,' ',m.LAST_NAME)  as Full_Name,m.TEAM_ID,t.TEAM_NAME,count(*) as won  
	from dbo.managers  m
	inner join dbo.teams  t on t.ID = m.TEAM_ID
	join dbo.matches  mt on mt.AWAY_TEAM_ID = t.ID or mt.HOME_TEAM_ID = t.ID 
	where (mt.AWAY_TEAM_ID = t.ID And mt.AWAY_TEAM_SCORE > mt.HOME_TEAM_SCORE) OR (mt.HOME_TEAM_ID = t.ID And mt.HOME_TEAM_SCORE > mt.AWAY_TEAM_SCORE)
	group by m.ID,m.TEAM_ID,t.TEAM_NAME,concat(m.FIRST_NAME,' ',m.LAST_NAME)
	)as win
)
order by won desc;
	
--bonus

SELECT season, (case when m1.home_team_score > m1.away_team_score then (select t.team_name 
from teams t where t.id = m1.home_team_id)  
else (select t.team_name 
from teams t
where t.id = m1.away_team_id )end) as winner
FROM matches m1
WHERE CONVERT(date, SUBSTRING(m1.DATE_TIME, 1, 10), 111) = (
    SELECT MAX(CONVERT(date, SUBSTRING(m2.DATE_TIME, 1, 10), 111))
    FROM matches m2
    WHERE m2.season = m1.season 
	
);


