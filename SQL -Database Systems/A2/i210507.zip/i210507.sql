create database db_assignment;

use db_assignment

---------------------------------------------------------------------------------------------------
CREATE TABLE PLANE_TYPE (
  Model INT ,
  Capacity INT,
  Weight INT
);

CREATE TABLE HANGAR (
  Number INT PRIMARY KEY,
  Capacity INT,
  Location VARCHAR(255)
);

CREATE TABLE AIRPLANE (
  RegNum INT PRIMARY KEY,
  OF_TYPE INT,
  STORED_IN INT,
  FOREIGN KEY (OF_TYPE) REFERENCES PLANE_TYPE(Model),
  FOREIGN KEY (STORED_IN) REFERENCES HANGAR(Number)
);

CREATE TABLE OWNER (
  Ssn INT PRIMARY KEY,
  Name VARCHAR(255),
  Address VARCHAR(255),
  Phone VARCHAR(255),
  location varchar (255) 
);

CREATE TABLE PERSON (
  Ssn INT PRIMARY KEY,
  Name VARCHAR(255),
  Address VARCHAR(255),
  Phone VARCHAR(255)
);

CREATE TABLE PILOT (
  Lic_num INT PRIMARY KEY,
  Ssn INT Not Null,
  Restr INT Not Null,
  FOREIGN KEY (Ssn) REFERENCES PERSON(Ssn),
  FOREIGN KEY (restr) REFERENCES airplane(regNum)
);

CREATE TABLE EMPLOYEE (
  Ssn INT PRIMARY KEY,
  Salary INT,
  Shift VARCHAR(255),
  FOREIGN KEY (Ssn) REFERENCES PERSON(Ssn)
);

CREATE TABLE OWNSSS (
  RegNum INT,
  Ssn INT,
  Pdate DATE,
  seller_ID int ,
  
  FOREIGN KEY (seller_ID) REFERENCES owner(ssn),
  FOREIGN KEY (RegNum) REFERENCES AIRPLANE(RegNum),
  FOREIGN KEY (Ssn) REFERENCES OWNER(Ssn)
);

CREATE TABLE SERVICE (
  ServiceID INT PRIMARY KEY,
  Date DATE,
  Hours INT,
  Work_code VARCHAR(255)
);

CREATE TABLE MAINTAIN (
  Ssn INT,
  Service INT,
  FOREIGN KEY (Ssn) REFERENCES EMPLOYEE(Ssn),
  FOREIGN KEY (Service) REFERENCES SERVICE(ServiceID)
);

CREATE TABLE PLANE_SERVICE (
  RegNum INT,
  Service INT,
  FOREIGN KEY (RegNum) REFERENCES AIRPLANE(RegNum),
  FOREIGN KEY (Service) REFERENCES SERVICE(ServiceID)
);

CREATE TABLE FLIES (
  Lic_num INT,
  Model INT,
  FOREIGN KEY (Lic_num) REFERENCES PILOT(Lic_num),
  FOREIGN KEY (Model) REFERENCES PLANE_TYPE(Model)
);

CREATE TABLE CORPORATION 
(
  Name VARCHAR(255),
  Address VARCHAR(255),
  Phone VARCHAR(255),
  ssn int not null,
  regNum int not null,
  FOREIGN KEY (ssn) REFERENCES owner(ssn),
  FOREIGN KEY (regNum) REFERENCES airplane(regNum),

);

CREATE TABLE WORKS_ON (
  Ssn INT,
  Model INT,
  FOREIGN KEY (Ssn) REFERENCES EMPLOYEE(Ssn),
  FOREIGN KEY (Model) REFERENCES PLANE_TYPE(Model)
);

------------------------------------------------------------------------------------------------------
-----------------------------------------------------Querry 2-----------------------------------------

INSERT INTO PLANE_TYPE (Model, Capacity, Weight) VALUES
(100, 150, 20000),
(200, 250, 30000),
(300, 350, 40000),
(400, 450, 50000),
(500, 550, 60000),
(600, 650, 70000),
(700, 750, 80000),
(800, 850, 90000),
(900, 950, 100000),
(1000, 1050, 110000),
(1100, 1150, 120000),
(1200, 1250, 130000),
(1300, 1350, 140000),
(1400, 1450, 150000),
(1500, 1550, 160000),
(1600, 1650, 170000),
(1700, 1750, 180000),
(1800, 1850, 190000),
(1900, 1950, 200000),
(2000, 2050, 210000),
(2100, 2100, 220000),
(2200, 2100, 220000),
(2300, 2100, 220000);

INSERT INTO HANGAR (Number, Capacity, Location) VALUES
(1, 10, 'New York'),
(2, 15, 'New York'),
(3, 20, 'Los Angeles'),
(4, 25, 'Los Angeles'),
(5, 30, 'Chicago'),
(6, 35, 'Chicago'),
(7, 40, 'Houston'),
(8, 45, 'Houston'),
(9, 50, 'Miami'),
(10, 55, 'Miami'),
(11, 60, 'San Francisco'),
(12, 65, 'San Francisco'),
(13, 70, 'Dallas'),
(14, 75, 'Dallas'),
(15, 80, 'Seattle'),
(16, 85, 'Seattle'),
(17, 90, 'Atlanta'),
(18, 95, 'Atlanta'),
(19, 100, 'Boston'),
(20, 105, 'Boston');

INSERT INTO AIRPLANE (RegNum, OF_TYPE, STORED_IN) VALUES
(101, 100, 1),
(102, 100, 2),
(103, 100, 3),
(104, 100, 4),
(105, 100, 5),
(106, 100, 6),
(107, 100, 7),
(108, 100, 8),
(109, 100, 9),
(110, 100, 10),
(201, 200, 1),
(202, 200, 2),
(203, 200, 3),
(204, 200, 4),
(205, 200, 5),
(206, 200, 6),
(207, 200, 7),
(208, 200, 8),
(209, 200, 9),
(210, 200, 10),
(211, 2100, 10),
(212 ,2200, 8),
(213 ,2300, 9),
(214,2300,10),
(215,2300,3),
(216,2300,18);

INSERT INTO OWNER (Ssn, Name, Address, Phone, location) VALUES 
(123456789, 'John Doe', '123 Main St, Anytown USA', '555-1234','Atlanta'),
(234567890, 'Jane Smith', '456 Park Ave, Anytown USA', '555-5678','Atlanta'),
(345678901, 'Bob Johnson', '789 Elm St, Anytown USA', '555-9012','Atlanta'),
(456789012, 'Sue Davis', '101 Oak Dr, Anytown USA', '555-3456','New York'),
(567890123, 'Tom Wilson', '1122 Maple Ave, Anytown USA', '555-7890','Seattle'),
(678901234, 'Mary Brown', '333 Cherry Ln, Anytown USA', '555-2345','Miami'),
(789012345, 'Mike Lee', '444 Pine St, Anytown USA', '555-6789','Atlanta'),
(890123456, 'Karen Kim', '555 Cedar Rd, Anytown USA', '555-1234','Houston'),
(901234567, 'David Green', '666 Olive Blvd, Anytown USA', '555-5678','Chicago'),
(012345678, 'Lisa Baker', '777 Walnut St, Anytown USA', '555-9012','Los Angeles'),
(123450987, 'Steve Chen', '888 Elmwood Ave, Anytown USA', '555-3456','Atlanta'),
(234561098, 'Michelle Lee', '999 Birch Rd, Anytown USA', '555-7890','Dallas'),
(345672109, 'Kevin Chang', '111 Pine Ave, Anytown USA', '555-2345','Seattle'),
(456783210, 'Amy Park', '222 Maple St, Anytown USA', '555-6789','Atlanta'),
(567894321, 'Greg Lee', '333 Cedar Ln, Anytown USA', '555-1234','San Francisco'),
(678905432, 'Laura Lee', '444 Pine Ct, Anytown USA', '555-5678','San Francisco'),
(789016543, 'Hannah Kim', '555 Cherry Blvd, Anytown USA', '555-9012','Atlanta'),
(890127654, 'Sean Park', '666 Elm St, Anytown USA', '555-3456','Miami'),
(901238765, 'Jessica Kim', '777 Oak Ln, Anytown USA', '555-7890','Miami'),
(012349876, 'Brian Lee', '888 Maple Rd, Anytown USA', '555-2345','Atlanta'),
(890127651, 'cooperation', '666 Elm St, Anytown USA', '555-3456','Boston'),
(901238768, 'cooperation', '777 Oak Ln, Anytown USA', '555-7890','Atlanta'),
(012349872, 'cooperation', '888 Maple Rd, Anytown USA', '555-2345','Atlanta'),
(890127650, 'cooperation', '666 Elm St, Anytown USA', '555-3456','Boston'),
(901238760, 'cooperation', '777 Oak Ln, Anytown USA', '555-7890','Atlanta'),
(012349870, 'cooperation', '888 Maple Rd, Anytown USA', '555-2345','Atlanta');

INSERT INTO CORPORATION (ssn,Name, Address, Phone,regNum) VALUES
(890127651, 'ABC Airlines', '666 Elm St, Anytown USA', '555-3456',      101),
(901238768, 'Airways Inc', '777 Oak Ln, Anytown USA', '555-7890',       102),
(012349872, 'Aero World', '888 Maple Rd, Anytown USA', '555-2345',      103),
(890127650, 'Jet Setters', '666 Elm St, Anytown USA', '555-3456',       104),
(901238760, 'Mile High Aviation', '777 Oak Ln, Anytown USA', '555-7890',105),
(012349870, 'Wing It Airlines', '888 Maple Rd, Anytown USA', '555-2345',106),
(890127651, 'ABC Airlines', '666 Elm St, Anytown USA', '555-3456',      107),
(901238768, 'Airways Inc', '777 Oak Ln, Anytown USA', '555-7890',       108),
(012349872, 'Aero World', '888 Maple Rd, Anytown USA', '555-2345',      109),
(890127650, 'Jet Setters', '666 Elm St, Anytown USA', '555-3456',       110),
(901238760, 'Mile High Aviation', '777 Oak Ln, Anytown USA', '555-7890',201),
(012349870, 'Wing It Airlines', '888 Maple Rd, Anytown USA', '555-2345',202),
(890127651, 'ABC Airlines', '666 Elm St, Anytown USA', '555-3456',      203),
(901238768, 'Airways Inc', '777 Oak Ln, Anytown USA', '555-7890',       204),
(012349872, 'Aero World', '888 Maple Rd, Anytown USA', '555-2345',      205),
(890127650, 'Jet Setters', '666 Elm St, Anytown USA', '555-3456',       206),
(901238760, 'Mile High Aviation', '777 Oak Ln, Anytown USA', '555-7890',207),
(012349870, 'Wing It Airlines', '888 Maple Rd, Anytown USA', '555-2345',208),
(890127651, 'ABC Airlines', '666 Elm St, Anytown USA', '555-3456',      209),
(901238768, 'Airways Inc', '777 Oak Ln, Anytown USA', '555-7890',       210),
(012349872, 'Aero World', '888 Maple Rd, Anytown USA', '555-2345',      211),
(890127650, 'Jet Setters', '666 Elm St, Anytown USA', '555-3456',       212),
(901238760, 'Mile High Aviation', '777 Oak Ln, Anytown USA', '555-7890',213),
(012349870, 'Wing It Airlines', '888 Maple Rd, Anytown USA', '555-2345',214);
																		
INSERT INTO PERSON (Ssn, Name, Address, Phone) VALUES					
(123456789, 'John Smith', '123 Main St, Anytown USA', '555-1234'),
(234567890, 'Jane Doe', '456 Broad St, Another Town USA', '555-2345'),
(345678901, 'Bob Johnson', '789 1st St, Smalltown USA', '555-3456'),
(456789012, 'Alice Jones', '321 Elm St, Big City USA', '555-4567'),
(567890123, 'David Brown', '987 2nd Ave, Midtown USA', '555-5678'),
(678901234, 'Karen Davis', '654 Pine St, Suburbia USA', '555-6789'),
(789012345, 'Paul Wilson', '432 Oak St, Countryside USA', '555-7890'),
(890123456, 'Sarah Lee', '987 Cedar Rd, Rural USA', '555-8901'),
(901234567, 'Mike Taylor', '1234 Maple St, Anytown USA', '555-9012'),
(111111111, 'Emily Wang', '5678 Peachtree Rd, Big City USA', '555-1111'),
(222222222, 'Juan Hernandez', '3456 Vine St, Another Town USA', '555-2222'),
(333333333, 'Maria Rodriguez', '7890 Market St, Midtown USA', '555-3333'),
(444444444, 'Hiroshi Tanaka', '4567 Main St, Anytown USA', '555-4444'),
(555555555, 'Fatemeh Naderi', '2468 Elm St, Smalltown USA', '555-5555'),
(666666666, 'Ming Li', '1357 Oak St, Countryside USA', '555-6666'),
(777777777, 'Hans Schmidt', '7531 Cedar Rd, Rural USA', '555-7777'),
(888888888, 'Jacques Dubois', '90210 Maple St, Big City USA', '555-8888'),
(999999999, 'Raj Patel', '5555 Pine St, Suburbia USA', '555-9999'),
(101010101, 'Jorge Chavez', '9876 1st St, Midtown USA', '555-1010'),
(202020202, 'Alicia Gonzalez', '5432 2nd Ave, Another Town USA', '555-2020');

INSERT INTO PILOT (Lic_num, ssn, Restr) VALUES
(1234, 123456789, 101),
(123456, 234567890, 102),
(234567, 345678901, 103),
(345678, 234567890, 104),
(456789, 123456789, 101),
(567890, 234567890, 102),
(678901, 789012345, 105),
(789012, 345678901, 103),
(890123, 123456789, 101),
(901234, 234567890, 206),
(123789, 111111111, 110),
(234890, 222222222, 210),
(345901, 333333333, 203),
(456012, 555555555, 205),
(567123, 234567890, 204),
(678234, 456789012, 104),
(789345, 101010101, 201),
(890456, 999999999, 209),
(901567, 222222222, 210),
(123678, 202020202, 207);

INSERT INTO EMPLOYEE (Ssn, Salary, Shift) VALUES
(123456789, 50000, 'Day'),
(234567890, 60000, 'Night'),
(345678901, 55000, 'Day'),
(456789012, 65000, 'Night'),
(567890123, 45000, 'Day'),
(678901234, 55000, 'Night'),
(789012345, 70000, 'Day'),
(890123456, 75000, 'Night'),
(901234567, 80000, 'Day'),
(111111111, 60000, 'Night'),
(222222222, 55000, 'Day'),
(333333333, 65000, 'Night'),
(444444444, 50000, 'Day'),
(555555555, 60000, 'Night'),
(666666666, 55000, 'Day'),
(777777777, 65000, 'Night'),
(888888888, 70000, 'Day'),
(999999999, 75000, 'Night'),
(101010101, 80000, 'Day'),
(202020202, 45000, 'Night');

INSERT INTO OWNSSS (Ssn, RegNum, Pdate,seller_ID)
VALUES 
(123456789, 101, '2022-01-01',901238768),
(123456789, 102, '2022-02-01',901238768),
(123456789, 103, '2022-03-01',901238768),
(234567890, 104, '2022-04-01',901238760),
(234567890, 105, '2022-05-01',901238760),
(234567890, 106, '2022-06-01',901238760),
(345678901, 107, '2022-07-01',null),
(345678901, 108, '2022-08-01',null),
(345678901, 109, '2022-09-01',null),
(456789012, 110, '2022-10-01',890127650),
(456789012, 201, '2022-11-01',890127650),
(456789012, 202, '2022-12-01',890127650),
(567890123, 203, '2023-01-01',890127650),
(567890123, 204, '2023-02-01',012349872),
(567890123, 205, '2023-03-01',012349872),
(678901234, 206, '2023-04-01',012349872),
(678901234, 207, '2023-05-01',012349872),
(678901234, 208, '2023-06-01',NULL),
(789012345, 209, '2023-07-01',NULL),
(789012345, 210, '2023-08-01',NULL),
(890127654, 211, '2023-09-01',NULL),
(901238765, 212, '2023-10-02',NULL),
(012349876, 213 ,'2023-11-01',890127650),
(890127650, 213 ,'2023-03-01',012349876),
(901238760, 213 ,'2022-09-01',012349876);

INSERT INTO SERVICE (ServiceID, Date, Hours, Work_code) VALUES
(1, '2022-01-15', 4, '1001'),
(2, '2022-02-03', 6, '2002'),
(3, '2022-02-20', 2, '1003'),
(4, '2022-03-08', 3, '3001'),
(5, '2022-04-01', 5, '1002'),
(6, '2022-05-02', 7, '4001'),
(7, '2022-06-15', 2, '3002'),
(8, '2022-07-07', 8, '2001'),
(9, '2022-08-12', 4, '1004'),
(10, '2022-09-18', 6, '2003'),
(11, '2022-10-05', 2, '3003'),
(12, '2022-11-22', 3, '1005'),
(13, '2022-12-11', 5, '4002'),
(14, '2023-01-09', 7, '3004'),
(15, '2023-02-20', 2, '2004'),
(16, '2023-03-20', 2, '2005'),
(17, '2023-04-20', 2, '2006'),
(18, '2023-05-20', 2, '2007'),
(19, '2023-06-20', 2, '2008'),
(20, '2023-07-20', 2, '2009');

INSERT INTO MAINTAIN (Ssn, Service) VALUES
(123456789, 1),
(234567890, 2),
(345678901, 3),
(456789012, 4),
(567890123, 5),
(678901234, 6),
(789012345, 7),
(890123456, 8),
(901234567, 9),
(111111111, 10),
(222222222, 11),
(333333333, 12),
(444444444, 13),
(555555555, 14),
(666666666, 15),
(777777777, 16),
(888888888, 17),
(999999999, 18),
(101010101, 19),
(202020202, 20);

INSERT INTO plane_service (RegNum, Service) VALUES
(101, 1),
(101, 3),
(101, 5),
(102, 2),
(102, 4),
(102, 6),
(103, 7),
(103, 9),
(103, 11),
(104, 8),
(104, 10),
(104, 12),
(105, 13),
(105, 15),
(105, 17),
(106, 14),
(106, 16),
(106, 18),
(107, 19),
(107, 20);

INSERT INTO FLIES (Lic_num, Model) VALUES
(1234, 100),
(123456, 100),
(234567, 100),
(345678, 100),
(456789, 200),
(567890, 200),
(678901, 200),
(789012, 200),
(890123, 300),
(901234, 300),
(123789, 300),
(234890, 300),
(345901, 400),
(456012, 400),
(567123, 400),
(678234, 400),
(789345, 500),
(890456, 500),
(901567, 500),
(123678, 500);

INSERT INTO WORKS_ON (Ssn, Model) VALUES 
(123456789, 100),
(234567890, 200),
(345678901, 300),
(456789012, 400),
(567890123, 500),
(678901234, 600),
(789012345, 700),
(890123456, 800),
(901234567, 900),
(111111111, 1000),
(222222222, 1100),
(333333333, 1200),
(444444444, 1300),
(555555555, 1400),
(666666666, 1500),
(777777777, 1600),
(888888888, 1700),
(999999999, 1800),
(101010101, 1900),
(202020202, 2000);

------------------------------------------------------------------------------------------------------
-----------------------------------------------------Querry 3-----------------------------------------

SELECT RegNum
FROM airplane
WHERE RegNum NOT IN (
    SELECT DISTINCT RegNum
    FROM PLANE_SERVICE
)

-----------------------------------------------------Querry 4-----------------------------------------

SELECT CORPORATION.Name, CORPORATION.Address 
FROM CORPORATION 
inner join owner on CORPORATION.ssn = OWNER.Ssn
INNER JOIN OWNSSS  ON OWNER.Ssn = OWNSSS.Ssn
INNER JOIN AIRPLANE ON OWNSSS.RegNum = AIRPLANE.RegNum
INNER JOIN PLANE_TYPE ON AIRPLANE.OF_TYPE = PLANE_TYPE.Model

WHERE PLANE_TYPE.Capacity > 200 ;

-----------------------------------------------------Querry 5-----------------------------------------

SELECT AVG(salary) as avg_night_shift_salary
FROM employee
WHERE shift = 'night';

-----------------------------------------------------Querry 6-----------------------------------------

SELECT top 5 person.Name ,SUM(service.hours) as maintanance_time_worked
FROM  person
    JOIN employee ON person.ssn = employee.ssn
    JOIN maintain ON employee.Ssn = maintain.Ssn
    JOIN service ON maintain.Service = service.ServiceID
GROUP BY 
    person.Name
ORDER BY 
    maintanance_time_worked DESC;

-----------------------------------------------------Querry 7-----------------------------------------

SELECT DISTINCT AIRPLANE.RegNum,AIRPLANE.OF_TYPE
FROM airplane
JOIN PLANE_SERVICE ON AIRPLANE.RegNum = PLANE_SERVICE.RegNum
JOIN SERVICE ON PLANE_SERVICE.Service = Service.ServiceID
WHERE service.Date >= DATEADD(WEEK, -1, GETDATE())

-----------------------------------------------------Querry 8-----------------------------------------

SELECT distinct OWNER.name, OWNER.phone,CORPORATION.Name
FROM OWNER 
left join CORPORATION on CORPORATION.ssn = OWNER.Ssn
JOIN OWNSSS ON OWNSSS.ssn = OWNER.ssn
WHERE OWNSSS.Pdate >= DATEADD(MONTH, -1, GETDATE())

-----------------------------------------------------Querry 9-----------------------------------------

SELECT person.name,COUNT(DISTINCT pilot.Restr) AS airplane_Authorized
FROM person
JOIN pilot ON person.ssn = pilot.Ssn
GROUP BY person.name;

-----------------------------------------------------Querry 10----------------------------------------

SELECT TOP 1 HANGAR.Location, HANGAR.Capacity - COUNT(AIRPLANE.RegNum) AS Available_Hangers
	FROM HANGAR 
	LEFT JOIN AIRPLANE  ON HANGAR.Number = AIRPLANE.STORED_IN
	GROUP BY HANGAR.Location, HANGAR .Capacity
	ORDER BY Available_Hangers DESC;

-----------------------------------------------------Querry 11----------------------------------------

SELECT corporation.Name, COUNT(*) AS total_Airplane_owned_By_corporation
	FROM CORPORATION 
	join OWNER on CORPORATION.ssn=OWNER.Ssn
	GROUP BY corporation.Name
	ORDER BY total_Airplane_owned_By_corporation DESC;

-----------------------------------------------------Querry 12----------------------------------------

SELECT top 1 AIRPLANE.OF_TYPE, AVG(service.hours) as AVG_SERVICE_TIME_H
FROM AIRPLANE
JOIN PLANE_SERVICE ON AIRPLANE.RegNum = PLANE_SERVICE.RegNum
JOIN SERVICE ON PLANE_SERVICE.Service = Service.ServiceID
GROUP BY AIRPLANE.OF_TYPE;

-----------------------------------------------------Querry 13----------------------------------------

SELECT DISTINCT o.Name,a.RegNum
FROM OWNER o
JOIN OWNSSS ow ON o.Ssn = ow.Ssn
JOIN AIRPLANE a ON ow.RegNum = a.RegNum
JOIN PLANE_TYPE pt ON a.OF_TYPE = pt.Model
JOIN PLANE_SERVICE s ON a.RegNum = s.RegNum
JOIN MAINTAIN m ON s.Service = m.Service
JOIN EMPLOYEE e ON m.Ssn = e.Ssn
JOIN WORKS_ON w ON e.Ssn = w.Ssn AND pt.Model != w.Model



-----------------------------------------------------Querry 14----------------------------------------

SELECT DISTINCT OWNER.Name, OWNER.Phone,HANGAR.Location FROM OWNER

	JOIN OWNSSS ON OWNER.Ssn = OWNSSS.Ssn
	JOIN AIRPLANE ON OWNSSS.RegNum = AIRPLANE.RegNum
	JOIN HANGAR ON AIRPLANE.STORED_IN = HANGAR.Number
	WHERE  OWNER.Ssn not in (select ssn from CORPORATION )
	AND OWNER.location = HANGAR.Location;

-----------------------------------------------------Querry 15----------------------------------------

SELECT DISTINCT (person.Name),AIRPLANE.RegNum FROM PERSON

	join EMPLOYEE ON EMPLOYEE.ssn = person.Ssn
	JOIN PILOT ON EMPLOYEE.Ssn = PILOT.Ssn
	JOIN FLIES ON PILOT.Lic_num = FLIES.Lic_num
	JOIN AIRPLANE ON FLIES.Model = AIRPLANE.OF_TYPE
	WHERE AIRPLANE.RegNum IN (SELECT AIRPLANE.RegNum FROM AIRPLANE

	  JOIN PLANE_SERVICE ON AIRPLANE.RegNum = PLANE_SERVICE.RegNum
	  JOIN SERVICE ON PLANE_SERVICE.Service = SERVICE.Serviceid
	  JOIN MAINTAIN ON SERVICE.ServiceID = MAINTAIN.Service
	);

-----------------------------------------------------Querry 16----------------------------------------

SELECT P.Name, SUM(s.Hours) as TotalHours
from PERSON p
join employee e on e.Ssn = P.Ssn
INNER JOIN MAINTAIN m ON e.Ssn = m.Ssn
INNER JOIN SERVICE s ON m.Service = s.ServiceID
INNER JOIN PLANE_SERVICE ps ON ps.Service = s.ServiceID
INNER JOIN AIRPLANE a ON ps.RegNum = a.RegNum
INNER JOIN OWNSSS o ON o.RegNum = a.RegNum
INNER JOIN CORPORATION c ON c.ssn = o.seller_ID AND c.regNum = o.RegNum
GROUP BY p.Name
ORDER BY TotalHours DESC;

-----------------------------------------------------Querry 17----------------------------------------

SELECT DISTINCT airplane.RegNum, airplane.OF_TYPE, OWNER.Name
FROM AIRPLANE
JOIN OWNSSS ON AIRPLANE.RegNum = OWNSSS.RegNum
JOIN OWNER ON OWNSSS.Ssn = OWNER.Ssn					-- For extracting owner's name
WHERE AIRPLANE.RegNum IN 
(
  SELECT RegNum
  FROM OWNSSS
  WHERE Ssn IN (SELECT Ssn FROM OWNER where owner.Ssn not in (select ssn from CORPORATION))
)
AND AIRPLANE.RegNum NOT IN 
(
  SELECT RegNum
  FROM PLANE_SERVICE
  WHERE Service IN (SELECT Ssn FROM EMPLOYEE WHERE Shift�=�'Day')
);

-----------------------------------------------------Querry 18----------------------------------------

SELECT DISTINCT CORPORATION.Name, CORPORATION.Address
from CORPORATION
join OWNER o on o.Ssn = CORPORATION.ssn
JOIN OWNSSS os ON o.Ssn = os.Ssn
JOIN AIRPLANE a ON os.RegNum = a.RegNum
JOIN PLANE_TYPE pt ON pt.Model = a.OF_TYPE
JOIN OWNSSS s ON s.RegNum = a.RegNum
JOIN OWNER o2 ON s.Seller_id = o2.Ssn
JOIN OWNSSS s2 ON s2.Ssn = o2.Ssn
JOIN AIRPLANE a2 ON s2.RegNum = a2.RegNum
JOIN PLANE_TYPE pt2 ON pt2.Model = a2.OF_TYPE
WHERE o.Ssn in (select ssn from CORPORATION) -- exclude the corporation itself
AND s.Pdate >= DATEADD(month, -1, '2021-08-11') -- purchase in the past month
AND o2.Ssn in (select ssn from CORPORATION) -- purchased by the corporation
AND pt.Model = pt2.Model -- same plane type

-----------------------------------------------------Querry 19----------------------------------------

SELECT HANGAR.number, COUNT(*) AS Total_Planes
	FROM HANGAR
	JOIN AIRPLANE A ON HANGAR.Number = A.STORED_IN
	GROUP BY HANGAR.Number
	ORDER BY Total_Planes DESC;

-----------------------------------------------------Querry 20----------------------------------------

SELECT OF_TYPE, COUNT(*) AS TOTAL
	FROM AIRPLANE
	GROUP BY OF_TYPE;

-----------------------------------------------------Querry 21----------------------------------------

SELECT RegNum, COUNT(*) AS TotalServices
FROM PLANE_SERVICE
GROUP BY RegNum

-----------------------------------------------------Querry 22----------------------------------------

SELECT Shift, AVG(Salary) AS AvgSalary
FROM EMPLOYEE
GROUP BY Shift;

-----------------------------------------------------Querry 23----------------------------------------

SELECT OWNER.Ssn, COUNT(DISTINCT OWNSSS.RegNum) AS num_planes
FROM OWNER
JOIN OWNSSS ON Owner.Ssn = OWNSSS.Ssn
GROUP BY Owner.Ssn;

-----------------------------------------------------Querry 24----------------------------------------

SELECT person.Name, COUNT(DISTINCT  flies.Model) AS Num_of_Planes_Authorized
FROM PERSON 
JOIN PILOT  ON person.Ssn = pilot.Ssn
JOIN FLIES  ON pilot.Lic_num = flies.Lic_num
GROUP BY person.Name;

-----------------------------------------------------Querry 25----------------------------------------

--Query to find the average salary of employees working on a particular plane type

SELECT AVG(e.Salary) AS Average_Salary
FROM EMPLOYEE e
JOIN WORKS_ON w ON e.Ssn = w.Ssn
JOIN PLANE_TYPE p ON w.Model = p.Model
WHERE p.Model = 1200;

--Query to find the total number of hours of service performed by each employee

SELECT person.Name, SUM(s.Hours) AS Total_Hours
FROM person
join EMPLOYEE on person.ssn = employee.ssn
JOIN MAINTAIN m ON employee.Ssn = m.Ssn
JOIN SERVICE s ON m.Service = s.ServiceID
GROUP BY person.Name;

--Query to find Most Used Airplane

SELECT top 1 p.Model, COUNT(*) AS Total_Flights
FROM PLANE_TYPE p
JOIN AIRPLANE a ON p.Model = a.OF_TYPE
JOIN PLANE_SERVICE ps ON a.RegNum = ps.RegNum
GROUP BY p.Model
ORDER BY Total_Flights DESC

--This query retrieves the registration number of each airplane in the database, along with the airplane's model and the name of its owner
SELECT PLANE_TYPE.Model,AIRPLANE.RegNum,OWNER.Name ,CORPORATION.Name
FROM AIRPLANE
JOIN PLANE_TYPE ON AIRPLANE.OF_TYPE = PLANE_TYPE.Model
JOIN OWNSSS ON AIRPLANE.RegNum = OWNSSS.RegNum
JOIN OWNER ON OWNSSS.Ssn = OWNER.Ssn
left join CORPORATION on OWNER.Ssn = CORPORATION.ssn;