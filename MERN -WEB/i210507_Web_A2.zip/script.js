// Sample data to simulate card records
let cardRecords = [
    { id: 1, date: '2024-03-20', time: '12:00', title: 'Meeting', description: 'Discuss project status', event: 'Project Meeting', nearestPlace: 'Office', image: 'meeting.jpg' },
    { id: 2, date: '2024-03-21', time: '14:00', title: 'Lunch', description: 'Lunch with client', event: 'Client Meeting', nearestPlace: 'Restaurant', image: 'lunch.jpg' }
];

// Get the form element
var addCardForm = document.getElementById('add-card-form');

// Listen for form submission
addCardForm.addEventListener('submit', function(event) {
    // Prevent default form submission
    event.preventDefault();

    // Get form data
    var date = document.getElementById('date').value;
    var time = document.getElementById('time').value;
    var title = document.getElementById('title').value;
    var description = document.getElementById('description').value;
    var event = document.getElementById('event').value;
    var nearestPlace = document.getElementById('nearest-place').value;
    var image = document.getElementById('image').files[0];

    // Create new card object
    var newCardId = cardRecords.length + 1; // Get a unique ID
    var newCard = {
        id: newCardId,
        date: date,
        time: time,
        title: title,
        description: description,
        event: event,
        nearestPlace: nearestPlace,
        image: URL.createObjectURL(image) // Convert file to URL
    };

    // Add new card to records
    cardRecords.push(newCard);

    // Update UI
    var newCardElement = createCardElement(newCard);
    var cardTableBody = document.getElementById('card-table-body');
    cardTableBody.appendChild(newCardElement);

    // Reset form inputs
    addCardForm.reset();
});

// Function to search and filter cards
document.getElementById('search-card-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission

    // Get search query
    var searchQuery = document.getElementById('search').value.trim();

    // Filter cards based on search query
    var searchResults = [];
    if (searchQuery === '') {
        searchResults = cardRecords; // Show all records if search query is empty
    } else {
        var searchID = parseInt(searchQuery);
        var record = cardRecords.find(record => record.id === searchID);
        if (record) {
            searchResults.push(record); // Show record with matching ID
        }
    }

    // Display search results
    displaySearchResults(searchResults);
});

// Function to display search results
function displaySearchResults(results) {
    var searchResultsContainer = document.getElementById('search-results');
    searchResultsContainer.innerHTML = '';

    if (results.length === 0) {
        searchResultsContainer.innerHTML = '<p class="no-results">No matching records found.</p>';
    } else {
        var table = document.createElement('table');
        var thead = document.createElement('thead');
        var tbody = document.createElement('tbody');

        // Create table header
        var headerRow = document.createElement('tr');
        var headers = ['ID', 'Date', 'Time', 'Title', 'Description', 'Event', 'Nearest Place', 'Image'];
        headers.forEach(function(header) {
            var th = document.createElement('th');
            th.textContent = header;
            headerRow.appendChild(th);
        });
        thead.appendChild(headerRow);
        table.appendChild(thead);

        // Create table body
        results.forEach(function(record) {
            var cardElement = createCardElement(record);
            var tr = document.createElement('tr');
            tr.appendChild(cardElement);
            tbody.appendChild(tr);
        });
        table.appendChild(tbody);

        searchResultsContainer.appendChild(table);
    }
}

// Function to create card element
function createCardElement(record) {
    // Create a new card element
    var cardElement = document.createElement('tr');
    cardElement.classList.add('card');
    cardElement.dataset.id = record.id;

    // Add card details
    cardElement.innerHTML = `
        <td>${record.id}</td>
        <td>${record.date}</td>
        <td>${record.time}</td>
        <td>${record.title}</td>
        <td>${record.description}</td>
        <td>${record.event}</td>
        <td>${record.nearestPlace}</td>
        <td><img src="${record.image}" alt="${record.title}"></td>
    `;

    return cardElement;
}

// Function to handle form submission for deleting specific record
document.getElementById('delete-card-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission

    // Get ID of the record to delete
    var deleteID = parseInt(document.getElementById('delete-id').value);

    // Find index of the record with given ID
    var index = cardRecords.findIndex(record => record.id === deleteID);

    if (index !== -1) {
        // Remove record from array
        cardRecords.splice(index, 1);

        // Remove card element from UI
        var cardElement = document.querySelector(`.card[data-id="${deleteID}"]`);
        if (cardElement) {
            cardElement.remove();
        }
    } else {
        alert('Record not found!');
    }
});

// Function to handle button click for deleting all records
document.getElementById('delete-all-btn').addEventListener('click', function() {
    // Clear cardRecords array
    cardRecords = [];

    // Clear card table body
    var cardTableBody = document.getElementById('card-table-body');
    cardTableBody.innerHTML = '';
});


// Function to handle form submission for updating card information
document.getElementById('update-card-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission

    // Get form values for updating card information (assuming you have input fields with IDs for each field)
    var updateID = parseInt(document.getElementById('update-id').value);
    var updatedDate = document.getElementById('update-date').value;
    var updatedTime = document.getElementById('update-time').value;
    var updatedTitle = document.getElementById('update-title').value;
    var updatedDescription = document.getElementById('update-description').value;
    var updatedEvent = document.getElementById('update-event').value;
    var updatedNearestPlace = document.getElementById('update-nearest-place').value;

    // Find index of the record with given ID
    var index = cardRecords.findIndex(record => record.id === updateID);

    if (index !== -1) {
        // Update record in array
        cardRecords[index] = {
            ...cardRecords[index],
            date: updatedDate,
            time: updatedTime,
            title: updatedTitle,
            description: updatedDescription,
            event: updatedEvent,
            nearestPlace: updatedNearestPlace
        };

        // Update card element in UI
        var updatedCardElement = createCardElement(cardRecords[index]);
        var cardElement = document.querySelector(`.card[data-id="${updateID}"]`);
        if (cardElement) {
            cardElement.replaceWith(updatedCardElement);
        }
    } else {
        alert('Record not found!');
    }
});

// Function to handle theme


// Function to handle theme selection
document.getElementById('theme').addEventListener('change', function() {
    var selectedTheme = this.value;
    applyTheme(selectedTheme);
});

// Function to apply selected theme
function applyTheme(theme) {
    var body = document.body;
    var styles;

    switch (theme) {
        case 'cool':
            styles = {
                backgroundImage: 'url("images/cool.jpeg")'
            };
            break;
        case 'sad':
            styles = {
                backgroundImage: 'url("images/sad.jpeg")'
            };
            break;
        case 'funny':
            styles = {
                backgroundImage: 'url("images/laughing.jpeg")'
            };
            break;
        default:
            styles = {
                backgroundImage: 'url("images/default.jpg")'
            };
    }

    // Apply styles to the body element
    Object.assign(body.style, styles);
}

window.onload = function() {
    var cardTableBody = document.getElementById('card-table-body');

    // Iterate over cardRecords array
    cardRecords.forEach(function(record) {
        // Create a new card element for each record
        var cardElement = createCardElement(record);
        cardTableBody.appendChild(cardElement);
    });

    // Apply default theme
    applyTheme('funny');
};