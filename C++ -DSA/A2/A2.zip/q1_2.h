//Hassan Abbas
//i210507@nu.edu.pk


#pragma once
#include<iostream>
#include<fstream>
using namespace std;

class Node {
public:
	string val;
	Node* next;
	Node(string d) {
		val = d;
		next = NULL;
	}
	Node() {
		val = '\0';
		next = NULL;
	}
};

class Stack {
public:
	Node* top;
	int size;
	int size1 = 1;
	Stack() {
		top = NULL;
		size = 0;
	}
	void push(string  d) {
		Node* n = new Node;
		n->val = d;
		n->next = top;
		top = n;
		size = size + 1;
	}
	void pop() {
		if (!isEmpty()) {
			Node* n = top;
			top = top->next;
			delete n;
			size = size - 1;
		}

	}
	void pop(int size) {
		for (int i = 0;i < size;i++) {
			top = top->next;
		}
		Node* n = top;
		top = top->next;
		delete n;
		size = size - 1;
	}
	void print() {
		
		if (!isEmpty()) {
			if (size1 == 0) {
				cout << "Syntax error";
			}
			else {
				while (top != NULL) {
					if (top->val[0] != '\0') {
						if (top->val == "endl") {
							cout << endl;

						}
						else {

							cout << top->val << " ";
						}
					}
					top = top->next;
				}
			}
		}
		}

	static Stack reverse(Stack& s) {
		Stack extra;
		int n = s.size;

		for (int i = 0; i < n; i++) {
		
			string element = s.top->val;
			
			s.pop();

			extra.push(element);
		}

		s = extra;
		return s;
	}

	bool isEmpty() {
		if (top == NULL) {
			return true;
		}
		else
			return false;
	}
};

//secondary templated stack

template<class T>

class node
{
public:
	T val;
	node<T>* next;

	node(T d)
	{
		val = d;
		next = NULL;
	}
	node()
	{
		val = '\0';
		next = NULL;
	}

};


template<class T>

class stack
{
public:

	node<T>* top;
	int size;

	stack()
	{
		top = NULL;
		size = 0;
	}
	void push(T d)
	{
		size++;
		node<T>* n = new node<T>(d);

		if (empty())
		{
			top = n;
		}
		else
		{
			n->next = top;
			top = n;
		}
	}
	bool empty()
	{
		if (top == NULL)
		{
			return true;
		}
		return false;
	}
	T pop()
	{
		if (!empty())
		{
			node<T>* n = new node<T>;
			T a;

			size--;
			a = top->val;
			n = top->next;
			delete top;
			top = n;
			return a;
		}

	}

	node<T>* top1()
	{
		return top;
	}
	int Size()
	{
		return size;
	}




};


bool IsOperator(char c)
{
	if (c == '+' || c == '-' || c == '*' || c == '/' || c == '^')
		return true;
	return false;
}


bool IsOperand(char c)
{
	if (c >= 'A' && c <= 'Z')
		return true;
	if (c >= 'a' && c <= 'z')
		return true;
	if (c >= '0' && c <= '9')
		return true;
	return false;
}

int precedence(char op)
{
	if (op == '+' || op == '-')
		return 1;
	if (op == '*' || op == '/')
		return 2;
	if (op == '^')
		return 3;
	return 0;
}

bool eqlOrhigher(char op1, char op2)
{
	int p1 = precedence(op1);
	int p2 = precedence(op2);
	if (p1 == p2)
	{
		if (op1 == '^')
			return false;
		return true;
	}
	return  (p1 > p2 ? true : false);
}

string converttopost(string infix)
{
	stack <char> S;
	string postfix = "";
	char ch;

	S.push('(');
	infix += ')';

	for (int i = 0; i < infix.length(); i++)
	{
		ch = infix[i];

		if (ch == ' ')
			continue;
		else if (ch == '(')
			S.push(ch);
		else if (IsOperand(ch))
			postfix += ch;
		else if (IsOperator(ch))
		{
			while (!S.empty() && eqlOrhigher(S.top1()->val, ch))
			{
				postfix += S.top1()->val;
				S.pop();
			}
			S.push(ch);
		}
		else if (ch == ')')
		{
			while (!S.empty() && S.top1()->val != '(')
			{
				postfix += S.top1()->val;
				S.pop();
			}
			S.pop();
		}
	}
	return postfix;
}



string converttopre(string infix)
{
	stack <char> s;
	string prefix;
	reverse(infix.begin(), infix.end());

	for (int i = 0; i < infix.length(); i++) {
		if (infix[i] == '(') {
			infix[i] = ')';
		}
		else if (infix[i] == ')') {
			infix[i] = '(';
		}
	}
	for (int i = 0; i < infix.length(); i++) {
		if ((infix[i] >= 'a' && infix[i] <= 'z') || (infix[i] >= 'A' && infix[i] <= 'Z')) {
			prefix += infix[i];
		}
		else if (infix[i] == '(') {
			s.push(infix[i]);
		}
		else if (infix[i] == ')') {
			while ((s.top1()->val != '(') && (!s.empty())) {
				prefix += s.top1()->val;
				s.pop();
			}

			if (s.top1()->val == '(') {
				s.pop();
			}
		}
		else if (IsOperator(infix[i])) {
			if (s.empty()) {
				s.push(infix[i]);
			}
			else {
				if (precedence(infix[i]) > precedence(s.top1()->val)) {
					s.push(infix[i]);
				}
				else if ((precedence(infix[i]) == precedence(s.top1()->val))
					&& (infix[i] == '^')) {
					while ((precedence(infix[i]) == precedence(s.top1()->val))
						&& (infix[i] == '^')) {
						prefix += s.top1()->val;
						s.pop();
					}
					s.push(infix[i]);
				}
				else if (precedence(infix[i]) == precedence(s.top1()->val)) {
					s.push(infix[i]);
				}
				else {
					while ((!s.empty()) && (precedence(infix[i]) < precedence(s.top1()->val))) {
						prefix += s.top1()->val;
						s.pop();
					}
					s.push(infix[i]);
				}
			}
		}
	}

	while (!s.empty()) {
		prefix += s.top1()->val;
		s.pop();
	}

	reverse(prefix.begin(), prefix.end());
	return prefix;
}


string converttoin(string newarr)
{
	newarr = "abc+*";
	stack<string> st;
	string str = "Invalid Expression . ";
	int x = 0, y = 0;
	for (int i = 0; i < newarr.length(); i++)
	{
		if (newarr[i] == '(')
		{
			x++;
		}

		if (newarr[i] == ')')
		{
			y++;
		}
	}

	if (x == y)
	{

		for (int i = 0; newarr[i] != '\0'; i++)
		{
			if (IsOperand(newarr[i]))
			{
				string op(1, newarr[i]);
				st.push(op);
			}



			else
			{
				string x = st.top1()->val;
				st.pop();
				string y = st.top1()->val;
				st.pop();
				st.push(y + newarr[i] + x);
			}
		}
	
		return st.top1()->val;
	}
	else
		return str;

}



void stackops(Stack& x) {
	bool flag = false;
	Node* temp = x.top;

	while (temp != NULL) {

		if (temp->val == "|paragraph|"|| temp->val == "|head|") {
			flag = false;
			temp->val = '\0';
		}

		if (temp->val == "|\\paragraph|" || temp->val == "|\\head|") {
			temp->val = "endl";
			flag = true;
		}

		if (flag == true) {
			temp->val = '\0';
		}
	
		temp = temp->next;
	}

	if (flag == false) {
		x.size1 = 0;
	}


	Node* tmp = x.top;
	string infix;
	bool flag1 = false;

	while (tmp != NULL) {
		
		if (tmp->val == "|post_exp|") {
			flag1 = true;	
			tmp->val = '\0';
		}
		
		if (tmp->val == "|\\post_exp|"|| tmp->val == "|\\post_exp|.") {
			flag1 = false;
			tmp->val = converttopost(infix);
			infix = '\0';
		}
		if (flag1 == true) {

			infix += tmp->val;
			tmp->val = '\0';
		}
		tmp = tmp->next;
		
	}
	
	if (flag1 == true) {
		x.size1 = 0;
	
	}

	tmp = x.top;
	 infix='\0';
	 flag1 = false;

	while (tmp != NULL) {

		if (tmp->val == "|pre_exp|") {
			flag1 = true;
			tmp->val = '\0';
		}

		if (tmp->val == "|\\pre_exp|" || tmp->val == "|\\pre_exp|.") {
			flag1 = false;
			tmp->val = converttopre(infix);
			infix = '\0';
		}
		if (flag1 == true) {
			
				infix += tmp->val;
			
			tmp->val = '\0';
		}
		tmp = tmp->next;

	}

	if (flag1 == true) {
		x.size1 = 0;

	}

	tmp = x.top;
	infix = '\0';
	flag1 = false;

	while (tmp != NULL) {

		if (tmp->val == "|sol_exp|") {
			
			flag1 = true;
			tmp->val = '\0';
		}

		if (tmp->val == "|\\sol_exp|" || tmp->val == "|\\sol_exp|."|| tmp->val == "+|\\sol_exp|.") {
			
			flag1 = false;
			tmp->val = converttoin(infix);
			infix = '\0';
		}
		if (flag1 == true) {
		
				infix += tmp->val;
			
			tmp->val = '\0';
		}
		tmp = tmp->next;

	}

	if (flag1 == true) {
		x.size1 = 0;
	
	}

	temp = x.top;

	while (temp != NULL) {
		if (temp->val == "|tab||\\tab|") {
			flag = false;
			temp->val = "\t";
		}

		temp = temp->next;
	}

	char* tagarray = new char;
	temp = x.top;
	Node* temp2 = x.top;
	while (temp != NULL) {
		

		if (temp->val[0] == '|') {
			
			char* array = new char[temp->val.length()];


			for (int i = 0;i < temp->val.length();i++) {
				array[i] = '\0';
			}
			int i;
			for (i = 0;i < temp->val.length();i++) {
				array[i] = temp->val[i];
			}
			array[i] = '\0';

			for (int n = 0;n < i;n++) {
				array[n] = array[n + 1];
			}

			char* array1 = new char[temp->val.length() + 2];
			for (int i = 0;i < temp->val.length();i++) {
				array1[i] = '\0';
			}
			array1[0] = '|';
			array1[1]='\\';
			if (array[0] != '\\') {
				for (int n = 0;n < i;n++) {
					array1[n + 2] = array[n];
				}
				
			}
		

			char* array2 = new char[temp->val.length() + 3];
			for (int i = 0;i < temp->val.length();i++) {
				array2[i] = '\0';
			}

			for (int n = 0;n < i+2;n++) {
				array2[n] = array1[n];
			}
			array2[i+1 ] = '.';
			array2[i + 2] = '\0';
		

			Node* temp2 = x.top;
			while (temp2 != NULL) {
				if (array1 == temp2->val|| array2 == temp2->val) {
					temp2->val = '\0';
					temp->val = '\0';
				}

				temp2 = temp2->next;
			}

					
		}
		
		temp = temp->next;
		
	}
	
















	temp = x.top;

	while (temp != NULL) {


		if (temp->val[0] == '|') {
			x.size1 = 0;
		}

		temp = temp->next;
	}



















}



void handlehead(string filename, Stack& x) {
	fstream file;
		file.open(filename);
	string word;
	bool flag = false;

	while (file >> word) {

		if (word == "|\\head|") {
			word = "endl";
			x.push(word);
			word = "|\\head|";
			x.push(word);
			flag = false;
		}

		if (flag == true) {
			x.push(word);
		}

	    if (word == "|head|") {
			x.push(word);
			flag = true;
		}

		
	}
	file.close();
}

void sendstack(string filename, Stack& x) {
	fstream file;
	file.open(filename);
	string word;

	bool flag = false;

	while (file >> word) {
		if (flag == true) {
			x.push(word);
		}

		if (word == "|\\head|") {
			flag = true;
		}

		
		if (word == "|head|") {
			flag = false;
		}
	}
	file.close();
	x.reverse(x);
	stackops(x);
}





