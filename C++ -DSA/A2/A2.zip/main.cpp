#include<iostream>
#include <fstream>
//Hassan Abbas
//i210507@nu.edu.pk



#include"../Assignment2DS/q1_2.h"
using namespace std;


int main() {
	Stack x;
	
	string filename = "test1.txt";

	handlehead(filename, x);
	sendstack(filename, x);
	
	x.print();
	
}