#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int** arr=NULL;
string* carr=NULL;
int vertex = 0;

template <class T>
class QueueNode
{
public:
	T data;
	QueueNode<T>* next;

};

template <class T>
class Queue {

public:

	QueueNode<T>* front;
	QueueNode<T>* rear;


	Queue() {
		front = NULL;
		rear = NULL;
	}




	bool isempty() {
		return front == NULL;
	}

	void enqueue(T d)
	{

		QueueNode<T>* n = new QueueNode<T>;
		n->data = d;
		n->next = NULL;
		if (isempty()) {
			front = n;
			rear = n;
		}

		else {
			rear->next = n;
			rear = n;
		}

	}




	T dequeue() {
		T temp = front->data;

		if (front != NULL) {
			front = front->next;
		}
		return temp;
	}



};

int** ReadFromFile() {

	vertex = 0;
	string str;
	fstream myfile;
	myfile.open("GraphData.csv", ios::in);
	getline(myfile, str);

	for (int i = 0; str[i] != '\0'; i++){
		if (str[i] == ',')
			vertex++;
	}
	
	arr = new int* [vertex];
	for (int i = 0; i < vertex; i++) {
		arr[i] = new int[vertex];
	}
	carr = new string[vertex];
	int i = 0;
	while (!myfile.eof() && i<vertex) {
		getline(myfile, str);
		char ch[15];
		int ind = 0;
		int j = 0;
		for (; str[j]!=','; j++,ind++) {
			ch[ind] = str[ind];	
		}

		ch[ind] = '\0';
		string c(ch);
		carr[i] = c;
		for (int k = 0; k < vertex; k++) {
			ind = 0;
			j++;
			while (1) {
				if (str[j] == ',' || str[j] == '\0')
					break;
				ch[ind] = str[j];
				ind++;
				j++;
			}
			ch[ind] = '\0';
			arr[i][k] = stoi(ch);
		}
		i++;
	}

	myfile.close();
	return arr;
}





class Graph {

public:
	int max = vertex;
	int** adjMatrix = NULL;
	string* cities = NULL;

	Graph* addNode(string node) {
		vertex++;
		max = vertex;
		string* str = new string[vertex];
		int** temp = new int* [vertex];

		for (int i = 0; i < vertex - 1; i++) {

			temp[i] = new int[vertex];
			str[i] = carr[i];
			for (int j = 0; j < vertex - 1; j++) {
				temp[i][j] = arr[i][j];
			}
			temp[i][vertex - 1] = 0;
		}
		temp[vertex - 1] = new int[vertex];
		for (int i = 0; i < vertex; i++) {
			temp[vertex - 1][i] = 0;
		}

		str[vertex - 1] = node;
		arr = temp;
		carr = str;
		adjMatrix = temp;
		cities = carr;
		return this;
	}
	Graph* deleteNode(string node) {
		int ind = -1;
		for (int i = 0; i < vertex; i++) {
			if (node == carr[i]) {
				ind = i;
				break;
			}
		}
		
		if (ind == -1) {
			cout << "****Node Not Found****\n";
			this->max = vertex;
			this->cities = carr;
			this->adjMatrix = arr;
			return this;
		}


		string* c = new string[vertex - 1];
		int** temp = new int* [vertex - 1];
		for (int i = 0,indi=0; i < vertex-1; i++,indi++) {
			temp[i] = new int[vertex - 1];
			if (indi == ind)
				indi++;
			c[i] = carr[indi];
			for (int j = 0, indj = 0; j < vertex - 1; j++,indj++) {
				if (indj == ind)
					indj++;
				temp[i][j] = arr[indi][indj];
			}
		}
		vertex--;
		arr = temp;
		carr = c;
		this->max = vertex;
		this->cities = carr;
		this->adjMatrix = arr;
		return this;
	}

	Graph* addEdge(string src, string dest, int val) {
		max = vertex;
		adjMatrix = arr;
		cities = carr;
		int inds = -1;
		int indd = -1;
		for (int i = 0; i < vertex; i++) {
			if (carr[i] == src)
				inds = i;
			if (carr[i] == dest)
				indd = i;
		}

		if (inds == -1 || indd == -1) {
			cout << "****Node Not Found****\n";
		}

		else {
			adjMatrix[inds][indd] = val;
			arr[inds][indd] = val;
		}

		return this;
	}
	Graph* deleteEdge(string src, string dest) {
		max = vertex;
		adjMatrix = arr;
		cities = carr;
		int inds = -1;
		int indd = -1;
		for (int i = 0; i < vertex; i++) {
			if (carr[i] == src)
				inds = i;
			if (carr[i] == dest)
				indd = i;
		}
		if (inds == -1 || indd == -1) {
			cout << "****Node Not Found****\n";
		}

		else {
			adjMatrix[inds][indd] = 0;
			arr[inds][indd] = 0;
		}
		return this;
	}

	void Path(int i, int j, int** ar) {
		int k = ar[i][j];
		if (k == 0 || k == -1)
			return;
		Path(i, k, ar);
		cout << " -> " << carr[k];
		Path(k, j, ar);
		return;

	}
	string Path1(int i, int j, int** ar) {
		int k = ar[i][j];
		if (k == 0 || k == -1)
			return "";
		string str1 = Path1(i, k, ar);
		str1 += "-> " + carr[k];
		str1 += Path1(k, j, ar);
		return str1;
	}

	void shortestPathfromOnetoall(string dest) {

		int** floyd = new int* [vertex];
		int** path = new int* [vertex];
		for (int i = 0; i < vertex; i++) {
			floyd[i] = new int[vertex];
			path[i] = new int[vertex];
			for (int j = 0; j < vertex; j++) {
				path[i][j] = 0;
				if (i == j)
					floyd[i][j] = 0;
				else if (arr[i][j] == 0){
					floyd[i][j] = INT_MAX;
				}

				else {
					floyd[i][j] = arr[i][j];
				}
			
			}
		}

		for (int k = 0; k < vertex; k++) {
			for (int i = 0; i < vertex; i++) {
				for (int j = 0; j < vertex; j++) {
					
					if ( (floyd[i][j] > floyd[i][k] + floyd[k][j])  && (floyd[i][k]!=INT_MAX)&& (floyd[k][j]!=INT_MAX)) {
						floyd[i][j] = floyd[i][k] + floyd[k][j];
						path[i][j] = k;
					}

				}
			}
		}
		int ind=-1;
		for (int i = 0; i < vertex; i++) {
			if (carr[i] == dest)
				ind = i;
		}

		if (ind == -1) {
			cout << "****Node Not Found\n";
			return;
		}


		for (int i = 0; i < vertex; i++) {
			cout << carr[ind] ;
			if (floyd[ind][i] == INT_MAX)
				cout << "-> *****NO PATH*****";
			else 
				Path(ind, i, path);
			cout << "->" << carr[i] << endl;
		}

	}
	void shortestPathfromalltoone(string dest) {

		int** floyd = new int* [vertex];
		int** path = new int* [vertex];
		for (int i = 0; i < vertex; i++) {
			floyd[i] = new int[vertex];
			path[i] = new int[vertex];
			for (int j = 0; j < vertex; j++) {
				path[i][j] = 0;

				if (i == j)
					floyd[i][j] = 0;
				else if (arr[i][j] == 0) {
					floyd[i][j] = INT_MAX;
				}

				else {
					floyd[i][j] = arr[i][j];
				}

			}
		}


		for (int k = 0; k < vertex; k++) {
			for (int i = 0; i < vertex; i++) {
				for (int j = 0; j < vertex; j++) {
					if (i == j)
						continue;

					if ((floyd[i][j] > floyd[i][k] + floyd[k][j]) && (floyd[i][k] != INT_MAX) && (floyd[k][j] != INT_MAX)) {
						floyd[i][j] = floyd[i][k] + floyd[k][j];
						path[i][j] = k;
					}

				}
			}
		}

		int ind = -1;
		for (int i = 0; i < vertex; i++) {
			if (carr[i] == dest)
				ind = i;
		}

		if (ind == -1) {
			cout << "****Node Not Found\n";
			return;
		}

		for (int i = 0; i < vertex; i++) {
			if (i == ind)
				continue;
			cout << carr[i] ;
			if (floyd[ind][i] == INT_MAX)
				cout << "*****NO PATH*****";
			else {
				Path(i, ind, path);
			}
			cout << "->" << carr[ind] << endl;
		}

	}
	string ShortestRoutefrompair(string src, string dest) {

		int** floyd = new int* [vertex];
		int** path = new int* [vertex];
		for (int i = 0; i < vertex; i++) {
			floyd[i] = new int[vertex];
			path[i] = new int[vertex];
			for (int j = 0; j < vertex; j++) {
				path[i][j] = 0;

				if (i == j)
					floyd[i][j] = 0;
				else if (arr[i][j] == 0) {
					floyd[i][j] = INT_MAX;
				}

				else {
					floyd[i][j] = arr[i][j];
				}

			}
		}

		for (int k = 0; k < vertex; k++) {
			for (int i = 0; i < vertex; i++) {
				for (int j = 0; j < vertex; j++) {
					if (i == j)
						continue;

					if ((floyd[i][j] > floyd[i][k] + floyd[k][j]) && (floyd[i][k] != INT_MAX) && (floyd[k][j] != INT_MAX)) {
						floyd[i][j] = floyd[i][k] + floyd[k][j];
						path[i][j] = k;
					}

				}
			}
		}
		int inds = -1,indd=-1;
		for (int i = 0; i < vertex; i++) {
			if (carr[i] == src)
				inds = i;
			if (carr[i] == dest)
				indd = i;

		}

		if (inds == -1 || indd == -1) {
			return "* ***Node Not Found * ***\n";
		}


		string str= src;
		if (floyd[inds][indd] == INT_MAX)
			return "NO PATH FOUND";
		str += Path1(inds, indd, path) + "-> " + dest;
		return str;
	}

	void secondshortestPathfromOnetoall(string src) {
		int*** floyd = new int** [vertex];
		int*** path = new int** [vertex];


		for (int k = 0; k < vertex; k++) {
			floyd[k] = new int* [vertex];
			path[k] = new int* [vertex];

			for (int i = 0; i < vertex; i++) {
				floyd[k][i] = new int[vertex];
				path[k][i] = new int[vertex];
				for (int j = 0; j < vertex; j++) {
					path[k][i][j] = 0;

					if (i == j)
						floyd[k][i][j] = 0;
					else if (arr[i][j] == 0) {
						floyd[k][i][j] = INT_MAX;
					}

					else {
						floyd[k][i][j] = arr[i][j];
					}

				}
				floyd[k][i][k] = INT_MAX;
				path[k][i][k] = 0;
			}
		}

		for (int a = 0; a < vertex; a++) {
			for (int k = 0; k < vertex; k++) {
				for (int i = 0; i < vertex; i++) {
					for (int j = 0; j < vertex; j++) {
						if (i == j)
							continue;

						if ((floyd[a][i][j] > floyd[a][i][k] + floyd[a][k][j])
							&& (floyd[a][i][k] != INT_MAX)
							&& (floyd[a][k][j] != INT_MAX)) {

							floyd[a][i][j] = floyd[a][i][k] + floyd[a][k][j];
							path[a][i][j] = k;
						}

					}
				}
			}

		}

		int inds = -1;
		for (int i = 0; i < vertex; i++) {
			if (carr[i] == src)
				inds = i;
		}

		if (inds == -1) {
			cout << "****Node Not Found ****\n";
			return;
		}

		
		for (int indd = 0; indd < vertex; indd++) {
			int mink = vertex - 1, seck = vertex - 2;
			for (int i = vertex - 1; i >= 0; i--) {

				if (floyd[i][inds][indd] == INT_MAX)
					continue;
				if (floyd[i][inds][indd] > floyd[seck][inds][indd]) {
					if (floyd[i][inds][indd] < floyd[mink][inds][indd]) {
						seck = mink;
						mink = i;
					}
					else
						seck = i;
				}
			}

			string str = src;

			str = src;
			if (floyd[seck][inds][indd] == INT_MAX)
				cout << src << "*****No Path Found*****" << "-> " << carr[indd]<<endl;
			else {
				str += Path1(inds, indd, path[seck]) + "-> " + carr[indd];
				cout << str << endl;
			}
		}


	}
	void secondshortestPathfromalltoone(string dest) {
		int*** floyd = new int** [vertex];
		int*** path = new int** [vertex];


		for (int k = 0; k < vertex; k++) {
			floyd[k] = new int* [vertex];
			path[k] = new int* [vertex];

			for (int i = 0; i < vertex; i++) {
				floyd[k][i] = new int[vertex];
				path[k][i] = new int[vertex];
				for (int j = 0; j < vertex; j++) {
					path[k][i][j] = 0;

					if (i == j)
						floyd[k][i][j] = 0;
					else if (arr[i][j] == 0) {
						floyd[k][i][j] = INT_MAX;
					}

					else {
						floyd[k][i][j] = arr[i][j];
					}

				}
				floyd[k][i][k] = INT_MAX;
				path[k][i][k] = 0;
			}
		}

		for (int a = 0; a < vertex; a++) {
			for (int k = 0; k < vertex; k++) {
				for (int i = 0; i < vertex; i++) {
					for (int j = 0; j < vertex; j++) {
						if (i == j)
							continue;

						if ((floyd[a][i][j] > floyd[a][i][k] + floyd[a][k][j])
							&& (floyd[a][i][k] != INT_MAX)
							&& (floyd[a][k][j] != INT_MAX)) {

							floyd[a][i][j] = floyd[a][i][k] + floyd[a][k][j];
							path[a][i][j] = k;
						}

					}
				}
			}

		}

		int indd = -1;
		for (int i = 0; i < vertex; i++) {
			if (carr[i] == dest)
				indd = i;
		}

		if (indd == -1) {
			cout << "****Node Not Found ****\n";
			return;
		}


		for (int inds = 0; inds < vertex; inds++) {
			int mink = vertex - 1, seck = vertex - 2;
			for (int i = vertex - 1; i >= 0; i--) {

				if (floyd[i][inds][indd] == INT_MAX)
					continue;
				if (floyd[i][inds][indd] >= floyd[seck][inds][indd]) {
					if (floyd[i][inds][indd] <= floyd[mink][inds][indd]) {
						seck = mink;
						mink = i;
					}
					else
						seck = i;
				}
			}

			string str = carr[inds];

			if (floyd[seck][inds][indd] == INT_MAX)
				cout << str << "*****No Path Found*****" << "-> " << dest << endl;
			else {
				str += Path1(inds, indd, path[seck]) + "-> " + dest;
				cout << str << endl;
			}
		}


	}
	string secondShortestRoutefrompair(string src, string dest) {
		int*** floyd = new int** [vertex];
		int*** path = new int** [vertex];
		
		
		for (int k = 0; k < vertex; k++) {
			floyd[k] = new int* [vertex];
			path[k] = new int* [vertex];
			
			for (int i = 0; i < vertex; i++) {
				floyd[k][i] = new int[vertex];
				path[k][i] = new int[vertex];
				for (int j = 0; j < vertex; j++) {
					path[k][i][j] = 0;

					if (i == j)
						floyd[k][i][j] = 0;
					else if (arr[i][j] == 0) {
						floyd[k][i][j] = INT_MAX;
					}

					else {
						floyd[k][i][j] = arr[i][j];
					}

				}
				floyd[k][i][k] = INT_MAX;
				path[k][i][k] = 0;
			}
		}

		for (int a = 0; a < vertex; a++) {
			for (int k = 0; k < vertex; k++) {
				for (int i = 0; i < vertex; i++) {
					for (int j = 0; j < vertex; j++) {
						if (i == j)
							continue;

						if ( (floyd[a][i][j] > floyd[a][i][k] + floyd[a][k][j])
							 && (floyd[a][i][k] != INT_MAX)
							 && (floyd[a][k][j] != INT_MAX)) {

							floyd[a][i][j] = floyd[a][i][k] + floyd[a][k][j];
							path[a][i][j] = k;
						}

					}
				}
			}

		}

		int inds = -1, indd = -1;
		for (int i = 0; i < vertex; i++) {
			if (carr[i] == src)
				inds = i;
			if (carr[i] == dest)
				indd = i;

		}

		if (inds == -1 || indd == -1) {
			return "****Node Not Found ****\n";
		}

		int mink = vertex - 1,seck=vertex-2;
		for (int i = vertex-1; i >= 0; i--) {
		
			if (floyd[i][inds][indd] == INT_MAX)
				continue;
			if (floyd[i][inds][indd] >= floyd[seck][inds][indd]) {
				if (floyd[i][inds][indd] <= floyd[mink][inds][indd]) {
					seck = mink;
					mink = i;
				}
				else
					seck = i;
			}
		}

		string str = src;
		
		str = src;
		if (floyd[seck][inds][indd] == INT_MAX)
			return "NO PATH FOUND";
		str += Path1(inds, indd, path[seck]) + "-> " + dest;
		return str;
		
	
	}
	
	string printsingleLink(string str) {
		string ret = str + ":";
		int ind = -1;
		
		for (int i = 0; i < max; i++) {
			if (carr[i] == str) {
				ind = i;
				break;
			}
		}

		if (ind == -1) {
			return "* ***Node Not Found * ***\n";
		}

		for (int i = 0; i <max; i++) {
			if (adjMatrix[ind][i] != 0) {
				ret += " -> " + carr[i];
			}
		}
		string str1(ret);
		return str1;
	}
	void printGraph() {

		max = vertex;
		adjMatrix = arr;
		cities = carr;

		cout << "   ";
		for (int i = 0; i < max; i++) {
			cout << carr[i] << "  ";
		}

		cout << endl << endl;
		for (int i = 0; i < max; i++) {
			cout << carr[i] << "  ";

			for (int j = 0; j < max; j++) {
				cout << adjMatrix[i][j] << "  ";
			}
			cout << endl << endl;
		}

		cout << endl;
	}

};
