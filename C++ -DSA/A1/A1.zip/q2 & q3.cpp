#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <opencv2/imgproc.hpp>
#include<ctime>
using namespace std;
using namespace cv;

int main()
{


    String path = "C:/Users/Ozone8/Desktop/Assignment 1/Original Images/IMD033.bmp";
    //String path = "C:\\Users\\user\\Downloads\\2.bmp";

    Mat img = imread(path, IMREAD_COLOR);
    resize(img, img, { 500,500 }, 0, 0, cv::INTER_NEAREST);
    imshow("image", img);


    ///////////////////////////////////////////////////////////////
    /*
    int down_width = 300;
        int down_height = 200;
        Mat resized_down;
        //resize down
        resize(image, resized_down, Size(down_width, down_height), INTER_LINEAR);
        imshow("Resized Down by defining height and width", resized_down);
        */
    float** arrOut = new float* [img.rows];
    for (int i = 0; i < img.rows; i++)
    {
        arrOut[i] = new float[img.cols];
    }
    int x = 0, y = 0, z = 0;
    for (int i = 0; i < img.rows; i++)
    {
        for (int j = 0; j < img.cols; j++)
        {
            x = img.at<Vec3b>(i, j)[0];
            y = img.at<Vec3b>(i, j)[1];
            z = img.at<Vec3b>(i, j)[2];
            int h = (x + y + z);
            h /= 3;
            arrOut[i][j] = h;
        }
    }





    //for (int q = 0; q < img.rows; q++)

    //{
    //    for (int p = 0; p < img.cols; p++)
    //    {
    //        cout << arrOut[q][p] << " ";
    //    }
    //}

    bool flag = true;



  


    while(flag==true){
    int rows = img.rows;
    int cols = img.cols;
    int i1 = rand() % rows;
    int j1 = rand() % cols;
    int c1 = 0;
    int i2 = rand() % rows;
    int j2 = rand() % cols;
    int c2 = 0;

    for (int i = 0;i < img.rows;i++) {
        for (int j = 0;j < img.cols;j++) {
            if (i == i1 && j == j1) {
                c1 = arrOut[i][j];
            }
            else if (i == i2 && j == j2) {
                c2 = arrOut[i][j];
            }
        }
    }
    int a = 0;
    int b = 0;
    float** array1 = new float* [img.rows];
    for (int i = 0; i < img.rows; i++)
    {
        array1[i] = new float[img.cols];
    }



    for (int i = 0;i < img.rows;i++) {
        for (int j = 0;j < img.cols;j++) {
            a = c1 - arrOut[i][j];
            b = c2 - arrOut[i][j];

            if (a < 0) {
                a = abs(a);
            }
            if (b < 0) {
                b = abs(b);
            }

            if (a < b) {

                array1[i][j] = 1;
            }
            else {
                array1[i][j] = 0;
            }




        }
    }

    int count1 = 1;
    int count2 = 1;
    int sum1 = 0;
    int sum2 = 0;


    //for (int i = 0;i < img.rows;i++) {
    //    for (int j = 0;j < img.cols;j++) {
    //        cout << array1[i][j] << " ";
    //    }
    //}

    for (int i = 0;i < img.rows;i++) {
        for (int j = 0;j < img.cols;j++) {
            if (array1[i][j] == 1) {
                sum1 += arrOut[i][j];
                count1++;
            }
            else if (array1[i][j] == 0) {

                sum2 += arrOut[i][j];
                count2++;

            }
        }
    }

    int avg1 = sum1 / count1;
    int avg2 = sum2 / count2;

   
    if (avg1 == c1 && avg2 == c2) {
        for (int i = 0;i < img.rows;i++) {
            for (int j = 0;j < img.cols;j++) {
                if (array1[i][j] == 1)
                    arrOut[i][j] = 0;
                else
                    arrOut[i][j] = 1;
            }
        }
        flag = false;
    }
    else {
        arrOut[i1][j1] = avg1;
        arrOut[i2][j2] = avg2;
        
    }


}

bool flag1 = false;
int counter = 0;
int counter2 = 0;
for (int i = 0;i < img.rows;i++) {
    for (int j = 0;j < img.cols;j++) {
        if (arrOut[i][j]!=0) {
            counter++;
        }
        else
            counter2++;
    }
}
if (counter > counter2) {
    flag = true;
}



    for (int q = 0; q < img.rows; q++)

    {
        for (int p = 0; p < img.cols; p++)
        {
            if (arrOut[q][p] !=0 && flag == false  )
            {

                img.at<Vec3b>(q, p)[0] = 255;
                img.at<Vec3b>(q, p)[1] = 255;
                img.at<Vec3b>(q, p)[2] = 255;

            }
            else if (arrOut[q][p] != 0 && flag == true)
            {

                img.at<Vec3b>(q, p)[0] = 0;
                img.at<Vec3b>(q, p)[1] = 0;
                img.at<Vec3b>(q, p)[2] = 0;

            }
            else if (arrOut[q][p] == 0 && flag == false) {

                img.at<Vec3b>(q, p)[0] = 0;
                img.at<Vec3b>(q, p)[1] = 0;
                img.at<Vec3b>(q, p)[2] = 0;
            }
            else if (arrOut[q][p] == 0 && flag == true)
            {

                img.at<Vec3b>(q, p)[0] = 255;
                img.at<Vec3b>(q, p)[1] = 255;
                img.at<Vec3b>(q, p)[2] = 255;

            }
        }
    }


 

    resize(img, img, { 500,500 }, 0, 0, cv::INTER_NEAREST);
    imshow("image", img);


    String pa = ("C:\\Users\\Ozone8\\Desktop\\Assignment 1\\Ground Truths\\IMD033_lesion.bmp");

    Mat im = imread(pa, IMREAD_COLOR);


    Mat d;
    im.convertTo(d, CV_32F);

    float** array02 = new float* [d.rows];
    for (int i = 0; i < d.rows; i++)
    {
        array02[i] = new float[d.cols];
    }

    x = 0, y = 0, z = 0;

    for (int i = 0; i < d.rows; i++)
    {
        for (int j = 0; j < d.cols; j++)
        {
            x = im.at<Vec3b>(i, j)[0];
            y = im.at<Vec3b>(i, j)[1];
            z = im.at<Vec3b>(i, j)[2];
            int h = (x + y + z);
            h /= 3;
            array02[i][j] = h;
        }
    }

    float tp01 = 0, fp01 = 0, fn01 = 0;

    for (int i = 0; i < img.rows; i++)
    {
        for (int j = 0; j < img.cols; j++)
        {
            if (array02[i][j] == arrOut[i][j]) {
                tp01 = tp01 + 1;
            }
                
            else
            {
                if (array02[i][j] == 0) {


                    fp01 = fp01 + 1;
                }
                else {
                    fn01 = fn01 + 1;
                }
            }

        }
    }

    float dice01 = (2 * tp01);
    dice01=dice01/ (fn01 + (2 * tp01) + fp01);

    cout <<"The dice value is "<< dice01 << endl;

    /*Mat image = Mat::zeros(300, 600, CV_8UC3);
    circle(image, Point(250, 150), 100, Scalar(0, 255, 128), -100);
    circle(image, Point(350, 150), 100, Scalar(255, 255, 255), -100);
    imshow("Display Window", image);*/
    waitKey(0);
    return 0;


}