#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <opencv2/imgproc.hpp>
using namespace std;
using namespace cv;
#include<conio.h>


template <class T>
class Node1
{
public:
	int* data;
	int size=0;
	Node1 *next;

	Node1()
	{
		data = new int[size];
		next = NULL;
	}

	void setData(int d)
	{
		data[size] = d;
		size++;
		data[size] = -1;
	}

	void setNext(Node1* n)
	{
		next = n->next;
	}

	T getData()
	{
		return data;
	}

	Node1* getNext()
	{
		return next;
	}

};

template <class T>
class SLinkedList {

public:

	Node1<T>* head;


	SLinkedList()
	{
		head = new Node1<T>();
		int size1 = 500;
		
	}


	void insert(T array) {
		if (head == NULL) {
			head = new Node1<T>();
			head->setData(array);

		}
		else {
			Node1 <T>* n;
			n = head;
			while (n->next != NULL) {
				n = n->next;
			}
			Node1 < T >* newa = new Node1<T>();
			head->setData(array);
			newa->next = NULL;
			n->next = newa;

		}
	}


	void remove(int index) {
		Node1 < T >* n = head;
		for (int i = 0;i < index;i++) {
			n = n->next;
		}
		n->next = n->next->next;
	}
	void print() {
		Node1 < T >* n = head;
		while (n != NULL) {
			cout << n->data << ",";
			n = n->next;
		}
	}

};


int main()
{


    String path = "C:/Users/Ozone8/Desktop/Assignment 1/Segmented Outputs/mIMD002.bmp";
    //String path = "C:\\Users\\user\\Downloads\\2.bmp";

    Mat img = imread(path, IMREAD_COLOR);
    resize(img, img, { 500,500 }, 0, 0, cv::INTER_NEAREST);
    imshow("image", img);


    ///////////////////////////////////////////////////////////////
    /*
    int down_width = 300;
        int down_height = 200;
        Mat resized_down;
        //resize down
        resize(image, resized_down, Size(down_width, down_height), INTER_LINEAR);
        imshow("Resized Down by defining height and width", resized_down);
        */
    float** arrOut = new float* [img.rows];
    for (int i = 0; i < img.rows; i++)
    {
        arrOut[i] = new float[img.cols];
    }
    int x = 0, y = 0, z = 0;
    for (int i = 0; i < img.rows; i++)
    {
        for (int j = 0; j < img.cols; j++)
        {
            x = img.at<Vec3b>(i, j)[0];
            y = img.at<Vec3b>(i, j)[1];
            z = img.at<Vec3b>(i, j)[2];
            int h = (x + y + z);
            h /= 3;
            arrOut[i][j] = h;
        }
    }


	SLinkedList<int> obj;

	Node1<int>* temp = obj.head;
	
	bool flag = false;

	for (int i = 0;i < img.rows;i++) {
		for (int j = 0;j < img.cols;j++) {
			if (arrOut[i][j] == 255) {
				SLinkedList<int> obj;
				obj.insert(j);
				if (arrOut[i][j + 1] == 0) {
					flag = true;
				}
			}
		}
	}



    for (int q = 0; q < img.rows; q++)

    {
        for (int p = 0; p < img.cols; p++)
        {
            if (arrOut[q][p] == 255)
            {

                img.at<Vec3b>(q, p)[0] = 255;
                img.at<Vec3b>(q, p)[1] = 255;
                img.at<Vec3b>(q, p)[2] = 255;

            }
            else
            {

                img.at<Vec3b>(q, p)[0] = 0;
                img.at<Vec3b>(q, p)[1] = 0;
                img.at<Vec3b>(q, p)[2] = 0;

            }
        }
    }

    resize(img, img, { 500,500 }, 0, 0, cv::INTER_NEAREST);
    imshow("image", img);




    /*Mat image = Mat::zeros(300, 600, CV_8UC3);
    circle(image, Point(250, 150), 100, Scalar(0, 255, 128), -100);
    circle(image, Point(350, 150), 100, Scalar(255, 255, 255), -100);
    imshow("Display Window", image);*/
    waitKey(0);
    return 0;


}

