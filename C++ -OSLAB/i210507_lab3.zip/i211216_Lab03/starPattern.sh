#!/bin/bash

echo "enter no. of rows"
read numRows

spaces=$(( $numRows-1 ))
i=1
j=1

for (( i = 1; i <= numRows; i++ ));
do
	for (( j = 1; j <= spaces; j++ ));
	do
		echo -n ' '
	done
	spaces=$spaces-1
	for (( j = 1; j <= $(( 2*$i-1 )); j++ ));
	do
		echo -n '*'
	done
	echo ' '
	
done

spaces=1

for (( i = 1; i <= numRows-1; i++ ));
do 
	for (( j = 1; j <= spaces; j++ ));
	do
	echo -n ' '
	done
	spaces=$spaces+1
	for (( j = 1; j <= $(( 2* $(( $numRows-$i )) )) -1; j++ )) ;
	do
	echo -n '*'
	done
	echo ' '
done

echo -n
