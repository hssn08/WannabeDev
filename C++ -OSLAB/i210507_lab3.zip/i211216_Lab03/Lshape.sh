

#!/bin/bash

echo "enter no. of rows"
read numRows

for (( i = 1; i <= numRows; i++ ))
do
echo '*'
done

for (( i = 1; i <= numRows; i++ ))
do
echo -n '*'
done
