#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

using namespace std;

const int NUM_PHILOSOPHERS = 5;


sem_t forks[NUM_PHILOSOPHERS];


void think(int philosopherId) {
   cout << "Philosopher " << philosopherId << " is thinking." << endl;

}


void eat(int philosopherId) {
    cout << "Philosopher " << philosopherId << " is eating." << endl;
 
}

void* philosopher(void* arg) {
    int philosopherId = *(int*)arg;
    int leftFork = philosopherId;
    int rightFork = (philosopherId + 1) % NUM_PHILOSOPHERS;

    while (true) {
        think(philosopherId);

       
        sem_wait(&forks[leftFork]);
        sem_wait(&forks[rightFork]);

       
        eat(philosopherId);

       
        sem_post(&forks[leftFork]);
        sem_post(&forks[rightFork]);
    }

    pthread_exit(nullptr);
}

int main() {
  
   

   
    for (int i = 0; i < NUM_PHILOSOPHERS; ++i) {
        sem_init(&forks[i], 0, 1);
    }

   
    pthread_t p[NUM_PHILOSOPHERS];

   
    int philosopherIds[NUM_PHILOSOPHERS];
    for (int i = 0; i < NUM_PHILOSOPHERS; ++i) {
        philosopherIds[i] = i;
        pthread_create(&p[i], nullptr, philosopher, &philosopherIds[i]);
    }

  
    for (int i = 0; i < NUM_PHILOSOPHERS; ++i) {
        pthread_join(p[i], nullptr);
    }

   
    for (int i = 0; i < NUM_PHILOSOPHERS; ++i) {
        sem_destroy(&forks[i]);
    }

    return 0;
}

