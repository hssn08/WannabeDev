#include <iostream>
#include <pthread.h>
using namespace std;

const int SIZE = 100;

int A[SIZE][SIZE];
int B[SIZE][SIZE];
int C[SIZE][SIZE];


int rows_A, cols_A, rows_B, cols_B;


const int NUM_THREADS = 3;


pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;


struct ThreadData {
    int startRow;
    int endRow;
};


void* multiplyMatrix(void* threadData) {
    ThreadData* data = static_cast<ThreadData*>(threadData);

    for (int i = data->startRow; i < data->endRow; ++i) {
        for (int j = 0; j < cols_B; ++j) {
            C[i][j] = 0;
            for (int k = 0; k < cols_A; ++k) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }

    pthread_exit(nullptr);
}

int main() {
   
    rows_A = 3;
    cols_A = 3;
    rows_B = 3;
    cols_B = 3;

  
    for (int i = 0; i < rows_A; ++i) {
        for (int j = 0; j < cols_A; ++j) {
            A[i][j] = i + j;
        }
    }
    
     for (int i = 0; i < rows_A; ++i) {
        for (int j = 0; j < cols_A; ++j) {
            cout<<A[i][j]<<" ";
        }
        cout<<endl;
    }
    
    
    cout<<endl;
  
    
    

    for (int i = 0; i < rows_B; ++i) {
        for (int j = 0; j < cols_B; ++j) {
            B[i][j] = i - j;
        }
    }
    
     for (int i = 0; i < rows_A; ++i) {
        for (int j = 0; j < cols_A; ++j) {
            cout<<B[i][j]<<" ";
        }
        cout<<endl;
    }
    
    

   
    pthread_t threads[NUM_THREADS];

  
    int rowsPerThread = rows_A / NUM_THREADS;
    int remainingRows = rows_A % NUM_THREADS;
    int startRow = 0;
    int endRow;

    for (int i = 0; i < NUM_THREADS; ++i)
    {
        endRow = startRow + rowsPerThread + (i < remainingRows ? 1 : 0);

        ThreadData* data = new ThreadData{startRow, endRow};
        pthread_create(&threads[i], nullptr, multiplyMatrix, data);

        startRow = endRow;
    }

   
    for (int i = 0; i < NUM_THREADS; ++i) {
        pthread_join(threads[i], nullptr);
    }

  
    cout << "Result Matrix C:" <<endl;
    for (int i = 0; i < rows_A; ++i) {
        for (int j = 0; j < cols_B; ++j) {
            cout << C[i][j] << " ";
        }
        cout <<endl;
    }

    return 0;
}
