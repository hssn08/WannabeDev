#include <iostream>
#include <pthread.h>
#include <unistd.h>

const int BUFFER_SIZE = 5; // Declare the type for BUFFER_SIZE

int buffer[BUFFER_SIZE];
int count = 0;
int in = 0;
int out = 0;

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

void* producer(void* arg) {
    for (int i = 0; i < 10; ++i) {
        pthread_mutex_lock(&mutex);
        if (count == BUFFER_SIZE) {
            pthread_mutex_unlock(&mutex);
            usleep(rand() % 500000);
            continue;
        }
        int item = rand() % 50;
        buffer[in] = item;
        std::cout << "Produced: " << item << ". Buffer size: " << (count + 1) << std::endl;
        in = (in + 1) % BUFFER_SIZE;
        count++;
        pthread_mutex_unlock(&mutex);
        usleep(rand() % 500000);
    }
    pthread_exit(NULL);
}

void* consumer(void* arg) {
    for (int i = 0; i < 10; ++i) {
        pthread_mutex_lock(&mutex);
        if (count == 0) {
            pthread_mutex_unlock(&mutex);
            usleep(rand() % 500000);
            continue;
        }
        int item = buffer[out];
        std::cout << "Consumed: " << item << ". Buffer size: " << (count - 1) << std::endl;
        out = (out + 1) % BUFFER_SIZE;
        count--;
        pthread_mutex_unlock(&mutex);
        usleep(rand() % 500000);
    }
    pthread_exit(NULL);
}

int main() {
    pthread_t Producer, Consumer;

    pthread_create(&Producer, NULL, producer, NULL);
    pthread_create(&Consumer, NULL, consumer, NULL);

    pthread_join(Producer, NULL);
    pthread_join(Consumer, NULL);

    return 0;
}
