#include <unistd.h>
#include <iostream> 

using namespace std;

int main(int argv, char* args[]) {
	cout<<args[1]<<" + " <<args[2]<<" = " << stoi(args[1])+stoi(args[2])<<endl;
	return 0;
}
