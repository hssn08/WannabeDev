#!/bin/bash

read -p "Enter the number to read " num

count=0;
num2=num; #num2 is a copy of num

while((num2 > 0)); do
	num2=$((num2/10));
	count=$((count+1));
done
#count tells how lomg the number is 


#spaces=$((rows / 2))

sum=0;
num3=num; #num3 is a copy of num

for ((i = 1; i <= count; i++)); do
	rem=$((num3%10));
	echo "its digit is" $rem
	fact=1;
	for((j=rem; j>=1; j--)); do
		fact=$((fact*j));
	done
	
	sum=$((sum+fact))
	num3=$((num3/10));
	
	
done

echo "sum of the factorials of its digits is " $sum

 if [ $sum -eq $num ]; then
       echo "its a strong num"
    else
    echo "its not a strong num"
    fi
