#include <unistd.h>
#include <iostream> 
#include <sys/wait.h>
#include <string.h>

using namespace std;

char* commandShortener(char[] cmd) {
	int sizee=0;
	for(int i=0;i<sizeof(cmd);i++) {
		if(cmd[i]!="\0") {
			sizee++;
		}
	}
}

int main() {
	//std::string cmd;
	char cmd[5] = {};
	std::string argz[5];
	int choice;
	while(true) {
		cout<<"enter the command to execute (quit to stop) ";
		cin>>cmd;
		
		if(cmd=="quit\n")
		break;
		
		
		pid_t pid= fork();
		if(pid==-1) {
			cout<<"error in spawning"<<endl;
			return 1;
		}
		if(pid==0) {
			//std::string commandfinal = "/bin/" + cmd;
			
			//execl(wcsstr(commandfinal), wcsstr(cmd), NULL); //if no arguments
			//cout<<"excl failed!!"<<endl;
			exit(0);
		} 
	
	}
	
	return 0;

}
