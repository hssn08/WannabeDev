#include <unistd.h>
#include <iostream> 
#include <sys/wait.h>

using namespace std;

int main() {

	pid_t pid = fork(); //creating child
	
	
	if(pid == -1) { //error handling
		cout<<"fork failed"<<endl;
		return 1;
	}
	
	if(pid==0){ //child process
		int c1, c2;
		cout<<" enter parameter 1 to send to child process ";
		cin>>c1;
	
		cout<<"enter parameter 2 to send to child process ";
		cin>>c2;
		
		execl("sum", "./sum.out", c1, c2, NULL);	 //assuming sum.cpp is already compiled into an obj named 'sum'
		cout<<"exec failed"<<endl;
		exit(0);
	} 
	else {
	wait(NULL);
		int p1, p2;
		cout<<" enter parameter 1 to send to parent process ";
		cin>>p1;
	
		cout<<"enter parameter 2 to send to parent process ";
		cin>>p2;
		
		execl("dif", "./dif.out", p1, p2, NULL);	 //assuming difference.cpp is already compiled into an obj named 'dif'
		cout<<"exec failed"<<endl;
	}
	
	return 0;

}
