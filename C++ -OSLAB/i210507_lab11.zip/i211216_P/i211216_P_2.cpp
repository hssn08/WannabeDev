#include <unistd.h>
#include <iostream> 
#include <sys/wait.h>

using namespace std;
bool isPrime(int num) {
	for(int i=num-1; i>1; i--) {
		if(num%i == 0) {
			return false;
		}
	}
	
	return true;
}


int numPrimeNosInRange(int min, int max) {
	int count=0;
	for(int i=min; i<max; i++) {
		if(isPrime(i)) 
			count++;
	}
	return count;

}
int main() {
	int range, min, max, numC, chunks;
	int fd[2];
	if(pipe(fd) == -1) {
		cout<<"error"<<endl;
		return 1;
	}
	
	cout<<"enter minimum num (inclusive) in range ";
	cin>>min;
	
	cout<<"enter maximum num (inclusive) in range ";
	cin>>max;
	
	cout<<"enter num of child processes to create";
	cin>>numC;
	
	range=max-min;
	chunks=range/numC;
		
	for(int i=0;i<numC;i++) {
		pid_t pid = fork();
		if(pid==0) {
			close(fd[0]);//child will only write
			
			//calculations by child
			int thisChildMin = min + chunks*i;
			int thisChildMax = min + chunks*(i+1);
			if(i+1 == numC) {
				thisChildMax = max+1; //extend range because its last interval; +1 because we said max was inclusive while taking input
			}
			int ctPrimesInRange = numPrimeNosInRange(thisChildMin, thisChildMax); //upper range is not inclusive in this func
			cout<<"I am child, my range was "<<thisChildMin<<" to "<<thisChildMax-1<<" and i found "<<ctPrimesInRange<<" prime nos"<<endl<<endl;
						 
			write(fd[1], &ctPrimesInRange, sizeof(int)); //writing to parent.
			exit(0); //ending child process here
			break;			
		} 
	}
	
	
	for(int i=0;i<numC; i++) 
		wait(NULL);
	cout<<" - --  - -- --  ---- -- --- - -  "<<endl;
	cout<<"i am parent"<<endl;
	
	int sumPrimes=0; 
	int reading;
	for(int i=0;i<numC; i++) {
		read(fd[0], &reading, sizeof(int));
		cout<<"child "<<i+1<< " found " <<reading <<" primes!"<<endl;
		sumPrimes += reading; 
	}
	cout<<"total no of primes found in the range " <<sumPrimes<<endl;

}



