#include <iostream>
#include <pthread.h>
#include<semaphore.h>
#include "ResourceManagement.h"
#include "TaskManagement.h"
const int tasks=10;

int main() {
    srand(time(0));
    
    sem_init(&bufferNotEmpty,0,0); //produce  resources and then consume as in provide to site 
   
        pthread_t generateThread,assignThread ,taskThread , adverseThread;

        if (pthread_create(&generateThread, NULL,generateResources, NULL)!=0) 
        {
            cout<<"Error creating generateResources thread"<<endl;
            return 1;
        }
       


        if (pthread_create(&assignThread,NULL,AssignResourcestoworkers, NULL) != 0) 
        {
            cout<<"Error creating AssignResourcestoworkers thread"<<endl;
            return 1;
        }

        if (pthread_create(&taskThread, NULL, createTaskThreads, NULL)!= 0) 
        {
            cout<<"Error creating task thread"<<endl;
            return 1;
        }

        if (pthread_create(&adverseThread, NULL, setTrueAfterRandomTime, NULL)!= 0) 
        {
            cout << "Error creating adverse condition simulation thread"<<endl;
            return 1;
        }

        
        //waiting for all threads
        if (pthread_join(generateThread, NULL)!= 0) 
        {
            cout<< "Error joining generateResources thread" <<endl;
            return 1;
        }
        if (pthread_join(assignThread, NULL)!= 0) 
        {
            cout<<"Error joining AssignResourcestoworkers thread"<<endl;
            return 1;
        }
        //cancel all other threads on joining createTaskThreads
        pthread_join(taskThread, NULL);
        if (pthread_cancel(adverseThread) != 0)
        {
            cout << "Error cancelling adverse condition simulation thread"<<endl;
            return 1;
        }
        if(pthread_cancel(generateThread)!=0)
        {
            cout<<"Error cancelling generateResources thread"<<endl;
            return 1;
        }
        if(pthread_cancel(assignThread)!=0)
        {
            cout<<"Error cancelling AssignResourcestoworkers thread"<<endl;
            return 1;
        }



        if (pthread_join(adverseThread, NULL) != 0) 
        {
            cout << "Error joining adverse condition simulation thread"<<endl;
            return 1;
        }
        cout<<"All threads joined successfully"<<endl;
        cout<<"WORK DONE"<<endl;
    

    // Destroying semaphore
    sem_destroy(&bufferNotEmpty);

    return 0;
}
