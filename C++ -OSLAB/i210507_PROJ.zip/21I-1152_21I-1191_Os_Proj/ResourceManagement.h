#ifndef RESOURCE_MANAGEMENT_H
#define RESOURCE_MANAGEMENT_H

#include <queue>
#include <pthread.h>
#include <semaphore.h>
#include <iostream>
#include <unistd.h>
#include<vector>
using namespace std;

const char* bricksSymbol = "\u2588";
const char* cementSymbol = "\u25A0";
const char* toolsSymbol = "\u2692";

//for producer consumer algo
sem_t bufferNotEmpty;
//for signaling available resources to tasks assigner func
sem_t resourcesAvailableSem; 

struct Resource 
{
    int unitsBricks;
    int unitsCement;
    int unitsTools;
};


struct ConstructionSiteData 
{
    int totalBricks;
    int totalCement;
    int totalTools;
    string externalFactors[3] = {"Bad Weather occured caused resource replenishment","Time based Decay occured and caused resource replenishment","External Factor caused resource replenishment"};

};

ConstructionSiteData siteData;  

// Producer-consumer implemented here as the generateResources function acts as a producer
// and the AssignResourcestoworkers function acts as a consumer that keeps storing the resources in a queue
// until workers use them in tasks

pthread_mutex_t siteDataMutex = PTHREAD_MUTEX_INITIALIZER;  // for synchronization of storing the generated data in site total data to be used later in tasks 
pthread_mutex_t bufferMutex = PTHREAD_MUTEX_INITIALIZER;    // for producing and consuming

//shared buffer queue for resources
queue<Resource> resourceBuffer;

void* generateResources(void* args) 
{
    while (true) 
    {
        sleep(10);

        //random resources produced
        int generatedBricks = 1;
        int generatedCement=1;
        int generatedTools=1;

        Resource newResource;
        newResource.unitsBricks=generatedBricks;
        newResource.unitsCement =generatedCement;
        newResource.unitsTools=generatedTools;
        

        pthread_mutex_lock(&bufferMutex);

        //new resource is added to the buffer queue to be used later
        resourceBuffer.push(newResource);
        cout << "\n--------------------------------------------------";
        cout << "\nNew resources added to stock\n";
        cout << "\n\t" << newResource.unitsBricks << " Bricks ";
        for(int i=0; i<newResource.unitsBricks; i++)
        {
            cout<< bricksSymbol<<" ";
        }
        cout<<endl;
        cout << "\t" <<newResource.unitsCement << " Cement Packs ";
          for(int i=0; i <newResource.unitsCement; i++)
        {
            cout<< cementSymbol <<" ";
        }
        cout<<endl;
        cout << "\t" <<newResource.unitsTools<< " Tools ";
          for(int i=0;i <newResource.unitsTools ; i++)
        {
            cout<< toolsSymbol <<" ";
        }
        cout<<endl;
        cout << "--------------------------------------------------\n";

        pthread_mutex_unlock(&bufferMutex);

        //signaling that buffer isn't empty
        sem_post(&bufferNotEmpty);
    }

    pthread_exit(NULL);
}

void* AssignResourcestoworkers(void*) {
    while (true) 
    {
        //wait on the semaphore for the buffer to be not empty
        sem_wait(&bufferNotEmpty);

        pthread_mutex_lock(&bufferMutex);

        //consuming resources from the buffer
        Resource consumedResource = resourceBuffer.front();
        resourceBuffer.pop();

        pthread_mutex_unlock(&bufferMutex);

        //update shared memory with resource availability
        pthread_mutex_lock(&siteDataMutex);

        siteData.totalBricks+=consumedResource.unitsBricks;
        siteData.totalCement+= consumedResource.unitsCement;
        siteData.totalTools+= consumedResource.unitsTools;

        cout << "\n--------------------------------------------------";
        cout << "\nTotal resources available for workers on Site are\n";
        cout << "\n\t" << siteData.totalBricks << " Bricks ";
        for(int i = 0 ; i <siteData.totalBricks ; i++)
        {
            cout<< bricksSymbol <<" ";
        }
        cout<<endl;
        cout << "\t" << siteData.totalCement << " Cement Packs ";
        for(int i = 0 ; i <siteData.totalCement ; i++)
        {
            cout<< cementSymbol <<" ";
        }
        cout<<endl;
        cout << "\t" << siteData.totalTools << " Tools ";
        for(int i = 0 ; i <siteData.totalTools ; i++)
        {
            cout<< toolsSymbol <<" ";
        }
        cout<<endl;
        cout << "--------------------------------------------------\n";

        pthread_mutex_unlock(&siteDataMutex);

        //signal other waiting threads for task creation and assignment that resources are available
        for (int i = 0; i < 10; i++) {
            sem_post(&resourcesAvailableSem);
        }

        //sleep for a while before assigning more resources
        sleep(1);
    }

    pthread_exit(NULL);
}

#endif
