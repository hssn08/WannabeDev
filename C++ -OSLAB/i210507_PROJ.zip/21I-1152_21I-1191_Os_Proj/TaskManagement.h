#ifndef TASK_MANAGEMENT_H
#define TASK_MANAGEMENT_H

#include <iostream>
#include <pthread.h>
#include <unistd.h>
#include <iomanip>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include "ResourceManagement.h"

using namespace std;

//number of tasks
const int num_tasks=10;
const int num_workers=5;
int done=0;

//mutex 
pthread_mutex_t adverseMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t workerMutex = PTHREAD_MUTEX_INITIALIZER;
bool adverseConditions = false;

struct worker
{
    int id;
    string skill;
    int skillLevel;
    int efficiency;
    string name;
};
vector<worker> workersmain;
vector<worker> workersvirtual;
vector<worker> employees;

//priority queues for each priority level
struct ConstructionTask 
{
    int id;
    string name;
    int requiredBricks;
    int requiredCement;
    int requiredTools;
    string priority_level;
    int priority_num;
    bool adverseConditions;
    string skill_req; // indicates that this type of task cannot be performed in an adverse condition
    time_t arrivalTime;
};
queue<ConstructionTask> highPriorityQueue;
queue<ConstructionTask> mediumPriorityQueue;
queue<ConstructionTask> lowPriorityQueue;

//vectors for sorting later for fifo
vector<ConstructionTask> sortedHighPriorityVector;
vector<ConstructionTask> sortedMediumPriorityVector;
vector<ConstructionTask> sortedLowPriorityVector;
vector<ConstructionTask> LowPriorityPostponedVector;
//mutex to protect a task at a time
pthread_mutex_t taskMutex = PTHREAD_MUTEX_INITIALIZER;
// Semaphore to signal availability of resources to be used by a task
extern sem_t resourcesAvailableSem;  
//for shared memory sitedata that stores the total bricks , cements and tools
extern pthread_mutex_t siteDataMutex; 

extern ConstructionSiteData siteData; 

void * threadforforking(void * args)
{
    
    int fd[2];
    int fd2[2];
    if(pipe(fd)==-1)
    {
        cout<<"Error in creating pipe"<<endl;
        exit(1);
    }
    if(pipe(fd2)==-1)
    {
        cout<<"Error in creating pipe"<<endl;
        exit(1);
    }
    int pid=fork();
    if(pid==0)
    {
            
            //read id of all low priority tasks from parent
            vector<int> highPriorityTasks;
            int id;
            while(true)
            {
                read(fd[0],&id,sizeof(id));
                if(id==-1)
                {
                    break;
                }
                highPriorityTasks.push_back(id);
            }
            //if no high priority tasks are present then continue
            if(highPriorityTasks.size()==0)
            {
                write(fd2[1],&id,sizeof(id));
                exit(0);
            }
            //select a random task from high priority tasks
            int randval=rand()%highPriorityTasks.size();

            //write the id of that task to parent
            write(fd2[1],&highPriorityTasks[randval],sizeof(highPriorityTasks[randval]));
            exit(0);

        


        
    }
    else
    {
            int i=rand()%3;
            if(i==0)
            {
                cout<<"\n..................BOSS IS CHECKING THE SITE DATA....................\n";
                //write id of all low priority tasks to child
                for(int i=0;i<sortedLowPriorityVector.size();i++)
                {
                    write(fd[1],&sortedLowPriorityVector[i].id,sizeof(sortedLowPriorityVector[i].id));
                }
                //write -1 to indicate end of low priority tasks
                int x=-1;
                write(fd[1],&x,sizeof(x));
                //read id of task to be promoted
                int id;
                read(fd2[0],&id,sizeof(id));
                //find the task with that id
                pthread_mutex_lock(&taskMutex);
                for(int i=0;i<sortedLowPriorityVector.size();i++)
                {
                    if(sortedLowPriorityVector[i].id==id)
                    {
                        sortedLowPriorityVector[i].priority_level="HIGH";
                        sortedLowPriorityVector[i].priority_num=0;
                        
                        //erase that task from low priority queue
                        sortedHighPriorityVector.push_back(sortedLowPriorityVector[i]);
                        sortedLowPriorityVector.erase(sortedLowPriorityVector.begin()+i);
                        //push that task to high priority queue
                        //sort the high priority queue
                        auto comparePriority = [](const ConstructionTask& task1, const ConstructionTask& task2) 
                        {
                            if (task1.priority_num == task2.priority_num) 
                            {
                                return task1.arrivalTime < task2.arrivalTime;
                            }
                            return task1.priority_num < task2.priority_num;
                        };
                        sort(sortedHighPriorityVector.begin(), sortedHighPriorityVector.end(), comparePriority);
                        cout<<"\n..................BOSS HAS PROMOTED TASK "<<sortedHighPriorityVector[sortedHighPriorityVector.size()-1].name<<" Id "<<sortedHighPriorityVector[sortedHighPriorityVector.size()-1].id<<" TO HIGH PRIORITY"<<endl;
                        break;
                    }

                }
                pthread_mutex_unlock(&taskMutex);

            }
    
            
        


      
    }
    pthread_exit(NULL);
}
void* setTrueAfterRandomTime(void* args)  
{
    while (true) {
        int randval = rand() % 100+1;
        if(randval<=40)
        {

            //random delay so that the adverse condition occurs after that
            sleep(rand() % 5);

            pthread_mutex_lock(&adverseMutex);
            adverseConditions = true;
            pthread_mutex_unlock(&adverseMutex);
            cout<<"\n..................WEATHER UPDATE....................";
            cout << "\nTHE WEATHER HAS STARTED TO TURN BAD!!!";
            cout<<"\n....................................................\n";

            sleep(10);

            pthread_mutex_lock(&adverseMutex);
            adverseConditions = false;
            pthread_mutex_unlock(&adverseMutex);
            cout<<"\n..................WEATHER UPDATE....................";
            cout << "\nTHE WEATHER IS CLEAR NOW!!!";
            cout<<"\n....................................................\n";


            sleep(rand() % 5 + 5);
        }
        int randval2=rand()%100+1;
        if(randval2<=20)
        {
            pthread_mutex_lock(&workerMutex);
            int size=workersmain.size();
            if(size==0)
            {
                continue;}

            int randval3=rand()%size;

            cout<<"\n ................... WORKER REQUESTED HOLIDAY ................... \n";
            cout<<"Worker "<<workersmain[randval3].name<<" is going on a holiday"<<endl;
            cout<<"...................................................................\n\n";

            worker temp2=workersmain[randval3];
            workersmain.erase(workersmain.begin()+randval3);
            worker temp=workersvirtual[0];
            workersvirtual.erase(workersvirtual.begin());
            workersmain.push_back(temp);
            pthread_mutex_unlock(&workerMutex);
            sleep(15);

            cout<<"\n..................... WORKER RETURNED FROM HOLIDAY ..................\n";
            cout<<"Worker "<<temp2.name<<" has returned from holiday";
            cout<<"\n...................................................................\n\n";

            pthread_mutex_lock(&workerMutex);
            if(workersvirtual.size()<num_workers)
            {
                workersvirtual.push_back(temp2);
            }
            else
            {
                workersmain.push_back(temp2);

            }
            pthread_mutex_unlock(&workerMutex);
        }
    }

    pthread_exit(NULL);
}






const vector<string> skilltype={"Mason","Carpenter","Painter","Electrician","Plumber"};

//generating random tasks here
ConstructionTask generateRandomTask() 
{
    const vector<string> taskNames = {"Non-critical tasks", "finishing touches", "aesthetic elements" , 
    "laying bricks","mixing cement","scaffolding" , 
    "Urgent repairs", "foundation laying", "critical structural work"};

    ConstructionTask task;
    
    int randval= rand()% taskNames.size();
    task.name = taskNames[randval];
    task.requiredBricks = rand()%3 +1;
    task.requiredCement = rand()%3+1;
    task.requiredTools = rand()%3+1;
    task.skill_req=skilltype[rand()%skilltype.size()];
    

    int randval2=rand()%3;

    //assigning priority levels and numbers
    if(randval2 ==0)
    {
        task.priority_level="LOW";
        task.priority_num=rand()%3 + 7;
    }
    else if(randval2==1)
    {
        task.priority_level="MEDIUM";
        task.priority_num=rand()%3 + 4;
    }
    else if(randval2==2)
    {
        task.priority_level="HIGH";
        task.priority_num=rand()%3 + 1;
    }

    //assigning adverse conditions
    task.adverseConditions = (randval % 4 == 0);

    task.arrivalTime = time(nullptr);
    sleep(1);

    return task;
}


// function to check if there are sufficient resources for a task
bool checkResourceAvailability(const ConstructionTask& task) 
{
    pthread_mutex_lock(&siteDataMutex);
    bool hasEnoughResources = (siteData.totalBricks>=task.requiredBricks) &&(siteData.totalCement>=task.requiredCement) &&(siteData.totalTools>=task.requiredTools);
    if(hasEnoughResources)
    {
        siteData.totalBricks-=task.requiredBricks;
        siteData.totalCement-=task.requiredCement;
        siteData.totalTools-=task.requiredTools;
    }
    pthread_mutex_unlock(&siteDataMutex);
    return hasEnoughResources;
}

//function to perform a construction task
void* performTask(void* taskPtr) 
{
    ConstructionTask* task = (ConstructionTask*)taskPtr;
    //check if a worker is available
    bool workerAvailable=false;
    worker w;
    while(!workerAvailable){
    sleep(5);
    pthread_mutex_lock(&workerMutex);
        for(int i=0;i<workersmain.size();i++)
        {
            if(workersmain[i].skill==((ConstructionTask*)taskPtr)->skill_req )
            {
                if(workerAvailable)
                {
                    if(workersmain[i].skillLevel>w.skillLevel)
                    {
                        worker temp=w;
                        w=workersmain[i];
                        workersmain.erase(workersmain.begin()+i);
                        workersmain.push_back(temp);

                    }
                }
                else{
                    w=workersmain[i];
                    workerAvailable=true;
                    workersmain.erase(workersmain.begin()+i);
                }
                

                
                
            }
        }

        //check from virtual worker then first swap that worker with the least recently used main worker
        if(!workerAvailable)
        {
            for(int i=0;i<workersvirtual.size();i++)
            {
                if(workersvirtual[i].skill==((ConstructionTask*)taskPtr)->skill_req)
                {
                    

                    if(workerAvailable)
                    {
                        if(workersvirtual[i].skillLevel>w.skillLevel)
                        {
                            worker toswap=workersmain[0];
                            workersmain[0]=workersvirtual[i];
                            workersvirtual[i]=toswap;
                            worker temp=w;
                            w=workersmain[0];
                            workersmain.erase(workersmain.begin());
                            workersmain.push_back(temp);
                        }
                    }
                    else if(workersmain.size()==num_workers)
                    {
                        worker toswap=workersmain[0];
                        workersmain[0]=workersvirtual[i];
                        workersvirtual[i]=toswap;
                        w=workersmain[0];
                        workersmain.erase(workersmain.begin());
                    }
                    else
                    {
                        workersmain.push_back(workersvirtual[i]);
                        workersvirtual.erase(workersvirtual.begin()+i);
                        w=workersmain[workersmain.size()-1];
                        workersmain.erase(workersmain.begin()+workersmain.size()-1);

                    }
                    workerAvailable=true;
                  
                }
            }
        }
        bool flag=false;
        for(int i=0;i<employees.size();i++)
        {
            if(employees[i].skill==((ConstructionTask*)taskPtr)->skill_req)
            {
                flag=true;
                break;
            }
        }
        if((workersmain.size()==num_workers && workersvirtual.size()==num_workers && !workerAvailable) || !flag)
        {

            cout<<"\n ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ WORKER NOT AVAILABLE ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗";
            cout<<"\n No worker with the required skill is present in the company alloting to first available worker"<<endl;
            cout<<"..................................................................................................\n\n";
            
           
            if(workersmain.size()!=0)
            {

            
                w=workersmain[0];
                workersmain.erase(workersmain.begin());
                workerAvailable=true;
            }
            else
            {
                w=workersvirtual[0];
                workersvirtual.erase(workersvirtual.begin());
                workerAvailable=true;


            }
            
        }
        else if(!workerAvailable)
        {
            cout<<"\n ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ WORKER NOT AVAILABLE ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗";
            cout<<"\n No worker with desired skill available for task "<<((ConstructionTask*)taskPtr)->name<<" Id "<<task->id 
             <<" waiting for "<<task->skill_req<< " to be free"<<endl;
            cout<<"..................................................................................................\n\n";
       

           //  cout<<"\nMain workers are "<<workersmain.size()<<" and virtual workers are "<<workersvirtual.size()<<endl;
            sleep(5);
        }
        pthread_mutex_unlock(&workerMutex);
        
    }
    if(w.efficiency==0)
    {
        cout<<"\n ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ WORKER ON BREAK (NOT AVAILABLE) ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗ ✗";
        cout<<"\nSelected Worker is on a break, task "<<((ConstructionTask*)taskPtr)->name<<" Id "<<task->id <<" waiting for worker to return"<<endl;
        cout<<"..................................................................................................\n\n";
         
        sleep(10);
        w.efficiency=2;
    }
    cout<<"\n 📝   📝   📝   📝  WORKER ASSIGNED TASK  📝   📝   📝   📝 \n";
    cout<<w.name<<" is assigned task "<<((ConstructionTask*)taskPtr)->name<<" Id "<<task->id <<endl;
    cout<<"\n.................................................................................\n\n";


    //mimicing the adverse weather conditions
    if (task->adverseConditions && adverseConditions) 
    {
        //if there are any adverse conditions right now only then the task cannot be done in adverse condition is postponed
        
            cout<<"\n 💧 💧 💧 💧 💧 💧 💧 💧 💧 💧 💧 💧 💧 💧 💧 💧 💧 💧 💧 💧 💧 💧 💧 💧";
            cout << "\nADVERSE WEATHER CONDITIONS DETECTED!!!. TASK '" << task->name << " POSTPONED!!! ⌛⌛⌛⌛ having "<<task->priority_level<<" Priority "<< endl;
            cout<<"\n.............................................................................\n\n";
        // Adjust priorities for postponed tasks
        task->priority_level = "LOW";
        task->priority_num = 10;

        // Push the task to the low priority queue
        pthread_mutex_lock(&taskMutex);
        //task->adverseConditions=false;
        
        LowPriorityPostponedVector.push_back(*task);
        //free the worker
        pthread_mutex_lock(&workerMutex);
        if(workersmain.size()< num_workers)
        {
            workersmain.push_back(w);
        }
        else
        {
            workersvirtual.push_back(w);
        }
        pthread_mutex_unlock(&workerMutex);

        // sortedLowPriorityVector.push_back(*task);
        pthread_mutex_unlock(&taskMutex);
        
       
    } 
    else 
    {


            //waiting until the resources are available in the total amount of resources present on the construction site
            while (!checkResourceAvailability(*task))
            {
                cout<<"\n🕰   🕰   🕰  🕰   🕰   🕰 WAITING FOR RESOURCES   🕰   🕰   🕰   🕰   🕰   🕰\n";   
                cout<<endl<<task->name<<"Id: "<<task->id<<" waiting for resources "<<task->requiredBricks<<" bricks, "<<task->requiredCement<<" ccement "<< task->requiredTools<<" tools ";
                cout<<"\n............................................................................................\n\n";
              sleep(10);
            }
          pthread_mutex_lock(&taskMutex);

            //pthread_mutex_unlock(&taskMutex);
   
        // // Wait for resources to become available
        // sem_wait(&resourcesAvailableSem);
     
        // Resources available, perform the task
        // pthread_mutex_lock(&siteDataMutex);

       // pthread_mutex_lock(&taskMutex);


        
        cout<<"\n  🛠️   🛠️   🛠️    🛠️   🛠️   🛠️    🛠️   🛠️   🛠️    🛠️   🛠️   🛠️     🛠️   🛠️   🛠️   🛠️\n\n";
        cout<<w.name<<" is performing task "<<task->name<<endl;
        cout << "\n=========== PERFORMING NEW TASK: " << task->name <<" Id "<<task->id <<" ============"<< endl;
        cout<<"Priority level \""<<task->priority_level<<"\" with priority number '"<<task->priority_num<<"'"<<endl;
        cout << "Required Resources: " << task->requiredBricks<<" Bricks, " << task->requiredCement<<" Cement Packs, " << task->requiredTools<<" Tools"  << endl;
         time_t arrivalTime = task->arrivalTime;
         //struct of time info secs mins and hours
            struct tm* timeinfo;
            timeinfo = localtime(&arrivalTime);
            cout << "Task '" << task->name << "' arrived at: "
                 << setfill('0') << setw(2) << timeinfo->tm_hour << ":"
                 << setfill('0') << setw(2) << timeinfo->tm_min << ":"
                 << setfill('0') << setw(2) << timeinfo->tm_sec << endl;
        
        cout<<"\n 🛠️   🛠️   🛠️    🛠️   🛠️   🛠️    🛠️   🛠️   🛠️    🛠️   🛠️   🛠️    🛠️   🛠️   🛠️    🛠️   🛠️ \n\n";

        // siteData.totalBricks-= task->requiredBricks;
        // siteData.totalCement-= task->requiredCement;
        // siteData.totalTools-= task->requiredTools;
        // pthread_mutex_unlock(&siteDataMutex);

        

        //task completion time
        sleep(5);
        if(rand()%2==0)
        {

                

                // Task completed // tools can be reused
                pthread_mutex_lock(&siteDataMutex);
                siteData.totalTools+=task->requiredTools;
                pthread_mutex_unlock(&siteDataMutex);

                cout<<"\n✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓  TASK DONE   ✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓\n";
                cout << "Task '"<<task->name<<" Id "<<task->id <<"' Completed. Tools released, Bricks and Cement Packs are used.";
                cout<<"\n✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓\n";
        }
        else
        {
             cout<<"\n**************     TOOLS DEGRADED      ********************\n";
            cout << "Task '"<<task->name<<" Id "<<task->id <<"' Completed. Tools degradation rendered them useless discarding them, Bricks and Cement Packs are used.";
            cout<<"\n*****************************************************\n";

        }
        //add worker back to queue
        pthread_mutex_lock(&workerMutex);
        w.efficiency--;
        if(w.efficiency==0)
        {
            cout<<"\n✓✓✓✓✓✓✓✓✓✓✓✓✓✓ WORKER COMPLETED WORK AND WANTS BREAK ✓✓✓✓✓✓✓✓✓✓✓✓\n";
            cout<<"Worker "<<w.name<<" has completed his work and is taking a break";
            cout<<"\n✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓\n";
            if(workersvirtual.size()<num_workers)
            {
                workersvirtual.push_back(w);
            }
            else
            {
                //swap with the least recently used worker
                worker toswap=workersvirtual[0];
                workersvirtual.erase(workersvirtual.begin());
                workersvirtual.push_back(w);
                workersmain.push_back(toswap);



            }
        }
        else
        {
            cout<<"\n✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓ WORKER COMPLETED WORK ✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓\n";
            cout<<w.name<<" has completed his work and is available for new work";
            cout<<"\n✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓\n";
            if(workersmain.size()<num_workers)
            {
                workersmain.push_back(w);
            }
            else
            {
                //swap with the least recently used worker
                worker toswap=workersmain[0];
                workersmain.erase(workersmain.begin());
                workersmain.push_back(w);
                workersvirtual.push_back(toswap);
            }
        }
        cout<<"\n.................................................................................\n\n";
        cout<<"WORKERS STATE"<<endl;
        cout<<"Main workers are "<<workersmain.size()<<" and virtual workers are "<<workersvirtual.size()<<endl;
        cout<<"Main workers are:\n";
        for(int i=0;i<workersmain.size();i++)
        {
            cout<<workersmain[i].name<<" with skill "<<workersmain[i].skill<<" and skill level "<<workersmain[i].skillLevel<<endl;
        }
        cout<<"BACKUP WORKERS ARE:\n";
        for(int i=0;i<workersvirtual.size();i++)
        {
            cout<<workersvirtual[i].name<<" with skill "<<workersvirtual[i].skill<<" and skill level "<<workersvirtual[i].skillLevel<<endl;
        }
        cout<<"\n.................................................................................\n\n";
        pthread_mutex_unlock(&workerMutex);


         time_t currentTime = time(0);
         
         struct tm* timeinfo1 = localtime(&currentTime);
        cout<<"Finishing Time " << setfill('0') <<setw(2) << timeinfo1->tm_hour << ":"
              <<setfill('0') <<setw(2) << timeinfo1->tm_min << ":"
              <<setfill('0')<<setw(2)<<timeinfo1->tm_sec <<endl;

        done++;
        cout<<"Done tasks: "<<done<<endl;
        pthread_mutex_unlock(&taskMutex);

        sleep(10); 
    }

    pthread_exit(NULL);
}

//function to create and manage threads for construction tasks

void* createTaskThreads(void* args) {
    for(int i=0;i<num_workers;i++)
    {
        worker w;
        w.id=i;
        w.name="Worker "+to_string(i);
        w.skill=skilltype[rand()%skilltype.size()];
        w.skillLevel=rand()%3+1;
        w.efficiency=2;
        workersmain.push_back(w);
        employees.push_back(w);
    }
    for(int i=0;i<num_workers;i++)
    {
        worker w;
        w.id=i;
        w.name="Worker "+to_string(i+num_workers);
        w.skill=skilltype[rand()%skilltype.size()];
        w.skillLevel=rand()%3+1;
        w.efficiency=2;
        workersvirtual.push_back(w);
        employees.push_back(w);
       

    }
    
    cout<<"\n.................. WORKERS ARE READY FOR WORK ..............\n";
    cout<<"WORKERS ARE:\n";
    for(int i=0;i<workersmain.size();i++)
    {
        cout<<workersmain[i].name<<" with skill "<<workersmain[i].skill<<" and skill level "<<workersmain[i].skillLevel<<endl;
    }
    cout<<"BACKUP WORKERS ARE:\n";
    for(int i=0;i<workersvirtual.size();i++)
    {
        cout<<workersvirtual[i].name<<" with skill "<<workersvirtual[i].skill<<" and skill level "<<workersvirtual[i].skillLevel<<endl;
    }
    pthread_t taskThreads[num_tasks];
    ConstructionTask tasks[num_tasks];

    cout<<"\n............... PROJECT PLANNING PHASE HAS STARTED, GET READY FOR WORK ..............\n";
    for (int i = 0; i < num_tasks; i++) 
    {
      
        tasks[i] = generateRandomTask();
        tasks[i].id = i;
        if (tasks[i].priority_level == "HIGH")
        {
            highPriorityQueue.push(tasks[i]);
        } else if (tasks[i].priority_level == "MEDIUM") 
        {
            mediumPriorityQueue.push(tasks[i]);
        } else if (tasks[i].priority_level == "LOW") 
        {
            lowPriorityQueue.push(tasks[i]);
        }
        
    }

    
    auto comparePriority = [](const ConstructionTask& task1, const ConstructionTask& task2) 
    {
        if (task1.priority_num == task2.priority_num) 
        {
            return task1.arrivalTime < task2.arrivalTime;
        }
        return task1.priority_num < task2.priority_num;
    };
    

    while (!highPriorityQueue.empty()) {
        ConstructionTask task = highPriorityQueue.front();
        highPriorityQueue.pop();
        sortedHighPriorityVector.push_back(task);
    }
    sort(sortedHighPriorityVector.begin(), sortedHighPriorityVector.end(), comparePriority);

    while (!mediumPriorityQueue.empty()) {
        ConstructionTask task = mediumPriorityQueue.front();
        mediumPriorityQueue.pop();
        sortedMediumPriorityVector.push_back(task);
    }
    sort(sortedMediumPriorityVector.begin(), sortedMediumPriorityVector.end(), comparePriority);

    while (!lowPriorityQueue.empty()) {
        ConstructionTask task = lowPriorityQueue.front();
        lowPriorityQueue.pop();
        sortedLowPriorityVector.push_back(task);
    }
    sort(sortedLowPriorityVector.begin(), sortedLowPriorityVector.end(), comparePriority);
    cout<<"\n\nPROJECT PLANNING PHASE HAS ENDED \nWORK HAS STARTED..............\n";

    bool doneflag=false;

    while (!doneflag) 
    {
       
        ConstructionTask* currentTask = nullptr;
        pthread_t thread;
        if(pthread_create(&thread,NULL,threadforforking,NULL)!=0)
        {
            cout<<"Error in creating thread"<<endl;
            exit(1);
        }

        pthread_mutex_lock(&taskMutex);


        if (!sortedHighPriorityVector.empty()) {
            currentTask = new ConstructionTask(sortedHighPriorityVector.front()); 
            sortedHighPriorityVector.erase(sortedHighPriorityVector.begin());
        }
        else if (!sortedMediumPriorityVector.empty()) {
            currentTask = new ConstructionTask(sortedMediumPriorityVector.front()); 
            sortedMediumPriorityVector.erase(sortedMediumPriorityVector.begin());
        }
        
        else if (!sortedLowPriorityVector.empty()) {
         currentTask = new ConstructionTask(sortedLowPriorityVector.front()); 
            sortedLowPriorityVector.erase(sortedLowPriorityVector.begin());
        }
   
        else if (!LowPriorityPostponedVector.empty()) 
        {
             
            currentTask = new ConstructionTask(LowPriorityPostponedVector.front());  
            LowPriorityPostponedVector.erase(LowPriorityPostponedVector.begin());
                }


        pthread_mutex_unlock(&taskMutex);

     
        if (currentTask != nullptr) {
            

        
            
            if (pthread_create(&taskThreads[currentTask->id], nullptr, performTask, currentTask) != 0) {
                cout << "Error creating task thread." << endl;
                exit(1);
            }

        }
        if(done==num_tasks)
        {
            doneflag=true;
           cout<<"All tasks done\n"<<endl;
           for(int i=0;i<num_tasks;i++)
           {
                pthread_join(taskThreads[i],NULL);


           }
              cout<<"All tasks joined\n"<<endl;
              cout<<"Exiting the program"<<endl;
              cout<<"Thank you for using our program"<<endl;
             
                
                 
               exit(0); 
        }
        sleep(5);
    }
    

    pthread_exit(NULL);
}

#endif