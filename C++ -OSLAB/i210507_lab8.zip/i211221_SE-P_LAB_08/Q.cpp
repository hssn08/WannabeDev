#include <iostream>
#include <queue>
#include <algorithm>
#include <unistd.h>

using namespace std;

struct Process
{
    int priority;
    int burstTime;
    int arrivalTime;
};

struct ComparePriority
{
    bool operator()(const Process &p1, const Process &p2)
    {
        return p1.priority > p2.priority;
    }
};

bool compareBurstTime(const Process &p1, const Process &p2)
{
    return p1.burstTime < p2.burstTime;
}

double calculate_Average_Waiting_Time(const vector<int> &waitingTimes)
{
    int totalWaitingTime = 0;
    for (int time : waitingTimes)
    {
        totalWaitingTime = totalWaitingTime + time;
    }
    float x = totalWaitingTime / waitingTimes.size();
    
    return x;
}

double priority_Scheduling(const vector<Process> &processes)
{
    priority_queue<Process, vector<Process>, ComparePriority> pq;
    vector<int> waitingTimes(processes.size(), 0);
    int currentTime = 0;
    int completedProcesses = 0;

    while (completedProcesses < processes.size())
    {
        for (int i = 0; i < processes.size(); i++)
        {
            if (processes[i].arrivalTime <= currentTime)
            {
                pq.push(processes[i]);
            }
        }

        if (!pq.empty())
        {
            Process currentProcess = pq.top();
            pq.pop();
            waitingTimes[currentProcess.priority] = waitingTimes[currentProcess.priority] + currentTime - currentProcess.arrivalTime;
            currentTime = currentTime + currentProcess.burstTime;
            completedProcesses++;
        }
        else
        {
            currentTime++;
        }
    }

    return calculate_Average_Waiting_Time(waitingTimes);
}

double srtf_Scheduling(vector<Process> processes)
{
    sort(processes.begin(), processes.end(), compareBurstTime);
    vector<int> waitingTimes(processes.size(), 0);
    int currentTime = 0;
    int completedProcesses = 0;

    while (completedProcesses < processes.size())
    {
        for (int i = 0; i < processes.size(); i++)
        {
            if (processes[i].arrivalTime <= currentTime && processes[i].burstTime > 0)
            {
                Process &currentProcess = processes[i];
                waitingTimes[i] = waitingTimes[i] + currentTime - currentProcess.arrivalTime;
                currentTime = currentTime + currentProcess.burstTime;
                currentProcess.burstTime = 0;
                completedProcesses++;
            }
        }
    }

    return calculate_Average_Waiting_Time(waitingTimes);
}

double multi_level_Feedback_Queue(vector<Process> processes)
{
    queue<Process> foregroundQueue;
    queue<Process> backgroundQueue;
    vector<int> waitingTimes(processes.size(), 0);
    int currentTime = 0;
    int completedProcesses = 0;
    bool isForegroundQueue = true;

    while (completedProcesses < processes.size())
    {
        for (int i = 0; i < processes.size(); i++)
        {
            if (processes[i].arrivalTime <= currentTime)
            {
                if (processes[i].priority < 5)
                {
                    backgroundQueue.push(processes[i]);
                }
                else
                {
                    foregroundQueue.push(processes[i]);
                }
            }
        }

        if (isForegroundQueue)
        {
            if (!foregroundQueue.empty())
            {
                Process currentProcess = foregroundQueue.front();
                foregroundQueue.pop();
                waitingTimes[currentProcess.priority] = waitingTimes[currentProcess.priority] + currentTime - currentProcess.arrivalTime;
                sleep(10);
                currentTime = currentTime + currentProcess.burstTime;
                completedProcesses++;
            }
            else
            {
                isForegroundQueue = false;
            }
        }
        else
        {
            if (!backgroundQueue.empty())
            {
                Process currentProcess = backgroundQueue.front();
                backgroundQueue.pop();
                waitingTimes[currentProcess.priority] = waitingTimes[currentProcess.priority] + currentTime - currentProcess.arrivalTime;
                sleep(3);
                currentTime = currentTime + currentProcess.burstTime;
                completedProcesses++;
            }
            else
            {
                isForegroundQueue = true;
            }
        }
    }

    return calculate_Average_Waiting_Time(waitingTimes);
}

int main()
{
    int numProcesses;
    cout << "Enter the number of processes: ";
    cin >> numProcesses;

    vector<Process> processes(numProcesses);
    cout << "Enter the priority, burst time, and arrival time:\n";
    for (int i = 0; i < numProcesses; i++)
    {
        cout << "Process " << i + 1 << ":\n";
        cout << "Priority: ";
        cin >> processes[i].priority;
        cout << "Burst Time: ";
        cin >> processes[i].burstTime;
        cout << "Arrival Time: ";
        cin >> processes[i].arrivalTime;
    }

    double avg_Waiting_Time;

    avg_Waiting_Time = priority_Scheduling(processes);
    cout << "Average Waiting Time (Priority based scheduling): " << avg_Waiting_Time << endl;

    avg_Waiting_Time = srtf_Scheduling(processes);
    cout << "Average Waiting Time (Shortest Remaining Time First): " << avg_Waiting_Time << endl;

    avg_Waiting_Time = multi_level_Feedback_Queue(processes);
    cout << "Average Waiting Time (Multilevel Feedback Queue): " << avg_Waiting_Time << endl;

    return 0;
}
