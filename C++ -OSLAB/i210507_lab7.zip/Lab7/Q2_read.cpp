#include <unistd.h>
#include <string.h> 
#include <fcntl.h> 
#include <iostream> 
#include<sys/stat.h>

using namespace std ; 

int main(){


char str[256] = "hello_world";
string str2 = "hello world";
int fifo_write ;

fifo_write = open ("pipe_one" ,O_WRONLY | O_RDONLY); 

if ( fifo_write < 0){
     cout<<"Error opening file ";
}
else {
    while(str2.compare ("abort") !=0){ 
        cout<<"Enter text: "<<endl;
        cin>>str2 ;
        write(fifo_write , str2.c_str() , sizeof(str2 )); 
        cout<<"∗"<<str2 <<"∗"<<endl ;
        read(fifo_write , str , sizeof(str )); 
        cout<<"Text: "<<str<<endl;
}
close(fifo_write);

}

}
