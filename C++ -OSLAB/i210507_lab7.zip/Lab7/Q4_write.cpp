#include <unistd.h>
#include <string.h> 
#include <fcntl.h> 
#include <iostream> 
#include<sys/stat.h>

using namespace std ; 

int main(){
string str = "hello world";
int fifo_write ;

fifo_write = open ("pipe_one" ,O_WRONLY ); 

if ( fifo_write < 0){
     cout<<"Error opening file ";
}
else {
        write(fifo_write , str.c_str() , sizeof(str )); 
        cout<<"∗"<<str <<"∗"<<endl ;
close(fifo_write);
}
}
