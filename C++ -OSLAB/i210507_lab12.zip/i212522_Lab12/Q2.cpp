#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>

using namespace std;

mutex mtx;
condition_variable cv;
bool req1_completed = false;
bool req2_completed = false;

void process_request(int id, int delay, bool isReq1) {
    unique_lock<mutex> lock(mtx);
    
    if (isReq1) {
        cv.wait(lock, [] { return req2_completed; });
    } else {
        cv.wait(lock, [] { return req1_completed; });
    }

    // Simulate processing
    this_thread::sleep_for(chrono::milliseconds(delay));

    if (isReq1) {
        req1_completed = true;
        cout << "Request 1 completed by User " << id << endl;
    } else {
        req2_completed = true;
        cout << "Request 2 completed by User " << id << endl;
    }

    cv.notify_all();
}

int main() {
    thread user1(process_request, 1, 2000, true); // Request 1
    thread user2(process_request, 2, 1500, false); // Request 2

    user1.join();
    user2.join();

    return 0;
}
