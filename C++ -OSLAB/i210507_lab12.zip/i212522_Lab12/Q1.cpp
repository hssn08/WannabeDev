
#include <iostream>

using namespace std;

const int MAX_PROCESS = 3;
const int MAX_RESOURCE = 3;

int available[MAX_RESOURCE] = {3, 3, 2};
int maximum[MAX_PROCESS][MAX_RESOURCE] = {
    {7, 5, 3},
    {3, 2, 2},
    {9, 0, 2}
};
int allocation[MAX_PROCESS][MAX_RESOURCE] = {
    {0, 1, 0},
    {2, 0, 0},
    {3, 0, 2}
};
int need[MAX_PROCESS][MAX_RESOURCE] = {0};
bool finish[MAX_PROCESS] = {false};

bool isSafe(int process, int work[MAX_RESOURCE]) {
    for (int i = 0; i < MAX_RESOURCE; ++i) {
        if (need[process][i] > work[i])
            return false;
    }
    return true;
}

bool bankersAlgorithm() {
    int work[MAX_RESOURCE];
    for (int i = 0; i < MAX_RESOURCE; ++i) {
        work[i] = available[i];
    }

    int safeSequence[MAX_PROCESS];
    int safeSeqIndex = 0;

    for (int step = 0; step < MAX_PROCESS; ++step) {
        bool found = false;
        for (int i = 0; i < MAX_PROCESS; ++i) {
            if (!finish[i] && isSafe(i, work)) {
                for (int j = 0; j < MAX_RESOURCE; ++j)
                    work[j] += allocation[i][j];

                safeSequence[safeSeqIndex++] = i;
                finish[i] = true;
                found = true;
            }
        }

        if (!found)
            return false; // No safe sequence found
    }

    cout << "Safe sequence: ";
    for (int i = 0; i < MAX_PROCESS; ++i)
        cout << "P" << safeSequence[i] << " ";

    return true;
}

int main() {
    // Calculate the need matrix
    for (int i = 0; i < MAX_PROCESS; ++i) {
        for (int j = 0; j < MAX_RESOURCE; ++j) {
            need[i][j] = maximum[i][j] - allocation[i][j];
        }
    }

    if (bankersAlgorithm())
        cout << "\nThe system is in a safe state.\n";
    else
        cout << "\nThe system is in an unsafe state.\n";

    return 0;
}




	

