#include <iostream> 
#include <pthread.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <string.h>
using namespace std;

struct Patient {
    int id;
    string name;
};

Patient patients[10];

struct Doctor {
    int id;
    string name;
};

Doctor doctors[10];

struct Appointment {
    int patientID;
    int doctorID;
    int time;
};

Appointment appointments[10];

// Mutexes
pthread_mutex_t appointmentMutex;
pthread_mutex_t patientMutex;

void checkAvailability(Appointment app){
	for(int i =0; i < 10; i++){
		if(appointments[i].time == app.time && appointments[i].doctorID == app.doctorID){
			cout << "There is already an appointment scheduled with the doctor. Please choose another slot" << endl;
			app.time = 0;
			app.doctorID = 0;
			return;
		} else {
			cout << "Empty slot found. Adding Appointment..." << endl;
			pthread_mutex_lock(&appointmentMutex);
			appointments[i].patientID = app.patientID;
			appointments[i].doctorID = app.doctorID;
			appointments[i].time = app.time;
			pthread_mutex_unlock(&appointmentMutex);
			return;
		}
	}
}

void findAppointment(Appointment app){
	for(int i =0; i < 10; i++){
		if(appointments[i].time == app.time && appointments[i].doctorID == app.doctorID){
			cout << "Appointment found. Cancelling slot..." << endl;
			pthread_mutex_lock(&appointmentMutex);
			appointments[i].patientID = 0;
			appointments[i].doctorID = 0;
			appointments[i].time = 0;
			pthread_mutex_unlock(&appointmentMutex);
			cout << "Appointment successfully cancelled!" << endl;
			return;
		} else {
			continue;
		}
	}
	cout << "Couldn't find appointment" << endl;
	return;
}

void* cancelAppointment(void* args){ 
	Appointment app;
	cout << "Enter Patient ID: ";
	cin >> app.patientID;
	cout << "Enter Doctor ID: ";
	cin >> app.doctorID;
	cout << "Enter time: ";
	cin >> app.time;
	findAppointment(app);
	return args;
}

void* addAppointment(void* args){ // Appointment Scheduling Algorithm = FCFS
	Appointment app;
	cout << "Enter Patient ID: ";
	cin >> app.patientID;
	cout << "Enter Doctor ID: ";
	cin >> app.doctorID;
	cout << "Enter time: ";
	cin >> app.time;
	checkAvailability(app);
	cout << "Appointment successfully added!" << endl;
	return args;
}

void* registerPatient(void* args){
	Patient patient;
	int id;
	string name;
	cout << "Enter Patient ID: ";
	cin >> id;
	cout << "Enter Patient Name: ";
	cin >> name;
	
	pthread_mutex_lock(&patientMutex);
	patient.id = id;
	patient.name = name;
	pthread_mutex_unlock(&patientMutex);
	
	cout << "Patient Registered Successfully" << endl;
	return args;
}


int main(){
    cout << "~~~~~~~~ Welcome to Hospital Management System ~~~~~~~~" << endl;
    cout << "1. Register new patient " << endl;
    cout << "2. Create Appointment " << endl;
    cout << "3. Cancel Appointment " << endl;
    cout << "0. Exit " << endl;
    pthread_t registerThread; // Thread for registering users
    pthread_t appointmentThread; // Thread for appointments
    pthread_mutex_t userMutex; // Mutex for User Interface
    int choice;
    cin >> choice;
    while(choice != 0){
    	switch(choice){
	    	case 1: {
	    	pthread_mutex_lock(&userMutex);
	    		pthread_create (&registerThread, NULL, &registerPatient, NULL);
	    		pthread_join(registerThread, NULL);
	    	pthread_mutex_unlock(&userMutex);
	    	}
	    	break;
	    	case 2: {
	    	pthread_mutex_lock(&userMutex);
	    		pthread_create (&appointmentThread, NULL, &addAppointment, NULL);
	    		pthread_join(appointmentThread, NULL);
	    	pthread_mutex_unlock(&userMutex);
	    	}
	    	break;
	    	case 3: {
	    	pthread_mutex_lock(&userMutex);
	    		pthread_create (&appointmentThread, NULL, &cancelAppointment, NULL);
	    		pthread_join(appointmentThread, NULL);
	    	pthread_mutex_unlock(&userMutex);
	    	}
	    	break;
	    	
	}
	    cout << "~~~~~~~~ Welcome to Hospital Management System ~~~~~~~~" << endl;
	    cout << "1. Register new patient " << endl;
	    cout << "2. Create Appointment " << endl;
	    cout << "3. Cancel Appointment " << endl;
	    cout << "0. Exit " << endl;
	    cin >> choice;
    }
    return 0;
}
