
echo "Enter Segments"
read segments

echo "Enter height"
read height


for{(int i =0; i < segments; i++)}
    do
        for {(int j = 0; j < height; j++)}
            do
                echo *
			
            done
            
    done

