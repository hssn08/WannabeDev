#include <iostream>
#include <vector>
#include <thread>

using namespace std;

void multiply(const vector<vector<int>> &A, const vector<vector<int>> &B, vector<vector<int>> &C, int startRow, int endRow)
{
    int colsA = A[0].size();
    int colsB = B[0].size();

    for (int i = startRow; i < endRow; i++)
    {
        for (int j = 0; j < colsB; j++)
        {
            C[i][j] = 0;
            for (int k = 0; k < colsA; k++)
            {
                C[i][j] += ( A[i][k] * B[k][j] );
            }
        }
    }
}

void printMatrix(const vector<vector<int>> &matrix)
{
    for (const auto &row : matrix)
    {
        for (int element : row)
        {
            cout << element << " ";
        }
        cout << endl;
    }
}

int main()
{
    int rowsA, colsA, rowsB, colsB;
    cout << "Enter the Rows of matrix A: ";
    cin >> rowsA;
    cout << "Enter the Coloumns of matrix A:";
    cin >> colsA;
    cout << "Enter the Rows of matrix B: ";
    cin >> rowsB;
    cout << "Enter the Coloumns of matrix B:";
    cin >> colsB;

    if (colsA != rowsB)
    {
        cout << "Error: The number of columns in matrix A must be equal to the number of rows in matrix B." << endl;
        return 0;
    }

    vector<vector<int>> A(rowsA, vector<int>(colsA));
    vector<vector<int>> B(rowsB, vector<int>(colsB));
    vector<vector<int>> C(rowsA, vector<int>(colsB));

    cout << "Enter the elements of matrix A:" << endl;
    for (int i = 0; i < rowsA; i++)
    {
        for (int j = 0; j < colsA; j++)
        {
            cin >> A[i][j];
        }
    }

    cout << "Enter the elements of matrix B:" << endl;
    for (int i = 0; i < rowsB; i++)
    {
        for (int j = 0; j < colsB; j++)
        {
            cin >> B[i][j];
        }
    }

    int numThreads = 2;
    vector<thread> threads;

    int rowsPerThread = rowsA / numThreads;
    int startRow = 0;
    int endRow = rowsPerThread;

    for (int i = 0; i < numThreads; i++)
    {
        if (i == numThreads - 1)
        {
            endRow = rowsA;
        }
        threads.emplace_back(multiply, ref(A), ref(B), ref(C), startRow, endRow);
        startRow = endRow;
        endRow += rowsPerThread;
    }

    for (auto &thread : threads)
    {
        thread.join();
    }

    cout << "Result matrix C:" << endl;
    printMatrix(C);

    return 0;
}
