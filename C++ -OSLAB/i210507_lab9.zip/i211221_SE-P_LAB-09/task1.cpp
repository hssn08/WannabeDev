#include <iostream>
#include <thread>
#include <chrono>
#include <vector>
#include <unistd.h>

using namespace std;

void executeThread(int threadNum)
{
    cout << "I am thread No. " << threadNum << " with thread id " << this_thread::get_id() << "." << endl;
}

void createThreads(int N)
{
    cout << "Creating " << N << " threads" << endl;
    vector<thread> threads;

    for (int i = 1; i <= N; i++)
    {
        threads.emplace_back(executeThread, i);
    }

    for (int i = 1; i <= (N / 4) + 1; i++)
    {
        sleep(1);
        cout << "\nAfter " << i << " second(s)" << endl;
        for (int j = i; j <= N; j += (N / 4) + 1)
        {
            if (j <= N)
            {
                threads[j - 1].join();
                cout << "\nI am thread No. " << j << " with thread id " << this_thread::get_id() << endl;
            }
        }
    }
    cout << "\nMain was waiting for the threads and is now terminating...." << endl;
}

int main()
{
    int number;
    cout << "Enter Number of threads: ";
    cin >> number;
    createThreads(number);

    return 0;
}
