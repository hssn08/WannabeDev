#include <iostream>
using namespace std;
#include <cstdlib>
#include <pthread.h>
#include "struct.h"
#include "func.h"
#define MATRIX_SIZE 9
int uniqueMatrix[MATRIX_SIZE][MATRIX_SIZE];

int main() {
    // Call the function to generate a unique matrix
    generateUniqueMatrix();

    pthread_t rowThreads[MATRIX_SIZE];
    ThreadInfo rowInfo[MATRIX_SIZE];

    for (int i = 0; i < MATRIX_SIZE; ++i) {
        rowInfo[i].array = uniqueMatrix[i];
        rowInfo[i].size = MATRIX_SIZE;
        pthread_create(&rowThreads[i], NULL, checkRepetition, (void*)&rowInfo[i]);
    }
cout<<"\nThese Rows have Repeating Values\n";
    for (int i = 0; i < MATRIX_SIZE; ++i) {
        pthread_join(rowThreads[i], NULL);
        if (rowInfo[i].result == 1) {
            cout << "Row " << i << ".\n";
        }
    }

    pthread_t colThreads[MATRIX_SIZE];
    ThreadInfo colInfo[MATRIX_SIZE];

    for (int j = 0; j < MATRIX_SIZE; ++j) {
        int column[MATRIX_SIZE];
        for (int i = 0; i < MATRIX_SIZE; ++i) {
            column[i] = uniqueMatrix[i][j];
        }
        colInfo[j].array = column;
        colInfo[j].size = MATRIX_SIZE;
        pthread_create(&colThreads[j], NULL, checkRepetition, (void*)&colInfo[j]);
    }
cout<<"\nThese Columns have Repeating Values\n";
    for (int j = 0; j < MATRIX_SIZE; ++j) {
        pthread_join(colThreads[j], NULL);
        if (colInfo[j].result == 1) {
            cout << "Column " << j << ".\n";
        }
    }

    cout << "All threads have completed their checks.\n";

    return 0;
}
