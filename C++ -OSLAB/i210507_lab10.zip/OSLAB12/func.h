#pragma once
#include "lab12.cpp"
int uniqueMatrix[MATRIX_SIZE][MATRIX_SIZE];
void* checkRepetition(void* arg) {
    ThreadInfo* info = static_cast<ThreadInfo*>(arg);
    int* array = info->array;
    int size = info->size;

    int occurrences[MATRIX_SIZE + 1] = {0};

    for (int i = 0; i < size; ++i) {
        int value = array[i];
        if (occurrences[value] > 0) {
            info->result = 1;
            pthread_exit(NULL);
        } else {
            occurrences[value]++;
        }
    }

    info->result = 0;
    pthread_exit(NULL);
}

// Function to initialize the matrix with random values
void generateUniqueMatrix() {
    srand(time(NULL));

    for (int i = 0; i < MATRIX_SIZE; ++i) {
        for (int j = 0; j < MATRIX_SIZE; ++j) {
            uniqueMatrix[i][j] = rand() % 10;
        }
    }
}
