#pragma once

struct ThreadInfo {
    int* array;
    int size;
    int result;
};
