please follow this pattern for input in test cases:-
0
0
0
0
0
5000
0
0
Abdul Samie
aaaaaaa@mail.com
islamabad
1
6000
797550
1