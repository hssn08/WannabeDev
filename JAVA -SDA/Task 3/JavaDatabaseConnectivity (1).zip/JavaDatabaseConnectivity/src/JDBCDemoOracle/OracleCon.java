package JDBCDemoOracle;

import java.sql.*;  
	class OracleCon { 
		
		public static void main(String args[]) {  
			try
			{  
			//step1 load the driver class  
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			  
			System.out.println("Driver Loaded Successfully!");

			//step2 create  the connection object  
			Connection con=DriverManager.getConnection(  
					"jdbc:oracle:thin:@127.0.0.1:1521:xe","system","tiger12345"); 
			
			System.out.println("Connection Established!");

			//step3 create the statement object  
			Statement stmt=con.createStatement();  
			 
			//step4 execute query  
			ResultSet rs=stmt.executeQuery("select * from STUDENT");  
			
			while(rs.next())  
			{
		    int id = rs.getInt(1);
		    String firstName = rs.getString("first_name"); // by column name matching
		    String lastName = rs.getString("last_name");
					
			System.out.println(id+"  "+firstName+"  "+lastName);  
			}
			//step5 close the connection object  
			con.close();  
			
			
			}
			catch(ClassNotFoundException e){ 
				
				System.out.println("Driver Not Loaded");
				
			} catch (SQLException e) {
				
				System.out.println("Connection is not Established!");

			}  
			  
	}  
}  
	
	
	
	
	