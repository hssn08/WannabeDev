package JDBCDemoOracle;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class UpdateRecord {

	
	public static void main(String args[]) {  
		try
		{  
		//step1 load the driver class  
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		  
		System.out.println("Driver Loaded Successfully!");

		//step2 create  the connection object  
		Connection con=DriverManager.getConnection(  
				"jdbc:oracle:thin:@127.0.0.1:1521:xe","system","tiger12345"); 
		
		System.out.println("Connection Established!");

		
		String sql = "UPDATE Student SET student_id =?, first_name=?, last_name=? WHERE first_name=?";
		 
		PreparedStatement statement = con.prepareStatement(sql);
			statement.setInt(1, 1200);
			statement.setString(2, "Bill");
			statement.setString(3, "Gates");
			statement.setString(4, "bill");

		int rowsUpdated = statement.executeUpdate();
		if (rowsUpdated > 0) {
		    System.out.println("An existing user was updated successfully!");
		}
			
		//step5 close the connection object  
		con.close();  
		
		 
		}
		catch(ClassNotFoundException e){ 
			
			System.out.println("Driver Not Loaded");
			
		} catch (SQLException e) {
			
			System.out.println(e.getMessage());

		}  
		  
}  
}  





