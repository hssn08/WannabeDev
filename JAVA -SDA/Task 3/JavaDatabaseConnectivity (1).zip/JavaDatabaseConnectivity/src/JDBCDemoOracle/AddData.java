package JDBCDemoOracle;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class AddData {


	public static void main(String args[]) {  
		try
		{  
		//step1 load the driver class  
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		  
		System.out.println("Driver Loaded Successfully!");

		//step2 create  the connection object  
		Connection con=DriverManager.getConnection(  
				"jdbc:oracle:thin:@127.0.0.1:1521:xe","system","tiger12345"); 
		
		System.out.println("Connection Established!");

		
		String sql = "INSERT INTO Student (student_id , first_name ,last_name) VALUES (?, ?, ?)";
		 
		PreparedStatement statement = con.prepareStatement(sql);
		statement.setInt(1, 1200);
		statement.setString(2, "bill");
		statement.setString(3, "Gates");
		 
		int rowsInserted = statement.executeUpdate();
		if (rowsInserted > 0) {
		    System.out.println("A new student was inserted successfully!");
		}	
		
		//step close the connection object  
		con.close();  
		
		 
		}
		catch(ClassNotFoundException e){ 
			
			System.out.println("Driver Not Loaded");
			
		} catch (SQLException e) {
			
			System.out.println(e.getMessage());

		}  
		  
}  
}  




