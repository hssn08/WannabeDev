package BusinessLogic;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import DataBase.Connectivity;
public class Donor extends User 
{
	public Donor()
	{
		super();
	}
	public Donor(String userID, String username,String email, String password, String phone, String address, Date dateOfBirth,Medical_information medicalInfo)
	{
		super(userID, username, email, password, phone, address, dateOfBirth,medicalInfo);
		if(Connectivity.doesDonorExist(userID, "Donor")==false)
		{
		Connectivity.storeUserDetails(userID,username,email,password,phone,address,dateOfBirth,medicalInfo.getBloodType(), medicalInfo.getWeight(), medicalInfo.getlasttransfusion(), medicalInfo.getHasAllergies(),"Donor");
		}
	}
	@Override
	public void displayInfo() {
		// TODO Auto-generated method stub
		
	}
	public Boolean loginDonor(String username,String password)
	{
		if(Connectivity.Checklogin(username,password,"Donor")==true)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
	public String PrintAllDonor()
	{
		
		return Connectivity.PrintAll("Donor");
	}
	public Boolean DeleteDonor(String userID)
	{
		
		return Connectivity.DeleteUser(userID,"Donor");
	}
	public String SearchDonor(String userID)
	{
		return Connectivity.SearchUser(userID,"Donor");
	}
	public Date getDonorLastDonationDate(String username)
	{
        return Connectivity.getDonorLastDonationDate(username);
	}
	public String getDonorID(String username)
	{
        return Connectivity.getDonorID(username);
	}
	public Boolean GetEligibility(String username)
	{
		

        Date currentDate = new Date();
        long differenceInMillis = currentDate.getTime() - Connectivity.getDonorLastDonationDate(username).getTime();

        
        long daysDifference = TimeUnit.DAYS.convert(differenceInMillis, TimeUnit.MILLISECONDS); 
        
        if(daysDifference>60)
        {
        	
        	return true;
        }
        else
        {
        	return false;
        }
	}
	public static void bookDonationAppointment(String userID, String hname, Date appointmentDate)
	{
	    Connectivity.storeDonationAppointment(userID,"", hname, appointmentDate);
	    Connectivity.updateLastTransfusionDate(userID, appointmentDate);
	}
	
	public String GetAppointmentsByUsername(String username)
	{
		return Connectivity.getDonationAppointmentDetails(Connectivity.getUserIdFromUsername(username));
	}
}
