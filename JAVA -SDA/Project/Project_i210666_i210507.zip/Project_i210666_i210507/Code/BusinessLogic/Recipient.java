package BusinessLogic;

import java.util.Date;

import DataBase.Connectivity;

public class Recipient extends User 
{
	public Recipient()
	{
		super();
	}
	public Recipient(String userID, String username,String email, String password, String phone, String address, Date dateOfBirth,Medical_information medicalInfo)
	{
		super(userID, username, email, password, phone, address, dateOfBirth,medicalInfo);
		Connectivity.storeUserDetails(userID,username,email,password,phone,address,dateOfBirth,medicalInfo.getBloodType(), medicalInfo.getWeight(), medicalInfo.getlasttransfusion(), medicalInfo.getHasAllergies(),"Recipient");
	}
	@Override
	public void displayInfo() {
		// TODO Auto-generated method stub
		
	}
	
	public Boolean login(String username,String password)
	{
		if(Connectivity.Checklogin(username,password,"Recipient")==true)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
	public String PrintAllRecipient()
	{
		System.out.println("All Recipient:");
		return Connectivity.PrintAll("Recipient");
	}
	public Boolean DeleteRecipient(String userID)
	{
		
		return Connectivity.DeleteUser(userID,"Recipient");
	}
	public String SearchRecipient(String userID)
	{
		
		return Connectivity.SearchUser(userID,"Recipient");
	}
	
	String findNearbyRecipient(String hospital,String type)
    {
    	return Connectivity.findNearbyRecipients(hospital,type);
    }
	public String GetAppointmentsByUsername(String userID)
	{
		System.out.println(userID);
		//System.out.println(Connectivity.RgetUserIdFromUsername(userID));
		return Connectivity.getDonationAppointmentsByRecipientID(userID);
	}
}