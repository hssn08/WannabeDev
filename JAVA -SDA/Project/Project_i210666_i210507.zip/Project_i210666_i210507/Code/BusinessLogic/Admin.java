package BusinessLogic;
import java.util.Date;
import DataBase.Connectivity;
class Admin extends User 
{
	public Admin()
	{
		super();
	}
	public Admin(String userID, String username,String email, String password, String phone, String address, Date dateOfBirth,Medical_information medicalInfo)
	{
		super(userID, username, email, password, phone, address, dateOfBirth,medicalInfo);
	}
	@Override
	public void displayInfo() {
		// TODO Auto-generated method stub
		
	}
	public Boolean loginAdmin(String username,String password)
	{
		if(Connectivity.Checklogin(username,password,"Admin")==true)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}

}
