package BusinessLogic;
import java.util.*;

import DataBase.Connectivity;

public abstract class User 
{
	private String userID;
	private String username;
    private String email;
    private String password;
    private String phone;
    private String address;
    private Date dateOfBirth;
    private Medical_information medicalInfo;

    // Constructor
    public User() {}
    public User(String userID, String username,String email, String password, String phone, String address, Date dateOfBirth,Medical_information medicalInfo) {
    	this.userID=userID;
    	this.username=username;
    	this.email=email;
    	this.password=password;
    	this.phone=phone;
    	this.address=address;
    	this.dateOfBirth=dateOfBirth;
    	this.medicalInfo=medicalInfo;

    }

    // Abstract method to be implemented by subclasses
    public abstract void displayInfo();

    // Getter methods
    public static Boolean ResetPassword(String username, String OldPassword, String NewPassowrd,String Type)
    {
    	return Connectivity.resetPassword(username, OldPassword, NewPassowrd, Type);
    }
    public String getUserID() {
        return userID;
    }
    public String getUsername() {
        return username;
    }
    public String getEmail() {
        return email;
    }
    public String getpassword() {
        return password;
    }
    public String getPhone() {
        return phone;
    }
    public String getAddress() {
        return address;
    }
    public Date getDateOfBirth() {
        return dateOfBirth;
    }
    public Medical_information getmedicalInfo() {
        return medicalInfo;
    }
    
}
