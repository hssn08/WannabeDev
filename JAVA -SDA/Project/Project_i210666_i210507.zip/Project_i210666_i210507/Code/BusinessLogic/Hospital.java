package BusinessLogic;
import DataBase.Connectivity;


public class Hospital {
	private String registrationNumber;
    private String name;
    private Location location;
    private Inventory inventory;
    
    public Hospital() {}
    public Hospital(String registrationNumber, String name, Location location) {
        this.registrationNumber = registrationNumber;
        this.name = name;
        this.location = location;
        this.inventory = new Inventory();
    }

    // Getters and Setters for attributes

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public Inventory getInventory() {
        return inventory;
    }
    void printHospitalInfo()
    {
    	Connectivity.printAllHospitals();
    }
    String PrintAllHospitalsDetails()
    {
    	return Connectivity.printAllHosOption();
    }
    String findNearbyHospital(String hospital,String type)
    {
    	return Connectivity.findNearbyHospitals(hospital,type);
    }
    void HospitalOption(String hospital,String type)
    {
    	Connectivity.HospitalsOption(hospital,type);
    }
    // Nested class for Location
    public static class Location {
        private String city;
        private String state;
        private String country;

        public Location(String city, String state, String country) {
            this.city = city;
            this.state = state;
            this.country = country;
        }

        // Getters and Setters for Location attributes

        public String getCity() {
            return city;
        }

        public void setCity(String city) {
            this.city = city;
        }

        public String getState() {
            return state;
        }

        public void setState(String state) {
            this.state = state;
        }

        public String getCountry() {
            return country;
        }

        public void setCountry(String country) {
            this.country = country;
        }
    }


    public static class Inventory {
        private BloodEntry[] bloodEntries;

        public Inventory() {
            // Initialize the array or use a dynamic collection as needed
            this.bloodEntries = new BloodEntry[BloodType.values().length];

            // Initialize each entry in the array
            for (int i = 0; i < bloodEntries.length; i++) {
                bloodEntries[i] = new BloodEntry(BloodType.values()[i], 0);
            }
        }

        // Getters and Setters for Inventory attributes

        public BloodEntry[] getBloodEntries() {
            return bloodEntries;
        }

        public void setBloodEntries(BloodEntry[] bloodEntries) {
            this.bloodEntries = bloodEntries;
        }

        // Add a method to update blood quantity for a specific blood type
        public void updateBloodQuantity(BloodType bloodType, int quantity) {
            for (BloodEntry entry : bloodEntries) {
                if (entry.getBloodType() == bloodType) {
                    entry.setQuantity(quantity);
                    return;
                }
            }
        }
    }

    public static class BloodEntry {
        private BloodType bloodType;
        private int quantity;

        public BloodEntry(BloodType bloodType, int quantity) {
            this.bloodType = bloodType;
            this.quantity = quantity;
        }

        // Getters and Setters for BloodEntry attributes

        public BloodType getBloodType() {
            return bloodType;
        }

        public void setBloodType(BloodType bloodType) {
            this.bloodType = bloodType;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }
    }

    public enum BloodType {
        A_POSITIVE,
        A_NEGATIVE,
        B_POSITIVE,
        B_NEGATIVE,
        O_POSITIVE,
        O_NEGATIVE,
        AB_POSITIVE,
        AB_NEGATIVE
        // Add more blood types as needed
    }
}