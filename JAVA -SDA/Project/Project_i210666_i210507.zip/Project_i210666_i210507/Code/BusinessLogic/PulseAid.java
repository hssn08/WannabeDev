package BusinessLogic;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import DataBase.Connectivity;
import org.bson.Document;

import java.util.*;
public class PulseAid 
{
	public static void main(String[] args)
	{
		
		Donor donor;
		Recipient recipient;
        System.out.println("welcome pulse Aid\n");
        System.out.println("1. Login\n2. Register\n");
        Scanner scanner = new Scanner(System.in);
        
        int num = scanner.nextInt();
        if(num==1)
        {
            System.out.println("1. Donor\n2. Recipient\n3. Admin");
            num = scanner.nextInt();
            if(num==1)
            {
            	
            	Scanner scanner0 = new Scanner(System.in);
            	int attempts = 3;
            	Donor LDonor=new Donor();
                while (attempts > 0) {
                    // Prompt for User name and password
                    System.out.print("Enter username: ");
                    String username = scanner0.nextLine();
                    System.out.print("Enter password: ");
                    String password = scanner0.nextLine();

                    // Check if the user exists in the MongoDB collection
                    
                    if (LDonor.loginDonor(username,password)==true)
                     {
                        System.out.println("Login successful!");
                        System.out.println("1.Find near By Hospital\n2.Find near By BloodCenter\n3.Donate Blood\n4.Update Medical Information\n5.respond to Request\n6.Reset Password\n7.Set Availability Status\n8. Delete Account");
                        scanner = new Scanner(System.in);
                        num = scanner.nextInt();
                        if(num==1)
                        {
                        	System.out.print("Enter your city: ");
                            String city = scanner0.nextLine();
                            Hospital hospital = new Hospital();
                        	hospital.findNearbyHospital(city,"Hospital");
                        }
                        else if(num==2)
                        {
                        	System.out.print("Enter your city: ");
                            String city = scanner0.nextLine();
                            Hospital hospital = new Hospital();
                        	hospital.findNearbyHospital(city,"Blood Center");
                        }
                        else if(num==3)
                        {
                        	System.out.print("Want to donote to Hospital/Blood Center/Direct to Recipient ");
                        	scanner = new Scanner(System.in);
                            num = scanner.nextInt();
                            if(num==1)
                            {
                            	Donor ldonor=new Donor();
                            	System.out.println("Eligibility Status: " + ldonor.GetEligibility(username));
                            	if(ldonor.GetEligibility(username))
                            	{
                            		BloodDonation bloodDonation=new BloodDonation();
                            		System.out.print("Enter your city: ");
                                    String city = scanner0.nextLine();
                                    Hospital hospital = new Hospital();
                                	hospital.HospitalOption(city,"Hospital");
                                	System.out.println("Select a hospital to donate blood by writing Registration No:");
                                	String hospitalID = scanner.next();
                                	System.out.print("Enter the donation date (yyyy-MM-dd): ");
                                    String dateString = scanner.next();
                                    Date selectedDate = parseDate(dateString);
                                    bloodDonation.bookDonationAppointment(ldonor.getDonorID(username),hospitalID,selectedDate);
                            	}
                            	else 
                            	{
                                	System.out.println("Sorry you are not Eligible");

                            		break; 
                            	}
                            }
                        }
                        else if(num==4)
                        {
                        	System.out.println("What do you want to update?\n1.Last Donation Date\n2.Update Alergy");
                        	scanner = new Scanner(System.in);
                            num = scanner.nextInt();
                            if(num==1)
                            {
                            	System.out.print("Enter the updated donation date (yyyy-MM-dd): ");
                                String dateString = scanner.next();
                                Date selectedDate = parseDate(dateString);
                            }
                        }
                        else if(num==5)
                        {
                        	
                        }
                        else if(num==7)
                        {
                        	
                        }
                        else if(num==8)
                        {
                        	
                        }
                        break;
                    } else {
                        System.out.println("Invalid username or password. Attempts left: " + (--attempts));
                    }
                }

                if (attempts == 0) {
                    System.out.println("Exceeded maximum login attempts. Account locked.");
                }
            }
            else if(num==2)
            	{
            	
            	Scanner scanner0 = new Scanner(System.in);
            	int attempts = 3;
            	Recipient LRecipient=new Recipient();
                while (attempts > 0) {
                    // Prompt for User name and password
                    System.out.print("Enter username: ");
                    String username = scanner0.nextLine();
                    System.out.print("Enter password: ");
                    String password = scanner0.nextLine();

                    // Check if the user exists in the MongoDB collection
                    
                    if (LRecipient.login(username,password)==true)
                     {
                        System.out.println("Login successful!");
                        System.out.println("1.Find near By Hospital\n2.Find near By BloodCenter\n3.Need Blood\n4.Update Medical Information\n5.Request for blood\n6.Reset Password\n7.Rate and review donor\n8.Delete Account\n9.Search Donor1");

                        break;
                    } else {
                        System.out.println("Invalid username or password. Attempts left: " + (--attempts));
                    }
                }

                if (attempts == 0) {
                    System.out.println("Exceeded maximum login attempts. Account locked.");
                }
            }
            else if(num==3)
        	{
        	
        	Scanner scanner0 = new Scanner(System.in);
        	int attempts = 3;
        	Admin ladmin=new Admin();
            while (attempts > 0) {
                // Prompt for User name and password
                System.out.print("Enter username: ");
                String username = scanner0.nextLine();
                System.out.print("Enter password: ");
                String password = scanner0.nextLine();

                // Check if the user exists in the MongoDB collection
                
                if (ladmin.loginAdmin(username,password)==true)
                 {
                    System.out.println("Login successful!");
                    System.out.println("1.See All donor\n2.See All Recipient\n3.See All Hospital\n4.Add Hospital\n5.Add Recipient\n6.Remove Donor\n7.Remove Recipient\n8.Search Donor\n9.Search Recipient\n10.View All donations");
                    //////////Condition for admin
                    scanner = new Scanner(System.in);
                    num = scanner.nextInt();
                    if(num==1)
                    {
                    	Donor Alldonor=new Donor();
                    	Alldonor.PrintAllDonor();
                    }
                    else if(num==2)
                    {
                    	Recipient Allrecipient=new Recipient();
                    	Allrecipient.PrintAllRecipient();
                    }
                    else if(num==3)
                    {
                    	Hospital hospital = new Hospital();
                    	hospital.printHospitalInfo();
                    }
                    else if(num==4)
                    {
                    	Hospital hospital;
                    	scanner = new Scanner(System.in);

                        System.out.print("Enter hospital registration number: ");
                        String registrationNumber = scanner.nextLine();

                        System.out.print("Enter hospital name: ");
                        String name = scanner.nextLine();

                        System.out.print("Enter hospital city: ");
                        String city = scanner.nextLine();

                        System.out.print("Enter hospital state: ");
                        String state = scanner.nextLine();

                        System.out.print("Enter hospital country: ");
                        String country = scanner.nextLine();

                        hospital = new Hospital(registrationNumber, name,new Hospital.Location(city, state, country));
                     // Get blood quantities for all blood types from the user
                        for (Hospital.BloodEntry entry : hospital.getInventory().getBloodEntries()) {
                            System.out.print("Enter blood quantity for " + entry.getBloodType() + ": ");
                            int quantity = scanner.nextInt();
                            entry.setQuantity(quantity);
                        }
                        Connectivity.storeHospitalData(hospital);
                    }
                    else if(num==5)
                    {
                    	Scanner scanner1 = new Scanner(System.in);

                        // Get user input for User fields
                        System.out.print("Enter User ID: ");
                        String userID = scanner1.nextLine();

                        System.out.print("Enter Username: ");
                        username = scanner1.nextLine();

                        System.out.print("Enter Email: ");
                        String email = scanner1.nextLine();

                        System.out.print("Enter Password: ");
                        password = scanner1.nextLine();

                        System.out.print("Enter Phone: ");
                        String phone = scanner1.nextLine();

                        System.out.print("Enter Address: ");
                        String address = scanner1.nextLine();

                        System.out.print("Enter Date of Birth (yyyy-MM-dd): ");
                        String dateOfBirthString = scanner1.nextLine();
                        Date dateOfBirth = parseDate(dateOfBirthString);

                        // Get user input for MedicalInformation fields
                        System.out.print("Enter Blood Type: ");
                        String bloodType = scanner1.nextLine();

                        System.out.print("Enter Weight: ");
                        String weight = scanner1.nextLine();

                        System.out.print("Enter Last Transfusion Date (yyyy-MM-dd): ");
                        String lastTransfusionString = scanner1.nextLine();
                        Date lastTransfusion = parseDate(lastTransfusionString);

                        System.out.print("Do you have any allergies? (true/false): ");
                        boolean hasAllergies = scanner1.nextBoolean();
                        scanner.nextLine(); // Consume the newline character

                        // Create MedicalInformation object
                        Medical_information medicalInfo = new Medical_information(bloodType, weight, lastTransfusion, hasAllergies);
                        recipient=new Recipient(userID,username,email,password,phone,address,dateOfBirth,medicalInfo);
                        Connectivity.storeUserDetails(userID,username,email,password,phone,address,dateOfBirth,bloodType, weight, lastTransfusion, hasAllergies,"Recipient");
                        
                    }
                    else if(num==6)
                    {
                    	Scanner scanner1 = new Scanner(System.in);

                        // Get user input for User fields
                        System.out.print("Enter User ID: ");
                        String userID = scanner1.nextLine();
                        Donor deletedonor=new Donor();
                        deletedonor.DeleteDonor(userID);
                    }
                    else if(num==7)
                    {
                    	Scanner scanner1 = new Scanner(System.in);

                        // Get user input for User fields
                        System.out.print("Enter Recipient ID: ");
                        String userID = scanner1.nextLine();
                        Recipient deleteRecipient=new Recipient();
                        deleteRecipient.DeleteRecipient(userID);
                    }
                    else if(num==8)
                    {
                    	Scanner scanner1 = new Scanner(System.in);

                        // Get user input for User fields
                        System.out.print("Enter Donor ID: ");
                        String userID = scanner1.nextLine();
                        Donor searchDonor=new Donor();
                        searchDonor.SearchDonor(userID);

                    }
                    else if(num==9)
                    {
                    	Scanner scanner1 = new Scanner(System.in);

                        // Get user input for User fields
                        System.out.print("Enter Recipient ID: ");
                        String userID = scanner1.nextLine();
                        Recipient searchRecipient=new Recipient();
                        searchRecipient.SearchRecipient(userID);
                    }
                    else if(num==10)
                    {
                    	
                    }
                    break;
                } else {
                    System.out.println("Invalid username or password. Attempts left: " + (--attempts));
                }
            }

            if (attempts == 0) {
                System.out.println("Exceeded maximum login attempts. Account locked.");
            }
        }
        }
        else if(num==2)
        {
        	System.out.println("1. Donor\n2. Recipient");
            num = scanner.nextInt();
            if(num==1)
            {
            	Scanner scanner1 = new Scanner(System.in);

                // Get user input for User fields
                System.out.print("Enter  ID: ");
                String userID = scanner1.nextLine();

                System.out.print("Enter Username: ");
                String username = scanner1.nextLine();

                System.out.print("Enter Email: ");
                String email = scanner1.nextLine();

                System.out.print("Enter Password: ");
                String password = scanner1.nextLine();

                System.out.print("Enter Phone: ");
                String phone = scanner1.nextLine();

                System.out.print("Enter Address: ");
                String address = scanner1.nextLine();

                System.out.print("Enter Date of Birth (yyyy-MM-dd): ");
                String dateOfBirthString = scanner1.nextLine();
                Date dateOfBirth = parseDate(dateOfBirthString);

                // Get user input for MedicalInformation fields
                System.out.print("Enter Blood Type: ");
                String bloodType = scanner1.nextLine();

                System.out.print("Enter Weight: ");
                String weight = scanner1.nextLine();

                System.out.print("Enter Last Transfusion Date (yyyy-MM-dd): ");
                String lastTransfusionString = scanner1.nextLine();
                Date lastTransfusion = parseDate(lastTransfusionString);

                System.out.print("Do you have any allergies? (true/false): ");
                boolean hasAllergies = scanner1.nextBoolean();
                scanner.nextLine(); // Consume the newline character

                // Create MedicalInformation object
                Medical_information medicalInfo = new Medical_information(bloodType, weight, lastTransfusion, hasAllergies);
                donor=new Donor(userID,username,email,password,phone,address,dateOfBirth,medicalInfo);
                Connectivity.storeUserDetails(userID,username,email,password,phone,address,dateOfBirth,bloodType, weight, lastTransfusion, hasAllergies,"Donor");
                
            }
            else if(num==2)
            {
            	Scanner scanner1 = new Scanner(System.in);

                // Get user input for User fields
                System.out.print("Enter User ID: ");
                String userID = scanner1.nextLine();

                System.out.print("Enter Username: ");
                String username = scanner1.nextLine();

                System.out.print("Enter Email: ");
                String email = scanner1.nextLine();

                System.out.print("Enter Password: ");
                String password = scanner1.nextLine();

                System.out.print("Enter Phone: ");
                String phone = scanner1.nextLine();

                System.out.print("Enter Address: ");
                String address = scanner1.nextLine();

                System.out.print("Enter Date of Birth (yyyy-MM-dd): ");
                String dateOfBirthString = scanner1.nextLine();
                Date dateOfBirth = parseDate(dateOfBirthString);

                // Get user input for MedicalInformation fields
                System.out.print("Enter Blood Type: ");
                String bloodType = scanner1.nextLine();

                System.out.print("Enter Weight: ");
                String weight = scanner1.nextLine();

                System.out.print("Enter Last Transfusion Date (yyyy-MM-dd): ");
                String lastTransfusionString = scanner1.nextLine();
                Date lastTransfusion = parseDate(lastTransfusionString);

                System.out.print("Do you have any allergies? (true/false): ");
                boolean hasAllergies = scanner1.nextBoolean();
                scanner.nextLine(); // Consume the newline character

                // Create MedicalInformation object
                Medical_information medicalInfo = new Medical_information(bloodType, weight, lastTransfusion, hasAllergies);
                recipient=new Recipient(userID,username,email,password,phone,address,dateOfBirth,medicalInfo);
                Connectivity.storeUserDetails(userID,username,email,password,phone,address,dateOfBirth,bloodType, weight, lastTransfusion, hasAllergies,"Recipient");
                
            }
        }
        }

	private static Date parseDate(String dateString) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            return dateFormat.parse(dateString);
        } catch (ParseException e) {
            System.err.println("Error parsing date. Please enter the date in the format yyyy-MM-dd.");
            System.exit(1);
            return null; // Unreachable, but required for compilation
        }
    }
	public static Boolean LoginDonor(String username,String password)
	{
		Donor LoginDonor=new Donor();
		return LoginDonor.loginDonor(username,password);
    }
	public static Boolean LoginRecipient(String username,String password)
	{
		Recipient LoginRecipient=new Recipient();
		return LoginRecipient.login(username,password);
    }
	public static Boolean LoginAdmin(String username,String password)
	{
		Admin LoginAdmin=new Admin();
		return LoginAdmin.loginAdmin(username,password);
    }
	public static String ShowAllDonor()
	{
		Donor Alldonor=new Donor();
		System.out.println(Alldonor.PrintAllDonor());
    	return Alldonor.PrintAllDonor();
    	
    }
	public static String ShowAllRecipient()
	{
		Recipient AllRecipient=new Recipient();
		System.out.println(AllRecipient.PrintAllRecipient());
    	return AllRecipient.PrintAllRecipient();
    	
    }
	public static String ShowAllHospital()
	{
		Hospital AllHospital=new Hospital();
    	return AllHospital.PrintAllHospitalsDetails();
    	
    }
	public static String AddHospital(String registrationNumber,String name,String city,String state,String country,String Apos,String Aneg,String Bpos,String Bneg,String Opos,String Oneg,String ABpos,String ABneg)
	{
		Hospital hospital;
		hospital = new Hospital(registrationNumber, name, new Hospital.Location(city, state, country));

		// Set blood quantities for each blood type using the provided arguments
		hospital.getInventory().updateBloodQuantity(Hospital.BloodType.A_POSITIVE, Integer.parseInt(Apos));
		hospital.getInventory().updateBloodQuantity(Hospital.BloodType.A_NEGATIVE, Integer.parseInt(Aneg));
		hospital.getInventory().updateBloodQuantity(Hospital.BloodType.B_POSITIVE, Integer.parseInt(Bpos));
		hospital.getInventory().updateBloodQuantity(Hospital.BloodType.B_NEGATIVE, Integer.parseInt(Bneg));
		hospital.getInventory().updateBloodQuantity(Hospital.BloodType.O_POSITIVE, Integer.parseInt(Opos));
		hospital.getInventory().updateBloodQuantity(Hospital.BloodType.O_NEGATIVE, Integer.parseInt(Oneg));
		hospital.getInventory().updateBloodQuantity(Hospital.BloodType.AB_POSITIVE, Integer.parseInt(ABpos));
		hospital.getInventory().updateBloodQuantity(Hospital.BloodType.AB_NEGATIVE, Integer.parseInt(ABneg));

		Connectivity.storeHospitalData(hospital);

		// Return success message or any other relevant information
		return "Hospital added successfully!";
	}
	public static boolean DeleteDonor(String userID)
	{
		
        Donor deletedonor=new Donor();
        return deletedonor.DeleteDonor(userID);
	}
	public static boolean DeleteRecipient(String userID)
	{
		
		Recipient deleteRecipient=new Recipient();
        return deleteRecipient.DeleteRecipient(userID);
	}
	public static String SearchDonor(String userID)
	{
		
		Donor searchDonor=new Donor();
        return searchDonor.SearchDonor(userID);
	}
	public static String SearchRecipient(String userID)
	{
		
		Recipient searchRecipient=new Recipient();
        return searchRecipient.SearchRecipient(userID);
	}
	public static String RegisterRecipient(String userID, String username, String email, String password, String phone, String address, String dateOfBirth,String weight ,String bloodType,String lastTransfusion,Boolean hasAllergies)
	{
		
		Medical_information medicalInfo = new Medical_information(bloodType, weight, parseDate(lastTransfusion), hasAllergies);
        Recipient NewRecipient=new Recipient(userID,username,email,password,phone,address,parseDate(dateOfBirth),medicalInfo);
         return "RECIPIENT REGISTERED SUCCESSFULLY";
        
	}
	public static String RegisterDonor(String userID, String username, String email, String password, String phone, String address, String dateOfBirth,String weight ,String bloodType,String lastTransfusion,Boolean hasAllergies)
	{
		if(Connectivity.doesDonorExist(userID, "Donor")==false)
		{
		Medical_information medicalInfo = new Medical_information(bloodType, weight, parseDate(lastTransfusion), hasAllergies);
        Donor NewDonor=new Donor(userID,username,email,password,phone,address,parseDate(dateOfBirth),medicalInfo);
         return "DONOR REGISTERED SUCCESSFULLY";
		}
		else
			return "DONOR ALREADY EXISTED";
        
	}
	
	public static String FindHospital(String city)
	{
		Hospital hospital = new Hospital();
    	return hospital.findNearbyHospital(city,"Hospital");
	}
	public static String FindRecipient(String city)
	{
		Recipient recipient = new Recipient();
    	return recipient.findNearbyRecipient(city,"Recipient");
	}
	public static String FindBloodCenter(String city)
	{
		Hospital hospital = new Hospital();
    	return hospital.findNearbyHospital(city,"Blood Center");
	}
	public static String donationToHospital(String username,String city,String hospitalID,String dateString)
	{
		Donor ldonor=new Donor();
    	System.out.println("Eligibility Status: " + ldonor.GetEligibility(username));
    	if(ldonor.GetEligibility(username))
    	{
    		BloodDonation bloodDonation=new BloodDonation();
    		/*System.out.print("Enter your city: ");
            String city = scanner0.nextLine();
            Hospital hospital = new Hospital();
        	hospital.HospitalOption(city,"Hospital");
        	System.out.println("Select a hospital to donate blood by writing Registration No:");
        	String hospitalID = scanner.next();
        	System.out.print("Enter the donation date (yyyy-MM-dd): ");
            String dateString = scanner.next();*/
            Date selectedDate = parseDate(dateString);
            bloodDonation.bookDonationAppointment(ldonor.getDonorID(username),hospitalID,selectedDate);
            return "Appointment Booked Successfully";
    	}
    	else 
    	{
        	return "Sorry you are not Eligible"; 
    	}
	}
	public static String donationToRecipient(String username,String RecipientID,String city,String hospitalID,String dateString)
	{
		Donor ldonor=new Donor();
    	System.out.println("Eligibility Status: " + ldonor.GetEligibility(username));
    	if(ldonor.GetEligibility(username))
    	{
    		BloodDonation bloodDonation=new BloodDonation();
    		
            Date selectedDate = parseDate(dateString);
            bloodDonation.bookDonationAppointment(ldonor.getDonorID(username),RecipientID,hospitalID,selectedDate);
            return "Appointment Booked Successfully";
    	}
    	else 
    	{
        	return "Sorry you are not Eligible"; 
    	}
	}
	public static Boolean GetEligibility(String username)
	{
		Donor ldonor=new Donor();
    	System.out.println("Eligibility Status: " + ldonor.GetEligibility(username));
    	return ldonor.GetEligibility(username);
    	
    	
	}
	public static String RecipientResetPassword(String username,String Oldpassword,String NewPassword)
	{
		Recipient ldonor=new Recipient();
    	if(Recipient.ResetPassword(username, Oldpassword, NewPassword,"Recipient"))
    	{
    		return "Password Changed Successfully";
    	}
    	else
    	{
    		return "Password not Changed";
    	}	
	}
	public static String ResetPassword(String username,String Oldpassword,String NewPassword)
	{
		Donor ldonor=new Donor();
    	if(Donor.ResetPassword(username, Oldpassword, NewPassword,"Donor"))
    	{
    		return "Password Changed Successfully";
    	}
    	else
    	{
    		return "Password Changed Successfully";
    	}	
	}
	public static String GetAppointmentsByUsername(String username)
	{
		Donor ldonor=new Donor();
		return ldonor.GetAppointmentsByUsername(username);
	}
	public static String RGetAppointmentsByUsername(String userID)
	{
		System.out.println(userID);
		Recipient ldonor=new Recipient();
		return ldonor.GetAppointmentsByUsername(userID);
	}
	public static String getAllDonationAppointments()
	{
			return BloodDonation.getAllDonationAppointments();
	}
	public static void RequestBlood(String Username)
	{
			new BloodRequest(Connectivity.getBloodTypeByUsername(Username),Connectivity.RgetUserIdFromUsername(Username),new Date());
	}
	public static String ShowAllRequest()
	{
			return BloodRequest.ShowAllRequest();
	}
}
