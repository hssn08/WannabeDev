package BusinessLogic;
import java.util.*;
import java.util.Date;
import DataBase.Connectivity;
public class BloodDonation {
    private Donor donor;
    private String appointmentId;
    private Date appointmentDate;
    private Hospital hospital;
    private DonationHistory donationHistory;
    
    public BloodDonation() {}
    public BloodDonation(Donor donor, String appointmentId, Date appointmentDate, Hospital hospital) {
        this.donor = donor;
        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.hospital = hospital;
        this.donationHistory = new DonationHistory();
    }

    // Getters and Setters for attributes

    public Donor getDonor() {
        return donor;
    }

    public void setDonor(Donor donor) {
        this.donor = donor;
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(String appointmentId) {
        this.appointmentId = appointmentId;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(Date appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public Hospital getHospital() {
        return hospital;
    }

    public void setHospital(Hospital hospital) {
        this.hospital = hospital;
    }
    private String generateAppointmentId() {
        // Generate a random number
        Random random = new Random();
        int randomNumber = random.nextInt(1000); // You can adjust the range as needed

        
        String appointmentId = "A" + randomNumber;

        return appointmentId;
    }
    public static void bookDonationAppointment(String userID, String hospitalID, Date appointmentDate) {
        
    	Connectivity.updateLastTransfusionDate(userID, appointmentDate);
    	// Store the details in the database here
    	Connectivity.storeDonationAppointment(userID,"", hospitalID, appointmentDate);
    }
    public static void bookDonationAppointment(String userID,String RecipientID, String hospitalID, Date appointmentDate) {
        
    	Connectivity.updateLastTransfusionDate(userID, appointmentDate);
    	// Store the details in the database here
    	Connectivity.storeDonationAppointment(userID, RecipientID, hospitalID, appointmentDate);
    }
    public DonationHistory getDonationHistory() {
        return donationHistory;
    }

    // DonationHistory class
    public static class DonationHistory {
        // You can add more attributes as needed
        private Date lastDonationDate;

        // Getters and Setters for DonationHistory attributes

        public Date getLastDonationDate() {
            return lastDonationDate;
        }

        public void setLastDonationDate(Date lastDonationDate) {
            this.lastDonationDate = lastDonationDate;
        }
    }
    
    
public static String getAllDonationAppointments() {
        
    	return Connectivity.getAllDonationAppointments();
    	
    }
}
