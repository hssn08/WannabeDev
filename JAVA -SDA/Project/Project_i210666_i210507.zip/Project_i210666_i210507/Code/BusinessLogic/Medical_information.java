package BusinessLogic;
import java.util.*;


public class Medical_information 
{
	private String bloodType;
	private String weight;
	private Date lasttransfusion;
    private boolean hasAllergies;

    // Constructor
    public Medical_information(String bloodType, String weight, Date lasttransfusion, boolean hasAllergies) {
        this.bloodType = bloodType;
        this.weight = weight;
        this.lasttransfusion = lasttransfusion;
        this.setHasAllergies(hasAllergies);
    }

    // Getter methods
    public String getBloodType() {
        return bloodType;
    }
    public String getWeight() {
        return weight;
    }
    public Date getlasttransfusion() {
        return lasttransfusion;
    }
    public boolean hasAllergies() {
        return getHasAllergies();
    }

	public boolean getHasAllergies() {
		return hasAllergies;
	}

	public void setHasAllergies(boolean hasAllergies) {
		this.hasAllergies = hasAllergies;
	}
    
}
