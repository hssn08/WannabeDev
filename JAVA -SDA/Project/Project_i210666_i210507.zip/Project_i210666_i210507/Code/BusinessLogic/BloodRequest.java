package BusinessLogic;

import java.util.Date;

import DataBase.Connectivity;

public class BloodRequest {

    private String bloodType;
    private String userID;
    private Date requestDate;

    // Constructors
    public BloodRequest(String bloodType, String userID, Date requestDate) {
        this.bloodType = bloodType;
        this.userID = userID;
        this.requestDate = requestDate;
        Connectivity.storeBloodRequest(bloodType, userID, requestDate);
    }

    // Getters and Setters
    public String getBloodType() {
        return bloodType;
    }

    public void setBloodType(String bloodType) {
        this.bloodType = bloodType;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public Date getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }
    
    public static String ShowAllRequest()
    {
    	return Connectivity.getAllBloodRequests();
    }
    // Additional methods, if needed
}
