package DataBase;

import com.mongodb.client.MongoClients;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Updates;

import BusinessLogic.BloodDonation;
import BusinessLogic.Hospital;
import BusinessLogic.Donor;

import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;
import java.util.Arrays;
import java.util.List;
import java.util.*;
import java.util.Date;
import java.util.List;

public class Connectivity {
    public static MongoDatabase database;

    public static void connect_database() {
        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");

        // Access the "PulseAid" database
        database = mongoClient.getDatabase("PulseAid");
        System.out.println("Connected to database successfully!");
    }

    public static void storeUserDetails(String userID, String username, String email, String password, String phone, String address, Date dateOfBirth, String bloodType, String weight, Date lastTransfusion, boolean hasAllergies, String table) {
        connect_database();

        // Perform operations on the database...
        MongoCollection<Document> collection = database.getCollection(table);

        // Create a document with donor details
        Document donorDocument = new Document()
                .append("userID", userID)
                .append("username", username)
                .append("email", email)
                .append("password", password)
                .append("phone", phone)
                .append("address", address)
                .append("dateOfBirth", dateOfBirth)
                .append("bloodType", bloodType)
                .append("weight", weight)
                .append("lastTransfusion", lastTransfusion)
                .append("hasAllergies", hasAllergies);

        // Insert the document into the collection
        collection.insertOne(donorDocument);

        System.out.println("Donor details stored successfully.");
    }

    public static boolean Checklogin(String username, String password,String type)
    {
        // Ensure the database is connected before checking login
        connect_database();

        MongoCollection<Document> usersCollection = database.getCollection(type);
        Document userDocument = usersCollection.find(new Document("username", username)).first();

        if (userDocument != null && userDocument.getString("password").equals(password)) {
            return true;
        } else {
            return false;
        }
    }
    /*public static void PrintAll(String type)
    {
    	connect_database();
    	// Access the "Donor" collection
        MongoCollection<Document> donorCollection = database.getCollection(type);

        // Retrieve all donors from the collection
        FindIterable<Document> donors = donorCollection.find();

        // Print each donor
        
        for (Document donor : donors) {
            System.out.println("User ID: " + donor.getString("userID"));
            System.out.println("Username: " + donor.getString("username"));
            System.out.println("Email: " + donor.getString("email"));
            System.out.println("Phone: " + donor.getString("phone"));
            System.out.println("Address: " + donor.getString("address"));
            System.out.println("Date of Birth: " + donor.getDate("dateOfBirth"));
            System.out.println("Blood Type: " + donor.getString("bloodType"));
            System.out.println("Weight: " + donor.getString("weight"));
            System.out.println("Last Transfusion: " + donor.getDate("lastTransfusion"));
            System.out.println("Has Allergies: " + donor.getBoolean("hasAllergies"));
            System.out.println("--------------------\n");
        }
    }*/
    public static String PrintAll(String type) {
    	   connect_database();
    	   // Access the "Donor" collection
    	   MongoCollection<Document> donorCollection = database.getCollection(type);

    	   // Retrieve all donors from the collection
    	   FindIterable<Document> donors = donorCollection.find();

    	   // Create a StringBuilder to hold the combined string
    	   StringBuilder combinedString = new StringBuilder();

    	   // Print each donor
    	   for (Document donor : donors) {
    	       combinedString.append("User ID: ").append(donor.getString("userID")).append("\n");
    	       combinedString.append("Username: ").append(donor.getString("username")).append("\n");
    	       combinedString.append("Email: ").append(donor.getString("email")).append("\n");
    	       combinedString.append("Phone: ").append(donor.getString("phone")).append("\n");
    	       combinedString.append("Address: ").append(donor.getString("address")).append("\n");
    	       combinedString.append("Date of Birth: ").append(donor.getDate("dateOfBirth")).append("\n");
    	       combinedString.append("Blood Type: ").append(donor.getString("bloodType")).append("\n");
    	       combinedString.append("Weight: ").append(donor.getString("weight")).append("\n");
    	       combinedString.append("Last Transfusion: ").append(donor.getDate("lastTransfusion")).append("\n");
    	       combinedString.append("Has Allergies: ").append(donor.getBoolean("hasAllergies")).append("\n");
    	       combinedString.append("--------------------\n");
    	   }

    	   // Return the combined string
    	   return combinedString.toString();
    	}

    public static Boolean DeleteUser(String userID,String type)
    {
    	// Access the "Donor" collection
        MongoCollection<Document> donorCollection = database.getCollection(type);

        // Create a filter to find the donor with the given user ID
        Document filter = new Document("userID", userID);

        // Delete the donor document
        if(donorCollection.deleteOne(filter)!=null)
        {
        	System.out.println("Donor with userID: " + userID + " deleted successfully.");
        	return true;
        }
        else
        {
        	System.out.println("No Donor with userID: " + userID + " Existed.");
        	return false;
        }
    }
    public static String SearchUser(String userID, String type) {
    	   // Access the "Donor" collection
    	   MongoCollection<Document> donorCollection = database.getCollection(type);
    	   // Create a filter to find the donor with the given user ID
    	   Document filter = new Document("userID", userID);

    	   // Search for the donor document
    	   FindIterable<Document> result = donorCollection.find(filter);

    	   // Prepare a StringBuilder to hold the output
    	   StringBuilder output = new StringBuilder();

    	   // Display donor details if found
    	   if (result.first() != null) {
    	       Document donor = result.first();
    	       output.append("Donor Details for UserID: " + userID).append("\n");
    	       output.append("Username: " + donor.getString("username")).append("\n");
    	       output.append("Email: " + donor.getString("email")).append("\n");
    	       output.append("Phone: " + donor.getString("phone")).append("\n");
    	       output.append("Address: " + donor.getString("address")).append("\n");
    	       output.append("Date of Birth: " + donor.getDate("dateOfBirth")).append("\n");
    	       output.append("Blood Type: " + donor.getString("bloodType")).append("\n");
    	       output.append("Weight: " + donor.getString("weight")).append("\n");
    	       output.append("Last Transfusion: " + donor.getDate("lastTransfusion")).append("\n");
    	       output.append("Has Allergies: " + donor.getBoolean("hasAllergies")).append("\n");
    	   } else {
    	       output.append("No donor found with UserID: " + userID);
    	   }

    	   // Return the output as a string
    	   return output.toString();
    	}

    
    
    
    
    public static void storeHospitalData(Hospital hospital) {
        connect_database();
        MongoCollection<Document> collection = database.getCollection("Hospital");

        // Create a document with hospital details
        Document hospitalDocument = new Document()
                .append("registrationNumber", hospital.getRegistrationNumber())
                .append("name", hospital.getName())
                .append("location", new Document()
                        .append("city", hospital.getLocation().getCity())
                        .append("state", hospital.getLocation().getState())
                        .append("country", hospital.getLocation().getCountry()))
                .append("inventory", new Document()
                        .append("bloodEntries", createBloodEntriesDocument(hospital.getInventory().getBloodEntries())));

        // Insert the document into the collection
        collection.insertOne(hospitalDocument);

        System.out.println("Hospital data stored successfully.");
    }

    private static List<Document> createBloodEntriesDocument(Hospital.BloodEntry[] bloodEntries) {
        List<Document> bloodEntriesDocuments = new ArrayList<>();
        for (Hospital.BloodEntry bloodEntry : bloodEntries) {
            bloodEntriesDocuments.add(new Document()
                    .append("bloodType", bloodEntry.getBloodType().toString())
                    .append("quantity", bloodEntry.getQuantity()));
        }
        return bloodEntriesDocuments;
    }
    
    
    
    public static void printAllHospitals() {
        connect_database();
        MongoCollection<Document> collection = database.getCollection("Hospital");

        // Find all documents in the collection
        FindIterable<Document> hospitals = collection.find();

        // Iterate over the documents and print information
        for (Document hospitalDocument : hospitals) {
            printHospitalInfo(hospitalDocument);
        }
    }
    
    public static void printHospitalInfo(Document hospitalDocument) {
        System.out.println("Hospital Information:");
        System.out.println("Registration Number: " + hospitalDocument.getString("registrationNumber"));
        System.out.println("Name: " + hospitalDocument.getString("name"));

        Document location = hospitalDocument.get("location", Document.class);
        if (location != null) {
            System.out.println("Location:");
            System.out.println("City: " + location.getString("city"));
            System.out.println("State: " + location.getString("state"));
            System.out.println("Country: " + location.getString("country"));
        }

        Document inventory = hospitalDocument.get("inventory", Document.class);
        if (inventory != null) {
            System.out.println("Inventory:");
            printBloodEntries(inventory.get("bloodEntries", ArrayList.class));
        }

        System.out.println("-----------------------------------");
    }
    public static String printAllHosOption() {
    	   connect_database();
    	   MongoCollection<Document> collection = database.getCollection("Hospital");

    	   // Find all documents in the collection
    	   FindIterable<Document> hospitals = collection.find();

    	   // Create a StringBuilder to hold the combined string
    	   StringBuilder combinedString = new StringBuilder();

    	   // Iterate over the documents and print information
    	   for (Document hospitalDocument : hospitals) {
    	       combinedString.append(printHospitalDetails(hospitalDocument));
    	   }

    	   // Return the combined string
    	   return combinedString.toString();
    	}

    	public static String printHospitalDetails(Document hospitalDocument) {
    	   StringBuilder hospitalDetails = new StringBuilder();
    	   hospitalDetails.append("Hospital Information:\n");
    	   hospitalDetails.append("Registration Number: ").append(hospitalDocument.getString("registrationNumber")).append("\n");
    	   hospitalDetails.append("Name: ").append(hospitalDocument.getString("name")).append("\n");

    	   Document location = hospitalDocument.get("location", Document.class);
    	   if (location != null) {
    	       hospitalDetails.append("Location:\n");
    	       hospitalDetails.append("City: ").append(location.getString("city")).append("\n");
    	       hospitalDetails.append("State: ").append(location.getString("state")).append("\n");
    	       hospitalDetails.append("Country: ").append(location.getString("country")).append("\n");
    	   }

    	   hospitalDetails.append("-----------------------------------\n");

    	   return hospitalDetails.toString();
    	}
    private static void printBloodEntries(ArrayList bloodEntries) {
        System.out.println("Blood Entries:");
        for (Object bloodEntryObj : bloodEntries) {
            Document bloodEntry = (Document) bloodEntryObj;
            System.out.println("Blood Type: " + bloodEntry.getString("bloodType"));
            System.out.println("Quantity: " + bloodEntry.getInteger("quantity"));
            System.out.println("-----------------------");
        }
    }
    public static String findNearbyHospitals(String userCity,String type) {
        connect_database();
        StringBuilder haha = new StringBuilder();
        MongoCollection<Document> collection = database.getCollection(type);

        // Create a query to find hospitals in the given city
        Bson query = Filters.eq("location.city", userCity);

        // Find documents matching the query
        FindIterable<Document> hospitals = collection.find(query);

        // Iterate over the documents and print information
        for (Document hospitalDocument : hospitals) {
        	haha.append(printHospitalDetails(hospitalDocument));
        }
        return haha.toString();
    }
    
    public static void HospitalsOption(String userCity,String type) {
        connect_database();
        MongoCollection<Document> collection = database.getCollection(type);

        // Create a query to find hospitals in the given city
        Bson query = Filters.eq("location.city", userCity);

        // Find documents matching the query
        FindIterable<Document> hospitals = collection.find(query);

        // Iterate over the documents and print information
        for (Document hospitalDocument : hospitals) {
            printHospitalDetails(hospitalDocument);
        }
    }
    
    
    
    
    
    
    public static Date getDonorLastDonationDate(String donorName) {
        // Your Donor collection in MongoDB
        MongoCollection<Document> donorCollection = database.getCollection("Donor");

        
        Document query = new Document("username", donorName);
        FindIterable<Document> result = donorCollection.find(query);

        
        Document donorDocument = result.first();
        if (donorDocument != null && donorDocument.containsKey("lastTransfusion")) {
            return donorDocument.getDate("lastTransfusion");
        }

        // Return null if the donor or lastDonationDate is not found
        return null;
    }
    public static String getDonorID(String donorName) {
        // Your Donor collection in MongoDB
        MongoCollection<Document> donorCollection = database.getCollection("Donor");

        
        Document query = new Document("username", donorName);
        FindIterable<Document> result = donorCollection.find(query);

        
        Document donorDocument = result.first();
        if (donorDocument != null && donorDocument.containsKey("userID")) {
            return donorDocument.getString("userID");
        }

        // Return null if the donor or lastDonationDate is not found
        return null;
    }
    public static void storeDonationAppointment(String userID,String RecipientID, String hospitalName, Date appointmentDate) {
    	connect_database();

        // Access the "DonationAppointments" collection
        MongoCollection<Document> collection = database.getCollection("DonationAppointments");

        // Create a document with donation appointment details
        Document appointmentDocument = new Document()
                .append("userID", userID)
                .append("RecipientID", RecipientID)
                .append("hospitalName", hospitalName)
                .append("appointmentDate", appointmentDate);

        // Insert the document into the collection
        collection.insertOne(appointmentDocument);

        System.out.println("Donation appointment details stored in the database.");
    }
    
    public static void updateLastTransfusionDate(String donorID, Date newLastTransfusionDate) {
        // Your Donor collection in MongoDB
        MongoCollection<Document> donorCollection = database.getCollection("Donor");

        // Create a query to find the donor by ID
        Document query = new Document("userID", donorID);

        // Create an update with the new lastTransfusionDate value
        Document update = new Document("$set", new Document("lastTransfusion", newLastTransfusionDate));

        // Perform the update
        donorCollection.updateOne(query, update);

        System.out.println("Last transfusion date updated successfully.");
    }
    public static boolean resetPassword(String username, String oldPassword, String newPassword,String Type) {
        // Your Donor collection in MongoDB
        MongoCollection<Document> donorCollection = database.getCollection(Type);

        // Query to find the donor by username and old password
        Document query = new Document("username", username).append("password", oldPassword);

        // Find the donor document based on the query
        Document donorDocument = donorCollection.find(query).first();

        // Check if the donor with the provided username and old password exists
        if (donorDocument != null) {
            // Update the password with the new password
            donorDocument.put("password", newPassword);

            // Update the document in the database
            donorCollection.replaceOne(query, donorDocument);

            // Return true to indicate successful password reset
            return true;
        }

        // Return false if the donor or old password is not found
        return false;
    }

    
    
    
    public static String getDonationAppointmentDetails(String userId) {
        MongoCollection<Document> donationAppointmentsCollection = database.getCollection("DonationAppointments");

        // Define the pipeline to join the Donor and Hospital collections
        List<Bson> pipeline = Arrays.asList(
                Aggregates.match(Filters.eq("userID", userId)),
                Aggregates.lookup("Donor", "userID", "userID", "donor"),
                Aggregates.lookup("Hospital", "hospitalID", "registrationNumber", "hospital"),
                Aggregates.unwind("$donor"),
                Aggregates.unwind("$hospital"),
                Aggregates.project(
                        Projections.fields(
                                Projections.excludeId(),
                                Projections.include("appointmentDate"),
                                Projections.computed("donorName", "$donor.username"),
                                Projections.computed("hospitalName", "$hospital.name"),
                                Projections.computed("city", "$hospital.location.city"),
                                Projections.computed("state", "$hospital.location.state"),
                                Projections.computed("country", "$hospital.location.country")
                        )
                )
        );

        // Execute the aggregation pipeline
        AggregateIterable<Document> result = donationAppointmentsCollection.aggregate(pipeline);

        // Process the result into a string
        StringBuilder resultString = new StringBuilder();
        for (Document document : result) {
            resultString.append("Donor Name: ").append(document.getString("donorName")).append("\n");
            resultString.append("Hospital Name: ").append(document.getString("hospitalName")).append("\n");
            resultString.append("Location: ").append(document.getString("city")).append(", ")
                    .append(document.getString("state")).append(", ").append(document.getString("country")).append("\n");
            resultString.append("Appointment Date: ").append(document.getDate("appointmentDate")).append("\n");
            resultString.append("-----------------------------------\n");
        }

        return resultString.toString();
    }




    public static String getUserIdFromUsername(String username) {
        // Your Donor collection in MongoDB
        MongoCollection<Document> donorCollection = database.getCollection("Donor");

        // Query to find the donor document based on the username
        Document query = new Document("username", username);

        // Find the donor document based on the query
        Document donorDocument = donorCollection.find(query).first();

        // Check if the donor document is found and contains the userID field
        if (donorDocument != null && donorDocument.containsKey("userID")) {
            return donorDocument.getString("userID");
        }

        // Return null if the donor or userID is not found
        return null;
    }
    public static String RgetUserIdFromUsername(String username) {
        // Your Donor collection in MongoDB
        MongoCollection<Document> donorCollection = database.getCollection("Recipient");

        // Query to find the donor document based on the username
        Document query = new Document("username", username);

        // Find the donor document based on the query
        Document donorDocument = donorCollection.find(query).first();

        // Check if the donor document is found and contains the userID field
        if (donorDocument != null && donorDocument.containsKey("userID")) {
            return donorDocument.getString("userID");
        }

        // Return null if the donor or userID is not found
        return null;
    }
    
    public static boolean doesDonorExist(String userId,String type) {
    	connect_database();
        MongoCollection<Document> donorCollection = database.getCollection(type);

        // Check if a document with the provided userID exists in the Donor collection
        long count = donorCollection.countDocuments(Filters.eq("userID", userId));

        // If count is greater than 0, the donor exists; otherwise, they don't exist
        return count > 0;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    public static String findNearbyRecipients(String userCity, String type) {
        connect_database();
        StringBuilder result = new StringBuilder();
        MongoCollection<Document> collection = database.getCollection(type);

        // Create a query to find recipients in the given city
        Bson query = Filters.regex("address", ".*" + userCity + ".*", "i");

        // Find documents matching the query
        FindIterable<Document> recipients = collection.find(query);

        // Iterate over the documents and append information to the result
        for (Document recipientDocument : recipients) {
            result.append(printRecipientDetails(recipientDocument));
        }
        return result.toString();
    }

    private static String printRecipientDetails(Document recipientDocument) {
        // Customize this method based on your document structure
        // Extract relevant information and format it as needed
        // Example:
        String recipientDetails = "User ID: " + recipientDocument.getString("userID") + "\n";
        recipientDetails += "Username: " + recipientDocument.getString("username") + "\n";
        recipientDetails += "Email: " + recipientDocument.getString("email") + "\n";
        recipientDetails += "Phone: " + recipientDocument.getString("phone") + "\n";
        recipientDetails += "Address: " + recipientDocument.getString("address") + "\n";
        recipientDetails += "Blood Type: " + recipientDocument.getString("bloodType") + "\n";
        recipientDetails += "Last Transfusion: " + recipientDocument.getDate("lastTransfusion") + "\n";
        recipientDetails += "Has Allergies: " + recipientDocument.getBoolean("hasAllergies") + "\n";
        recipientDetails += "-----------------------------------\n";
        return recipientDetails;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    public static String getDonationAppointmentsByRecipientID(String recipientID) {
        connect_database();
        StringBuilder result = new StringBuilder();
        MongoCollection<Document> appointmentCollection = database.getCollection("DonationAppointments");

        // Create a query to find appointments based on the recipient's RecipientID
        Bson query = Filters.eq("RecipientID", recipientID);

        // Find documents matching the query
        FindIterable<Document> appointments = appointmentCollection.find(query);

        // Iterate over the documents and append information to the result
        for (Document appointmentDocument : appointments) {
            result.append(printDonationAppointmentDetails(appointmentDocument));
        }
        return result.toString();
    }

    private static String printDonationAppointmentDetails(Document appointmentDocument) {
        // Customize this method based on your document structure
        // Extract relevant information and format it as needed
        // Example:
        String appointmentDetails = "Appointment ID: " + appointmentDocument.getObjectId("_id") + "\n";
        appointmentDetails += "Hospital Name: " + appointmentDocument.getString("hospitalName") + "\n";
        appointmentDetails += "Appointment Date: " + appointmentDocument.getDate("appointmentDate") + "\n";
        appointmentDetails += "-----------------------------------\n";
        return appointmentDetails;
    }
    
    
    
    
    
    
    
    
    
    public static String getAllDonationAppointments() {
        connect_database();
        StringBuilder result = new StringBuilder();
        MongoCollection<Document> appointmentCollection = database.getCollection("DonationAppointments");

        // Find all documents in the collection
        FindIterable<Document> appointments = appointmentCollection.find();

        // Iterate over the documents and append information to the result
        for (Document appointmentDocument : appointments) {
            result.append(printDonationAppointmentDetails(appointmentDocument));
        }
        return result.toString();
    }

    
    public static void storeBloodRequest(String bloodType, String userID, Date requestDate) {
        // Access the "RequestBlood" collection in the database
        MongoCollection<Document> collection = database.getCollection("RequestBlood");

        // Create a document with blood request details
        Document requestDocument = new Document()
                .append("bloodType", bloodType)
                .append("userID", userID)
                .append("requestDate", requestDate);

        // Insert the document into the collection
        collection.insertOne(requestDocument);

        System.out.println("Blood request stored successfully.");
    }
    
    public static String getBloodTypeByUsername(String username) {
        // Access the "Donor" collection in the database
        MongoCollection<Document> collection = database.getCollection("Recipient");

        // Create a query to find the donor based on the username
        Document query = new Document("username", username);

        // Find the donor document based on the query
        FindIterable<Document> result = collection.find(query);

        // Check if the document is found and contains the bloodType field
        if (result.first() != null && result.first().containsKey("bloodType")) {
            return result.first().getString("bloodType");
        }

        // Return null if the donor or bloodType is not found
        return null;
    }
    public static String getAllBloodRequests() {
        // Access the "RequestBlood" collection in the database
        MongoCollection<Document> collection = database.getCollection("RequestBlood");

        // Retrieve all blood donation requests from the collection
        FindIterable<Document> requests = collection.find();

        // Create a StringBuilder to hold the combined string
        StringBuilder result = new StringBuilder();

        // Iterate over the requests and append details to the result
        for (Document requestDocument : requests) {
            result.append("Request ID: ").append(requestDocument.getObjectId("_id")).append("\n");
            result.append("UserID: ").append(requestDocument.getString("userID")).append("\n");
            result.append("Blood Type: ").append(requestDocument.getString("bloodType")).append("\n");
            result.append("Request Date: ").append(requestDocument.getDate("requestDate")).append("\n");
            result.append("-----------------------------------\n");
        }

        // Return the result as a string
        return result.toString();
    }
}
