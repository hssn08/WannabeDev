package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import BusinessLogic.PulseAid;
import javafx.event.ActionEvent;

public class DonationOptionsController {

	private String username;

	public void setMyString(String myString)
	{
		this.username = myString;
	}
	// Event Listener on Button.onAction
	@FXML
	public void DonateToHospital(ActionEvent event)
	{
		//PulseAid.GetEligibility(username)
		Stage primaryStage = new Stage();
		try {
		 FXMLLoader loader = new FXMLLoader(getClass().getResource("DonateToHospital.fxml"));
		 Parent root = loader.load();
		 Scene scene = new Scene(root);
		 primaryStage.setScene(scene);
		 primaryStage.show();

		 DonateToHospitalController donateToHospitalController = loader.getController();
		 donateToHospitalController.setMyString(username);

		} catch(Exception e) {
		 e.printStackTrace();
		}

	}
	@FXML
	public void DonateToBloodCenter(ActionEvent event) {
		Stage primaryStage = new Stage();
		try {
		 FXMLLoader loader = new FXMLLoader(getClass().getResource("DonateToBloodCenter.fxml"));
		 Parent root = loader.load();
		 Scene scene = new Scene(root);
		 primaryStage.setScene(scene);
		 primaryStage.show();

		 DonateToBloodCenterController donateToHospitalController = loader.getController();
		 donateToHospitalController.setMyString(username);

		} catch(Exception e) {
		 e.printStackTrace();
		}
	}
	// Event Listener on Button.onAction
	@FXML
	public void DonateToRecipient(ActionEvent event){
		Stage primaryStage = new Stage();
		try {
		 FXMLLoader loader = new FXMLLoader(getClass().getResource("DonateToRecipient.fxml"));
		 Parent root = loader.load();
		 Scene scene = new Scene(root);
		 primaryStage.setScene(scene);
		 primaryStage.show();

		 DonateToRecipientController donateToRecipientController = loader.getController();
		 donateToRecipientController.setMyString(username);

		} catch(Exception e) {
		 e.printStackTrace();
		}
	}
	// Event Listener on Button.onAction
	@FXML
	public void BackToMenu(ActionEvent event) {
		Stage primaryStage=new Stage();
   		try {
   			Parent root = FXMLLoader.load(getClass().getResource("DonorMenu.fxml"));
   			Scene scene=new Scene(root);
   			primaryStage.setScene(scene);
   			primaryStage.show();
   		} catch(Exception e) {
   			e.printStackTrace();
   		}
	}
}
