package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class WelcomePageController {
	Image MyImage = new Image(getClass().getResourceAsStream("LOGO.jpg"));
	@FXML
	public void LoginButton(ActionEvent event)
	{
		Stage primaryStage=new Stage();
		try {
			Parent root = FXMLLoader.load(getClass().getResource("LoginOption.fxml"));
			Scene scene=new Scene(root);
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	// Event Listener on Button.onAction
	@FXML
	public void RegisterButton(ActionEvent event) {
		Stage primaryStage=new Stage();
		try {
			Parent root = FXMLLoader.load(getClass().getResource("RegisterOption.fxml"));
			Scene scene=new Scene(root);
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
