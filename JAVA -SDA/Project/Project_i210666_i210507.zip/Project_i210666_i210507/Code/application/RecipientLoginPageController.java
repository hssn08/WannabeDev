package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;
import BusinessLogic.PulseAid;

public class RecipientLoginPageController {
   @FXML
   private TextField username;
   @FXML
   private PasswordField password;

   // Event Listener on Button.onAction
   @FXML
   public void LoginSucess(ActionEvent event) {
       String Username=username.getText();
       String Password=password.getText();
       if(PulseAid.LoginRecipient(Username,Password))
       {
    	   Stage primaryStage = new Stage();
			try {
			   FXMLLoader loader = new FXMLLoader(getClass().getResource("RecipientMenu.fxml"));
			   Parent root = loader.load();
			   Scene scene = new Scene(root);
			   primaryStage.setScene(scene);
			   primaryStage.show();

			   RecipientMenuController recipientMenuController = loader.getController();
			   recipientMenuController.setMyString(Username);

			} catch(Exception e) {
			   e.printStackTrace();
			}
       }
       else
       {
           //alert
           Alert alert = new Alert(AlertType.ERROR);
           alert.setTitle("Login Error");
           alert.setHeaderText("Incorrect Username or Password");
           alert.setContentText("Please check your username and password.");
           alert.showAndWait();
       }
   }
}
