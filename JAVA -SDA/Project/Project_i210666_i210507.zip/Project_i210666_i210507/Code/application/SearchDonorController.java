package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import BusinessLogic.PulseAid;
import javafx.event.ActionEvent;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;

public class SearchDonorController {
	@FXML
	private TextField userID;
	@FXML
	private Label Donor;

	// Event Listener on Button.onAction
	@FXML
	public void SearchDonor(ActionEvent event) {
		String DonorList = PulseAid.SearchDonor(userID.getText());
	       Donor.setText(DonorList);
	       //System.out.println(PulseAid.ShowAllDonor());
	}
	// Event Listener on Button.onAction
	@FXML
	public void GoBack(ActionEvent event) throws IOException {
		Stage primaryStage=new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("AdminMenu.fxml"));
        Scene scene=new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
	}
}
