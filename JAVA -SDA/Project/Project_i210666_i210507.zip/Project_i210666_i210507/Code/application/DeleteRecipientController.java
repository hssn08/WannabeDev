package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

import java.io.IOException;

import BusinessLogic.PulseAid;
import javafx.event.ActionEvent;

public class DeleteRecipientController {
	@FXML
	private TextField userID;

	// Event Listener on Button.onAction
	@FXML
	public void Goback(ActionEvent event) throws IOException {
		Stage primaryStage=new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("AdminMenu.fxml"));
        Scene scene=new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
	}
	// Event Listener on Button.onAction
	@FXML
	public void DeleteRecipient(ActionEvent event) {
		   String userid = userID.getText();
		   

		   if(userid!=null)
		   {
		       PulseAid.DeleteRecipient(userid);
		       Stage primaryStage=new Stage();
		       try {
		           Parent root = FXMLLoader.load(getClass().getResource("AdminMenu.fxml"));
		           Scene scene=new Scene(root);
		           primaryStage.setScene(scene);
		           primaryStage.show();
		           
		           Alert alert = new Alert(AlertType.CONFIRMATION);
			       alert.setTitle("DONOR DELETED");
			       alert.showAndWait();
			       
		           
		       } catch(Exception e) {
		           e.printStackTrace();
		       }
		   }
		   else
		   {
		       //alert
		       Alert alert = new Alert(AlertType.ERROR);
		       alert.setTitle("FILL THE SLOT");
		       alert.setHeaderText("PLS FILL");
		       alert.setContentText("Please check BOX.");
		       alert.showAndWait();
		   }
		}

}
