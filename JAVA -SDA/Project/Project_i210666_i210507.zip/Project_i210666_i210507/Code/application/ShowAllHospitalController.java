package application;

import BusinessLogic.PulseAid;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

import java.net.URL;
import java.util.ResourceBundle;

public class ShowAllHospitalController implements Initializable {
   @FXML
   private Label HospitalText;

   @Override
   public void initialize(URL location, ResourceBundle resources) {
       String HospitalList = PulseAid.ShowAllHospital();
       HospitalText.setText(HospitalList);
       System.out.println(PulseAid.ShowAllHospital());
   }
}
