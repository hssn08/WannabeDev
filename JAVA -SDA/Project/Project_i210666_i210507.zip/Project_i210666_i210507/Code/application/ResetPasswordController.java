package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import BusinessLogic.PulseAid;
import javafx.event.ActionEvent;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.scene.control.PasswordField;

public class ResetPasswordController {
	@FXML
	private PasswordField oldpassword;
	@FXML
	private PasswordField newpassword;
	private String username;
	public void setmystring(String Username) {
		// TODO Auto-generated method stub
		this.username=Username;
	}
	// Event Listener on Button.onAction
	@FXML
	public void ResetPassword(ActionEvent event) {
		//PulseAid.ResetPassword(username, oldpassword.getText(), newpassword.getText());
		Alert alert = new Alert(AlertType.CONFIRMATION);
	       alert.setTitle("");
	       alert.setHeaderText(PulseAid.RecipientResetPassword(username, oldpassword.getText(), newpassword.getText()));
	       alert.showAndWait();
	       Stage primaryStage=new Stage();
			try {
				Parent root = FXMLLoader.load(getClass().getResource("LoginOption.fxml"));
				Scene scene=new Scene(root);
				primaryStage.setScene(scene);
				primaryStage.show();
			} catch(Exception e) {
				e.printStackTrace();
			}
	}
}