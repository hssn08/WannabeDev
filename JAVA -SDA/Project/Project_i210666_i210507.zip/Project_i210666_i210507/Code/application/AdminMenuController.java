package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.event.ActionEvent;

public class AdminMenuController {

	// Event Listener on Button.onAction
	@FXML
	public void RemoveDonor(ActionEvent event) {
		Stage primaryStage=new Stage();
   		try {
   			Parent root = FXMLLoader.load(getClass().getResource("DeleteDonor.fxml"));
   			Scene scene=new Scene(root);
   			primaryStage.setScene(scene);
   			primaryStage.show();
   		} catch(Exception e) {
   			e.printStackTrace();
   		}
	}
	@FXML
	public void RemoveRecipient(ActionEvent event) {
		Stage primaryStage=new Stage();
   		try {
   			Parent root = FXMLLoader.load(getClass().getResource("DeleteRecipient.fxml"));
   			Scene scene=new Scene(root);
   			primaryStage.setScene(scene);
   			primaryStage.show();
   		} catch(Exception e) {
   			e.printStackTrace();
   		}
	}
	// Event Listener on Button.onAction
	@FXML
	public void SearchDonor(ActionEvent event) {
		Stage primaryStage=new Stage();
   		try {
   			Parent root = FXMLLoader.load(getClass().getResource("SearchDonor.fxml"));
   			Scene scene=new Scene(root);
   			primaryStage.setScene(scene);
   			primaryStage.show();
   		} catch(Exception e) {
   			e.printStackTrace();
   		}
	}
	// Event Listener on Button.onAction
	@FXML
	public void SearchRecipient(ActionEvent event) {
		Stage primaryStage=new Stage();
   		try {
   			Parent root = FXMLLoader.load(getClass().getResource("SearchRecipient.fxml"));
   			Scene scene=new Scene(root);
   			primaryStage.setScene(scene);
   			primaryStage.show();
   		} catch(Exception e) {
   			e.printStackTrace();
   		}
	}
	// Event Listener on Button.onAction
	@FXML
	public void ViewAllRecipient(ActionEvent event) {
		Stage primaryStage=new Stage();
   		try {
   			Parent root = FXMLLoader.load(getClass().getResource("ViewAllDonations.fxml"));
   			Scene scene=new Scene(root);
   			primaryStage.setScene(scene);
   			primaryStage.show();
   		} catch(Exception e) {
   			e.printStackTrace();
   		}
	}
	// Event Listener on Button.onAction
	@FXML
	public void ShowAllDonor(ActionEvent event) {
		Stage primaryStage=new Stage();
   		try {
   			Parent root = FXMLLoader.load(getClass().getResource("ShowAllDonor.fxml"));
   			Scene scene=new Scene(root);
   			primaryStage.setScene(scene);
   			primaryStage.show();
   		} catch(Exception e) {
   			e.printStackTrace();
   		}
	}
	// Event Listener on Button.onAction
	@FXML
	public void ShowAllRecipient(ActionEvent event) {
		Stage primaryStage=new Stage();
   		try {
   			Parent root = FXMLLoader.load(getClass().getResource("ShowAllRecipient.fxml"));
   			Scene scene=new Scene(root);
   			primaryStage.setScene(scene);
   			primaryStage.show();
   		} catch(Exception e) {
   			e.printStackTrace();
   		}
	}
	// Event Listener on Button.onAction
	@FXML
	public void ShowAllHospitals(ActionEvent event) {
		Stage primaryStage=new Stage();
   		try {
   			Parent root = FXMLLoader.load(getClass().getResource("ShowAllHospital.fxml"));
   			Scene scene=new Scene(root);
   			primaryStage.setScene(scene);
   			primaryStage.show();
   		} catch(Exception e) {
   			e.printStackTrace();
   		}
	}
	// Event Listener on Button.onAction
	@FXML
	public void AddHospital(ActionEvent event) {
		Stage primaryStage=new Stage();
   		try {
   			Parent root = FXMLLoader.load(getClass().getResource("AddHospital.fxml"));
   			Scene scene=new Scene(root);
   			primaryStage.setScene(scene);
   			primaryStage.show();
   		} catch(Exception e) {
   			e.printStackTrace();
   		}
	}
	// Event Listener on Button.onAction
	@FXML
	public void AddRecipient(ActionEvent event) {
		Stage primaryStage=new Stage();
   		try {
   			Parent root = FXMLLoader.load(getClass().getResource("RegisterRecipient.fxml"));
   			Scene scene=new Scene(root);
   			primaryStage.setScene(scene);
   			primaryStage.show();
   		} catch(Exception e) {
   			e.printStackTrace();
   		}
	}
}
