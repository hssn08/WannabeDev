package application;

import BusinessLogic.PulseAid;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;





public class RequestBloodController implements Initializable {
   @FXML
   private Label request;

   @Override
   public void initialize(URL location, ResourceBundle resources) {
       String DonorList = PulseAid.ShowAllRequest();
       request.setText(DonorList);
       System.out.println(PulseAid.ShowAllRequest());
   }
   
   @FXML
	public void DonateBlood(ActionEvent event) {
	    Stage primaryStage = new Stage();
	    try {
	        FXMLLoader loader = new FXMLLoader(getClass().getResource("DonateToRecipient.fxml"));  
	        Parent root = loader.load();
	        Scene scene = new Scene(root);
	        primaryStage.setScene(scene);
	        primaryStage.show();

	        
	    } catch(Exception e) {
	        e.printStackTrace();
	    }
	}
}


