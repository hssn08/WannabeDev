package application;

import BusinessLogic.PulseAid;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

import java.net.URL;
import java.util.ResourceBundle;


public class ViewAllDonationsController implements Initializable {
	   @FXML
	   private Label DonationText;

	   @Override
	   public void initialize(URL location, ResourceBundle resources) {
	       String DonorList = PulseAid.getAllDonationAppointments();
	       DonationText.setText(DonorList);
	       System.out.println(PulseAid.getAllDonationAppointments());
	   }
	}


