package application;	
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import BusinessLogic.PulseAid;
import javafx.event.ActionEvent;
	

public class AddHospitalController {
	@FXML
	private TextField regno;
	@FXML
	private TextField hcity;
	@FXML
	private TextField hname;
	@FXML
	private TextField hstate;
	@FXML
	private TextField hcountry;
	@FXML
	private TextField Aneg;
	@FXML
	private TextField Apos;
	@FXML
	private TextField Bpos;
	@FXML
	private TextField Bneg;
	@FXML
	private TextField Opos;
	@FXML
	private TextField Oneg;
	@FXML
	private TextField ABpos;
	@FXML
	private TextField ABneg;




		public void AddHospital(ActionEvent event) {
		   String Regno = regno.getText();
		   String Hcity = hcity.getText();
		   String Hname = hname.getText();
		   String Hstate = hstate.getText();
		   String Hcountry = hcountry.getText();
		   String aneg = Aneg.getText();
		   String apos = Apos.getText();
		   String bpos = Bpos.getText();
		   String bneg = Bneg.getText();
		   String opos = Opos.getText();
		   String oneg = Oneg.getText();
		   String abpos = ABpos.getText();
		   String abneg = ABneg.getText();

		   if(Regno !=null && Hcity !=null &&Hname !=null &&Hstate !=null &&Hcountry !=null &&apos !=null &&aneg !=null &&bpos !=null &&bneg !=null &&opos !=null &&oneg !=null &&abpos !=null &&abneg!=null)
		   {
		       PulseAid.AddHospital(Regno,Hname,Hcity,Hstate,Hcountry,apos,aneg,bpos,bneg,opos,oneg,abpos,abneg);
		       Stage primaryStage=new Stage();
		       try {
		           Parent root = FXMLLoader.load(getClass().getResource("AdminMenu.fxml"));
		           Scene scene=new Scene(root);
		           primaryStage.setScene(scene);
		           primaryStage.show();
		           
		           Alert alert = new Alert(AlertType.ERROR);
			       alert.setTitle("Hospital added");
			       alert.showAndWait();
			       
		           
		       } catch(Exception e) {
		           e.printStackTrace();
		       }
		   }
		   else
		   {
		       //alert
		       Alert alert = new Alert(AlertType.ERROR);
		       alert.setTitle("Login Error");
		       alert.setHeaderText("PLS FILL ALL");
		       alert.setContentText("Please check BOXES.");
		       alert.showAndWait();
		   }
		}
		
	}
