package application;

import BusinessLogic.PulseAid;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;




public class RViewAppointmentController {
	@FXML
	private Label AppointmentText;
	@FXML
	private TextField RecipientID;

	// Event Listener on Button.onAction
	@FXML
	public void showAppointment(ActionEvent event) {
		String appintmentList = PulseAid.RGetAppointmentsByUsername(RecipientID.getText());
	       AppointmentText.setText(appintmentList);
	}
}


