package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import BusinessLogic.PulseAid;
import javafx.event.ActionEvent;


public class DonateToBloodCenterController {
	@FXML
	private Label hos;
	@FXML
	private TextField city;
	@FXML
	private TextField hregno;
	@FXML
	private TextField date;
	private String username;

	   public void setMyString(String myString) {
	       this.username = myString;
	   }
	// Event Listener on Button.onAction
	@FXML
	public void BookAppointment(ActionEvent event)
	{
		PulseAid.donationToHospital(username,city.getText(),hregno.getText(),date.getText());
		Stage primaryStage = new Stage();
		try {
			Alert alert = new Alert(AlertType.CONFIRMATION);
		       alert.setTitle("Appintment Booked");
		       alert.setHeaderText("BE There");
		       
		       alert.showAndWait();
			
		 FXMLLoader loader = new FXMLLoader(getClass().getResource("DonorMenu.fxml"));
		 Parent root = loader.load();
		 Scene scene = new Scene(root);
		 primaryStage.setScene(scene);
		 primaryStage.show();


		} catch(Exception e) {
		 e.printStackTrace();
		}
	}
	// Event Listener on Button.onAction
	@FXML
	public void ShowBloodCenter(ActionEvent event) {
		String haha = PulseAid.FindBloodCenter(city.getText());
	       hos.setText(haha);
	}
}

