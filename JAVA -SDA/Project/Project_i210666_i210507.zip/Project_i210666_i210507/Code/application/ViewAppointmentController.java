
package application;

import BusinessLogic.PulseAid;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

import java.net.URL;
import java.util.ResourceBundle;


public class ViewAppointmentController implements Initializable {
   @FXML
   private Label AppointmentText;
   private String username;
	public void setmystring(String Username) {
		// TODO Auto-generated method stub
		this.username=Username;
	}
   @Override
   public void initialize(URL location, ResourceBundle resources) {
       String appintmentList = PulseAid.GetAppointmentsByUsername(username);
       AppointmentText.setText(appintmentList);
       System.out.println(PulseAid.GetAppointmentsByUsername(username));
   }
}
