package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import BusinessLogic.PulseAid;
import javafx.event.ActionEvent;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.RadioButton;

public class RegisterRecipientController {
	@FXML
	private TextField userID;
	@FXML
	private TextField DOL;
	@FXML
	private TextField Bloodtype;
	@FXML
	private TextField weight;
	@FXML
	private TextField dob;
	@FXML
	private TextField address;
	@FXML
	private TextField phone;
	@FXML
	private TextField password;
	@FXML
	private TextField email;
	@FXML
	private TextField username;
	@FXML
	private RadioButton hasAlergy;
	
	
	
	@FXML
	public void RegisterRecipient(ActionEvent event)
	{
		String userid=userID.getText();
		String dol= DOL.getText();
		String bllodtype= Bloodtype.getText();
		
		String Weight = weight.getText();
		String Dob = dob.getText();
		String Address= address.getText();
		String Phone = phone.getText();
		String Password = password.getText();
		String Email = email.getText();
		String Username = username.getText();
		Boolean allergyStatus = hasAlergy.isSelected();
		if(userid !=null && dol !=null &&bllodtype !=null &&Weight !=null &&Dob !=null &&Address !=null &&Phone !=null &&Password !=null &&Email !=null &&Username !=null)
		   {
		       PulseAid.RegisterRecipient(userid,Username, Email, Password, Phone, Address,Dob , Weight , bllodtype, dol, allergyStatus);
		       Stage primaryStage=new Stage();
		       try {
		           Parent root = FXMLLoader.load(getClass().getResource("AdminMenu.fxml"));
		           Scene scene=new Scene(root);
		           primaryStage.setScene(scene);
		           primaryStage.show();
		           
		           Alert alert = new Alert(AlertType.INFORMATION);
			       alert.setTitle("Recipient Added");
			       alert.showAndWait();
			       
		           
		       } catch(Exception e) {
		           e.printStackTrace();
		       }
		   }
		   else
		   {
		       //alert
		       Alert alert = new Alert(AlertType.ERROR);
		       alert.setTitle("Login Error");
		       alert.setHeaderText("PLS FILL ALL");
		       alert.setContentText("Please check BOXES.");
		       alert.showAndWait();
		   }
	}
}
