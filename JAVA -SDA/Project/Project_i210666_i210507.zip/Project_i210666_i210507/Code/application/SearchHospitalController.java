package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

import BusinessLogic.PulseAid;
import javafx.event.ActionEvent;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;

public class SearchHospitalController {
	@FXML
	private TextField userID;
	@FXML
	private Label Hospital;

	// Event Listener on Button.onAction
	@FXML
	public void SearchHospital(ActionEvent event){
		String Hospitaltext = PulseAid.FindHospital(userID.getText());
	       Hospital.setText(Hospitaltext);
	       //System.out.println(PulseAid.ShowAllDonor());
	}
	// Event Listener on Button.onAction
	@FXML
	public void GoBack(ActionEvent event) throws IOException {
		Stage primaryStage=new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("DonorMenu.fxml"));
     Scene scene=new Scene(root);
     primaryStage.setScene(scene);
     primaryStage.show();
	}
}
