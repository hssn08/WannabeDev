package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import BusinessLogic.PulseAid;
import javafx.event.ActionEvent;


public class DonateToRecipientController {
	@FXML
	private Label res;
	@FXML
	private TextField city;
	@FXML
	private TextField hregno;
	@FXML
	private TextField date;
	@FXML
	private TextField Rregno;
	@FXML
	private Label hos;

	private String username;

	   public void setMyString(String myString) {
	       this.username = myString;
	   }
	// Event Listener on Button.onAction
	@FXML
	public void BookAppointment(ActionEvent event)
	{
		PulseAid.donationToRecipient(username,Rregno.getText(),city.getText(),hregno.getText(),date.getText());
		Stage primaryStage = new Stage();
		try {
			Alert alert = new Alert(AlertType.CONFIRMATION);
		       alert.setTitle("Appintment Booked");
		       alert.setHeaderText("BE There");
		       
		       alert.showAndWait();
			
		 FXMLLoader loader = new FXMLLoader(getClass().getResource("DonorMenu.fxml"));
		 Parent root = loader.load();
		 Scene scene = new Scene(root);
		 primaryStage.setScene(scene);
		 primaryStage.show();


		} catch(Exception e) {
		 e.printStackTrace();
		}
	}
	// Event Listener on Button.onAction
	@FXML
	public void ShowHospital(ActionEvent event) {
		String haha = PulseAid.FindHospital(city.getText());
	       hos.setText(haha);
	       
	    String haha1 = PulseAid.FindRecipient(city.getText());
	       res.setText(haha1);
	}
	
}



