
package application;

import BusinessLogic.*;
import DataBase.Connectivity;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;



public class DeleteAccountController {
	@FXML
	private TextField username;
	@FXML
	private PasswordField password;

	// Event Listener on Button.onAction
	@FXML
	public void DeleteAccount(ActionEvent event) {
		//PulseAid pulseaid=new PulseAid();
		String Username=username.getText();
		String Password=password.getText();
		if(PulseAid.LoginDonor(Username,Password))
		{
			Connectivity.getUserIdFromUsername(Username);
			PulseAid.DeleteDonor(Connectivity.getUserIdFromUsername(Username));
			Stage primaryStage = new Stage();
			try {
			   FXMLLoader loader = new FXMLLoader(getClass().getResource("DonorLoginPage.fxml"));
			   Parent root = loader.load();
			   Scene scene = new Scene(root);
			   primaryStage.setScene(scene);
			   primaryStage.show();
			   

			} catch(Exception e) {
			   e.printStackTrace();
			}
		}
		else
		{
			Alert alert = new Alert(AlertType.ERROR);
		       alert.setTitle("INNCORRECT PASSWORD");
		       alert.setHeaderText("TRY AGAIN");
		       alert.showAndWait();
		}
	}
}
