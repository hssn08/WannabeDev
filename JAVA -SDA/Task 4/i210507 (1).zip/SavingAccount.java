package studyopedia;

public class SavingAccount extends Account
{
    private double annualInterestRate;

    public SavingAccount(int accountNumber, Customer accountHolder, double annualInterestRate,int maxtransaction)
    {
        super(accountNumber, accountHolder,maxtransaction);
        this.annualInterestRate = annualInterestRate;
    }

    public double getAnnualInterestRate()
    {
        return annualInterestRate;
    }

    public void setAnnualInterestRate(double annualInterestRate)
    {
        this.annualInterestRate = annualInterestRate;
    }

    @Override
    public double makeDeposit(double depositAmount) 
    {    
        double previousBalance = checkBalance();
        double interest = previousBalance * (annualInterestRate / 100);
        super.makeDeposit(depositAmount + interest);
        return checkBalance();
    }

    @Override
    public double makeWithdrawal(double withdrawalAmount)
    {
        double previousBalance = checkBalance();
        double interest = previousBalance * (annualInterestRate / 100);
        super.makeWithdrawal(withdrawalAmount);
        return checkBalance();
    }

    @Override
    public double transferFromAcctToAnother(double transferAmount, Account destinationAccount)
    {    
        double previousBalance = checkBalance();
        double interest = previousBalance * (annualInterestRate / 100);
        super.transferFromAcctToAnother(transferAmount, destinationAccount);
        return checkBalance();
    }

    public double calculateZakat()
    {
        double zakat = 0.025 * checkBalance(); // Assuming 2.5% zakat rate
        return zakat;
    }

    public double calculateAnnualInterest()
    {
        return checkBalance() * (annualInterestRate / 100);
    }

    public void displayAllDeductions() 
    {
        double zakat = calculateZakat();
        double annualInterest = calculateAnnualInterest();
        System.out.println("Zakat Deduction: " + zakat);
        System.out.println("Annual Interest Deduction: " + annualInterest);
    }
}
