package studyopedia;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;


public class BankManagementSystem {

    public static void main(String[] args) {
        Admin admin = new Admin(20);
        Scanner scanner = new Scanner(System.in);
        Connection connection = null;
        String url = "jdbc:sqlserver://C:\\Users\\Abdul Wasay\\SQLEXPRESS;databaseName=Accounts;integratedSecurity=true;encrypt=false";

        try 
        {
            connection = DriverManager.getConnection(url);
            System.out.println("Connected to the database.");
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
            System.exit(1);
        }
        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Open New Account");
            System.out.println("2. Close Account");
            System.out.println("3. Login");
            System.out.println("4. Display Account Balance");
            System.out.println("5. Withdraw");
            System.out.println("6. Deposit");
            System.out.println("7. Transfer");
            System.out.println("8. Calculate Zakat");
            System.out.println("9. Calculate Interest");
            System.out.println("10. Calculate Tax");
            System.out.println("11. Display All Deductions");
            System.out.println("12. Display All Account Deductions");
            System.out.println("13. Specify Interest Rate");
            System.out.println("14. Display All Account Details");
            System.out.println("15. Exit");
            System.out.print("Select an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume the newline character

            switch (choice) {
                case 1:
                    openNewAccount(admin, scanner);
                    break;
                case 2:
                    closeAccount(admin, scanner);
                    break;
                case 3:
                    login(admin, scanner);
                    break;
                case 4:
                    checkBalance(admin, scanner);
                    break;
                case 5:
                    withdraw(admin, scanner);
                    break;
                case 6:
                    deposit(admin, scanner);
                    break;
                case 7:
                    transfer(admin, scanner);
                    break;
                case 8:
                    calculateZakat(admin, scanner);
                    break;
                case 9:
                    calculateInterest(admin, scanner);
                    break;
                case 10:
                    calculateTax(admin, scanner);
                    break;
                case 11:
                    displayAllDeductions(admin, scanner);
                    break;
                case 12:
                    displayAllAccountDeductions(admin, scanner);
                    break;
                case 13:
                    specifyInterestRate(admin, scanner);
                    break;
                case 14:
                    displayAllAccountDetails(admin, scanner);
                    break;
                case 15:
                    System.out.println("Exiting the program.");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
                    break;
            }
        }
    }

    private static void openNewAccount(Admin admin, Scanner scanner) {
    	 System.out.print("Enter Account Number: ");
    	    int accountNo = scanner.nextInt();
    	    scanner.nextLine();

    	    Customer customer = new Customer();

    	    System.out.print("Enter Customer Name: ");
    	    customer.setName(scanner.nextLine());

    	    System.out.print("Enter Customer Address: ");
    	    customer.setAddress(scanner.nextLine());

    	    System.out.print("Enter Customer CNIC: ");
    	    customer.setCNIC(scanner.nextLine());
    	    
    	    System.out.print("Enter Customer PhoneNo: ");
    	    customer.setPhoneNo(scanner.nextLine());

    	    System.out.print("Enter Initial Balance: ");
    	    double initialBalance = scanner.nextDouble();
    	    scanner.nextLine();

    	    System.out.print("Select Account Type (Saving/Checking): ");
    	    String accountType = scanner.nextLine();

    	    Account newAccount;

    	    if ("Saving".equalsIgnoreCase(accountType)) {
    	        System.out.print("Enter Interest Rate: ");
    	        double interestRate = scanner.nextDouble();
    	        scanner.nextLine();
    	        newAccount = admin.openNewAccount(accountNo, customer, initialBalance, interestRate, 0.0);
    	    } else if ("Checking".equalsIgnoreCase(accountType)) {
    	        System.out.print("Enter Transaction Fee: ");
    	        double transactionFee = scanner.nextDouble();
    	        scanner.nextLine();
    	        newAccount = admin.openNewCheckingAccount(accountNo, customer, initialBalance, transactionFee);
    	    } else {
    	        System.out.println("Invalid account type.");
    	        return;
    	    }

    	    
    	    String jdbcUrl = "jdbc:sqlserver://C:\\Users\\Abdul Wasay\\SQLEXPRESS;databaseName=Accounts;integratedSecurity=true;encrypt=false";
    	    

    	    try (Connection connection = DriverManager.getConnection(jdbcUrl)) 
    	    {
    	        String insertSQL = "INSERT INTO accounts (accountNo, customerName, address, phoneNo,CNIC, accountType, balance, interestRate, transactionFee,zakat,interest,tax) " +
    	                "VALUES (?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?)";
    	        try (PreparedStatement preparedStatement = connection.prepareStatement(insertSQL))
    	        {
    	            preparedStatement.setInt(1, newAccount.getAccountNo());
    	            preparedStatement.setString(2, customer.get_Name());
    	            preparedStatement.setString(3, customer.get_Address());
    	            preparedStatement.setString(4, customer.get_CNIC());
    	            preparedStatement.setString(5, customer.get_PhoneNo());
    	            preparedStatement.setString(6, accountType);
    	            preparedStatement.setDouble(7, initialBalance);
    	            preparedStatement.setDouble(8, (newAccount instanceof SavingAccount) ? ((SavingAccount) newAccount).getAnnualInterestRate() : 0.0);
    	            preparedStatement.setDouble(9, (newAccount instanceof CheckingAccount) ? ((CheckingAccount) newAccount).getTransactionFee() : 0.0);
    	            preparedStatement.setDouble(10, 0);
    	            preparedStatement.setDouble(11, 0);
    	            preparedStatement.setDouble(12, 0);
    	            int rowsAffected = preparedStatement.executeUpdate();
    	            if (rowsAffected > 0) 
    	            {
    	                System.out.println("Account created successfully. Account Number: " + newAccount.getAccountNo());
    	            } 
    	            else
    	            {
    	                System.out.println("Failed to create the account.");
    	            }
    	        }
    	    } 
    	    catch (SQLException e)
    	    {
    	        e.printStackTrace();
    	        System.out.println("Database connection error.");
    	    }
    }

    private static void closeAccount(Admin admin, Scanner scanner) 
    {
    	System.out.print("Enter Account Number to close: ");
        int accountNo = scanner.nextInt();
        scanner.nextLine();

        
        Account accountToClose = admin.findAccountByAccountNo(accountNo);
        
        if (accountToClose != null) {
            
        	 String jdbcUrl = "jdbc:sqlserver://C:\\Users\\Abdul Wasay\\SQLEXPRESS;databaseName=Accounts;integratedSecurity=true;encrypt=false";
     	    

            try (Connection connection = DriverManager.getConnection(jdbcUrl)) 
            {
                String deleteSQL = "DELETE FROM accounts WHERE accountNo = ?";
                try (PreparedStatement preparedStatement = connection.prepareStatement(deleteSQL))
                {
                    preparedStatement.setInt(1, accountToClose.getAccountNo());
                    int rowsAffected = preparedStatement.executeUpdate();
                    if (rowsAffected > 0)
                    {
                        
                        boolean closed = admin.closeAccount(accountToClose);
                        if (closed) 
                        {
                            System.out.println("Account closed successfully.");
                        } 
                        else
                        {
                            System.out.println("Failed to close the account.");
                        }
                    } 
                    else
                    {
                        System.out.println("Failed to delete the account record from the database.");
                    }
                }
            } 
            catch (SQLException e)
            {
                e.printStackTrace();
                System.out.println("Database connection error.");
            }
        }
        else
        {
            System.out.println("Account not found.");
        }
    }

    private static void login(Admin admin, Scanner scanner) 
    {
        System.out.print("Enter Account Number: ");
        int accountNo = scanner.nextInt();
        scanner.nextLine();

        Account account = admin.findAccountByAccountNo(accountNo);

        if (account == null)
        {
            System.out.println("Account not found.");
            return;
        }

        System.out.print("Enter Customer Name: ");
        String customerName = scanner.nextLine();

        if (validateLogin(account, customerName))
        {
            System.out.println("Login successful.");
        } 
        else
        {
            System.out.println("Login failed. Please check your credentials.");
        }
    }

    private static boolean validateLogin(Account account, String customerName)
    {
        
    	 String jdbcUrl = "jdbc:sqlserver://--------\\SQLEXPRESS;databaseName=Accounts;integratedSecurity=true;encrypt=false";
  	    
        try (Connection connection = DriverManager.getConnection(jdbcUrl)) 
        {
            String selectSQL = "SELECT * FROM accounts WHERE accountNo = ? AND customerName = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(selectSQL))
            {
                preparedStatement.setInt(1, account.getAccountNo());
                preparedStatement.setString(2, customerName);
                ResultSet resultSet = preparedStatement.executeQuery();
                return resultSet.next(); // If a record is found, the login is successful
            }
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
            System.out.println("Database connection error.");
            return false;
        }
    }

    private static void checkBalance(Admin admin, Scanner scanner)
    {
    	System.out.print("Enter Account Number: ");
        int accountNo = scanner.nextInt();
        scanner.nextLine();

        Account account = admin.findAccountByAccountNo(accountNo);
        if (account == null)
        {
            System.out.println("Account not found.");
            return;
        }

        String jdbcUrl = "jdbc:sqlserver://C:\\Users\\Abdul Wasay\\SQLEXPRESS;databaseName=Accounts;integratedSecurity=true;encrypt=false";
  	 
        try (Connection connection = DriverManager.getConnection(jdbcUrl))
        {
            String selectSQL = "SELECT balance FROM accounts WHERE accountNo = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(selectSQL))
            {
                preparedStatement.setInt(1, accountNo);
                ResultSet resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) 
                {
                    double balance = resultSet.getDouble("balance");
                    System.out.println("Account Balance: " + balance);
                } 
                else
                {
                    System.out.println("Account not found in the database.");
                }
            }
        }
        catch (SQLException e) 
        {
            e.printStackTrace();
            System.out.println("Database connection error.");
        }
    }

    private static void withdraw(Admin admin, Scanner scanner) 
    {
    	System.out.print("Enter Account Number: ");
        int accountNo = scanner.nextInt();
        scanner.nextLine();

        Account account = admin.findAccountByAccountNo(accountNo);
        if (account == null)
        {
            System.out.println("Account not found.");
            return;
        }

        System.out.print("Enter Withdrawal Amount: ");
        double amount = scanner.nextDouble();
        scanner.nextLine();

        // Now, let's connect to the database to update the balance
       
        String jdbcUrl = "jdbc:sqlserver://C:\\Users\\Abdul Wasay\\SQLEXPRESS;databaseName=Accounts;integratedSecurity=true;encrypt=false";
     	 
        try (Connection connection = DriverManager.getConnection(jdbcUrl))
        {
            // Check if the withdrawal is valid
            double balance = account.checkBalance();
            if (balance >= amount) {
                String updateSQL = "UPDATE accounts SET balance = balance - ? WHERE accountNo = ?";
                try (PreparedStatement preparedStatement = connection.prepareStatement(updateSQL))
                {
                    preparedStatement.setDouble(1, amount);
                    preparedStatement.setInt(2, accountNo);
                    int rowsAffected = preparedStatement.executeUpdate();

                    if (rowsAffected > 0) 
                    {
                        balance -= amount;
                        System.out.println("Withdrawal successful. New Balance: " + balance);
                    } 
                    else 
                    {
                        System.out.println("Failed to update the balance in the database.");
                    }
                }
            } 
            else 
            {
                System.out.println("Insufficient balance for withdrawal.");
            }
        } catch (SQLException e)
        {
            e.printStackTrace();
            System.out.println("Database connection error.");
        }
    }

    private static void deposit(Admin admin, Scanner scanner) 
    {
    	System.out.print("Enter Account Number: ");
        int accountNo = scanner.nextInt();
        scanner.nextLine();

        Account account = admin.findAccountByAccountNo(accountNo);
        if (account == null) 
        {
            System.out.println("Account not found.");
            return;
        }

        System.out.print("Enter Deposit Amount: ");
        double amount = scanner.nextDouble();
        scanner.nextLine();

        // Now, let's connect to the database to update the balance
        String jdbcUrl = "jdbc:sqlserver://C:\\Users\\Abdul Wasay\\SQLEXPRESS;databaseName=Accounts;integratedSecurity=true;encrypt=false";
    	 
        try (Connection connection = DriverManager.getConnection(jdbcUrl))
        {
            String updateSQL = "UPDATE accounts SET balance = balance + ? WHERE accountNo = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(updateSQL)) {
                preparedStatement.setDouble(1, amount);
                preparedStatement.setInt(2, accountNo);
                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0)
                {
                    double balance = account.makeDeposit(amount);
                    System.out.println("Deposit successful. New Balance: " + balance);
                } 
                else
                {
                    System.out.println("Failed to update the balance in the database.");
                }
            }
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
            System.out.println("Database connection error.");
        }
        
    }

    private static void transfer(Admin admin, Scanner scanner) 
    {
    	System.out.print("Enter Source Account Number: ");
        int sourceAccountNo = scanner.nextInt();
        scanner.nextLine();

        Account sourceAccount = admin.findAccountByAccountNo(sourceAccountNo);
        if (sourceAccount == null)
        {
            System.out.println("Source Account not found.");
            return;
        }

        System.out.print("Enter Destination Account Number: ");
        int destinationAccountNo = scanner.nextInt();
        scanner.nextLine();

        Account destinationAccount = admin.findAccountByAccountNo(destinationAccountNo);
        if (destinationAccount == null) 
        {
            System.out.println("Destination Account not found.");
            return;
        }

        System.out.print("Enter Transfer Amount: ");
        double amount = scanner.nextDouble();
        scanner.nextLine();

        String jdbcUrl = "jdbc:sqlserver://--------\\SQLEXPRESS;databaseName=Accounts;integratedSecurity=true;encrypt=false";
   	 

        try (Connection connection = DriverManager.getConnection(jdbcUrl))
        {
            
            double sourceBalance = sourceAccount.checkBalance();
            if (sourceBalance >= amount) 
            {
                connection.setAutoCommit(false); 
                try 
                {
                    String updateSourceSQL = "UPDATE accounts SET balance = balance - ? WHERE accountNo = ?";
                    try (PreparedStatement sourceStatement = connection.prepareStatement(updateSourceSQL))
                    {
                        sourceStatement.setDouble(1, amount);
                        sourceStatement.setInt(2, sourceAccountNo);
                        int sourceRowsAffected = sourceStatement.executeUpdate();

                        String updateDestinationSQL = "UPDATE accounts SET balance = balance + ? WHERE accountNo = ?";
                        try (PreparedStatement destinationStatement = connection.prepareStatement(updateDestinationSQL)) 
                        {
                            destinationStatement.setDouble(1, amount);
                            destinationStatement.setInt(2, destinationAccountNo);
                            int destinationRowsAffected = destinationStatement.executeUpdate();

                            if (sourceRowsAffected > 0 && destinationRowsAffected > 0) 
                            {
                                connection.commit(); 
                                sourceBalance -= amount;
                                System.out.println("Transfer successful. New Balance of Source Account: " + sourceBalance);
                            }
                            else 
                            {
                                connection.rollback(); 
                                System.out.println("Failed to update the balances in the database.");
                            }
                        }
                    }
                } 
                catch (SQLException ex) 
                {
                    connection.rollback(); 
                    ex.printStackTrace();
                    System.out.println("Transaction failed.");
                } 
                finally 
                {
                    connection.setAutoCommit(true);
                }
            }
            else
            {
                System.out.println("Insufficient balance for the transfer.");
            }
        } 
        catch (SQLException e)
        {
            e.printStackTrace();
            System.out.println("Database connection error.");
        }
    }

    private static void calculateZakat(Admin admin, Scanner scanner)
    {
    	System.out.print("Enter Account Number: ");
        int accountNo = scanner.nextInt();
        scanner.nextLine();

        SavingAccount account = (SavingAccount) admin.findAccountByAccountNo(accountNo);
        if (account == null) 
        {
            System.out.println("Account not found or not a Saving Account.");
            return;
        }

        double zakat = account.calculateZakat();
        System.out.println("Zakat Amount: " + zakat);

        
        String jdbcUrl = "jdbc:sqlserver://C:\\Users\\Abdul Wasay\\SQLEXPRESS;databaseName=Accounts;integratedSecurity=true;encrypt=false";
      	 
        try (Connection connection = DriverManager.getConnection(jdbcUrl)) 
        {
            String updateSQL = "UPDATE accounts SET zakat = ? WHERE accountNo = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(updateSQL))
            {
                preparedStatement.setDouble(1, zakat);
                preparedStatement.setInt(2, accountNo);
                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0)
                {
                    System.out.println("Zakat amount updated in the 'accounts' table.");
                } 
                else 
                {
                    System.out.println("Failed to update the Zakat amount in the database.");
                }
            }
        } 
        catch (SQLException e)
        {
            e.printStackTrace();
            System.out.println("Database connection error.");
        }
    }

    private static void calculateInterest(Admin admin, Scanner scanner)
    {
    	System.out.print("Enter Account Number: ");
        int accountNo = scanner.nextInt();
        scanner.nextLine();

        SavingAccount account = (SavingAccount) admin.findAccountByAccountNo(accountNo);
        if (account == null)
        {
            System.out.println("Account not found or not a Saving Account.");
            return;
        }

        double interest = account.calculateAnnualInterest();
        System.out.println("Interest Amount: " + interest);

        String jdbcUrl = "jdbc:sqlserver://C:\\Users\\Abdul Wasay\\SQLEXPRESS;databaseName=Accounts;integratedSecurity=true;encrypt=false";
     	 
        try (Connection connection = DriverManager.getConnection(jdbcUrl))
        {
            String updateSQL = "UPDATE accounts SET interest = ? WHERE accountNo = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(updateSQL))
            {
                preparedStatement.setDouble(1, interest);
                preparedStatement.setInt(2, accountNo);
                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0) 
                {
                    System.out.println("Interest amount updated in the 'accounts' table.");
                } 
                else
                {
                    System.out.println("Failed to update the interest amount in the database.");
                }
            }
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
            System.out.println("Database connection error.");
        }
    }

    private static void calculateTax(Admin admin, Scanner scanner)
    {
    	System.out.print("Enter Account Number: ");
        int accountNo = scanner.nextInt();
        scanner.nextLine();

        CheckingAccount account = (CheckingAccount) admin.findAccountByAccountNo(accountNo);
        if (account == null) {
            System.out.println("Account not found or not a Checking Account.");
            return;
        }

        double tax = account.calculateTax();
        System.out.println("Tax Amount: " + tax);

        String jdbcUrl = "jdbc:sqlserver://C:\\Users\\Abdul Wasay\\SQLEXPRESS;databaseName=Accounts;integratedSecurity=true;encrypt=false";
    	 
        try (Connection connection = DriverManager.getConnection(jdbcUrl)) 
        {
            String updateSQL = "UPDATE accounts SET tax = ? WHERE accountNo = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(updateSQL)) 
            {
                preparedStatement.setDouble(1, tax);
                preparedStatement.setInt(2, accountNo);
                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0)
                {
                    System.out.println("Tax amount updated in the 'accounts' table.");
                } 
                else
                {
                    System.out.println("Failed to update the tax amount in the database.");
                }
            }
        } 
        catch (SQLException e)
        {
            e.printStackTrace();
            System.out.println("Database connection error.");
        }
    }

    private static void displayAllDeductions(Admin admin, Scanner scanner)
    {
        System.out.print("Enter Account Number: ");
        int accountNo = scanner.nextInt();
        scanner.nextLine();

        Account account = admin.findAccountByAccountNo(accountNo);
        if (account == null)
        {
            System.out.println("Account not found.");
            return;
        }

        if (account instanceof SavingAccount)
        {
            SavingAccount savingAccount = (SavingAccount) account;
            System.out.println("Zakat Deduction: " + savingAccount.calculateZakat());
            System.out.println("Interest Deduction: " + savingAccount.calculateAnnualInterest());
        } 
        else if (account instanceof CheckingAccount) 
        {
            CheckingAccount checkingAccount = (CheckingAccount) account;
            System.out.println("Tax Deduction: " + checkingAccount.calculateTax());
            System.out.println("Transaction Fees Deduction: " + checkingAccount.applyTransactionFees());
        }
    }

    private static void displayAllAccountDeductions(Admin admin, Scanner scanner) 
    {
        admin.displayAllAccountDeductions();
    }

    private static void specifyInterestRate(Admin admin, Scanner scanner)
    {
    	 System.out.print("Enter Account Number: ");
    	    int accountNo = scanner.nextInt();
    	    scanner.nextLine();

    	    SavingAccount account = (SavingAccount) admin.findAccountByAccountNo(accountNo);
    	    if (account == null) 
    	    {
    	        System.out.println("Account not found or not a Saving Account.");
    	        return;
    	    }

    	    System.out.print("Enter New Interest Rate: ");
    	    double interestRate = scanner.nextDouble();
    	    scanner.nextLine();

    	    double newInterestRate = admin.specifyInterestRate(account, interestRate);
    	    if (newInterestRate != -1) {
    	        System.out.println("Interest Rate updated to: " + newInterestRate);

    	        String jdbcUrl = "jdbc:sqlserver://C:\\Users\\Abdul Wasay\\SQLEXPRESS;databaseName=Accounts;integratedSecurity=true;encrypt=false";
    	    	 
    	        try (Connection connection = DriverManager.getConnection(jdbcUrl)) 
    	        {
    	            String updateSQL = "UPDATE accounts SET interestRate = ? WHERE accountNo = ?";
    	            try (PreparedStatement preparedStatement = connection.prepareStatement(updateSQL)) 
    	            {
    	                preparedStatement.setDouble(1, newInterestRate);
    	                preparedStatement.setInt(2, accountNo);
    	                int rowsAffected = preparedStatement.executeUpdate();

    	                if (rowsAffected > 0)
    	                {
    	                    System.out.println("Interest Rate updated in the 'accounts' table.");
    	                }
    	                else
    	                {
    	                    System.out.println("Failed to update the interest rate in the database.");
    	                }
    	            }
    	        } 
    	        catch (SQLException e)
    	        {
    	            e.printStackTrace();
    	            System.out.println("Database connection error.");
    	        }
    	    } 
    	    else
    	    {
    	        System.out.println("Failed to update the interest rate.");
    	    }
    }

    private static void displayAllAccountDetails(Admin admin, Scanner scanner)
    {
        admin.displayAllAccountDetails();
    }
}
