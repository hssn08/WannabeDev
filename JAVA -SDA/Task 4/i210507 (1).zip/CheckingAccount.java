package studyopedia;

public class CheckingAccount extends Account
{
    private double transactionFee;
    private int transactionFeeCounter;

    public CheckingAccount(int accountNumber, Customer accountHolder, double transactionFee,int maxtransaction) 
    {
        super(accountNumber, accountHolder,maxtransaction);
        this.transactionFee = transactionFee;
        this.transactionFeeCounter = 0;
    }

    public double getTransactionFee()
    {
        return transactionFee;
    }

    public void setTransactionFee(double transactionFee)
    {
        this.transactionFee = transactionFee;
    }

    public double calculateTax()
    {
        double balance = checkBalance();
        double tax = 0.05 * balance; 
        return tax;
    }

    public double applyTransactionFees()
    {
        if (transactionFeeCounter < 2) 
        {
            transactionFeeCounter++;
            return 0; 
        } 
        else 
        {
            return transactionFee;
        }
    }

    @Override
    public double makeDeposit(double amount) 
    {
        double fee = applyTransactionFees();
        double depositAmount = amount - fee;
        super.makeDeposit(depositAmount);
        return checkBalance();
    }

    @Override
    public double makeWithdrawal(double amount)
    {
    	 if (checkBalance() < amount) 
    	 {
             if (amount <= 5000 && amount >= 0) 
             {
                 super.makeWithdrawal(amount);
                 applyTransactionFees();
             } 
             else 
             {
                 System.out.println("Cannot withdraw, limit exceeded");
             }
         } 
    	 else 
    	 {
             super.makeWithdrawal(amount);
             applyTransactionFees();
         }
        return checkBalance();
    }

    @Override
    public double transferFromAcctToAnother(double amount, Account destinationAccount) 
	{
		  double fee = applyTransactionFees();
	      double depositAmount = amount - fee;
	      super.transferFromAcctToAnother(depositAmount, destinationAccount);
	      return checkBalance();
       
    }

    public void displayAllDeductions() {
        double tax = calculateTax();
        double transactionFees = (transactionFeeCounter - 2) * transactionFee;
        System.out.println("Tax Deduction: " + tax);
        System.out.println("Transaction Fees Deduction: " + transactionFees);
    }
}
