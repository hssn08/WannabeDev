package studyopedia;


public class Customer 
{
	
	private String Name;
	private String Address;
	private  String PhoneNo;
	private String CNIC;
	private int AccountNo;
	private String Acc_type;
	public Customer() 
	{
		
	}
	
	public void setName(String Name)
	{
		this.Name =Name;
	}
	public void setCNIC(String CNIC)
	{
		this.CNIC =CNIC;
	}
	
	public void setAddress(String Address)
	{
		this.Address = Address;
	}
	public void setType(String Acc_type)
	{
		this.Acc_type = Acc_type;
	}
	public void setPhoneNo(String PhoneNo)
	{
		this.PhoneNo = PhoneNo;
	}
	public void setAccNo(int AccountNo)
	{
		if(this.AccountNo != AccountNo)
		{
		   this.AccountNo = AccountNo;
		}
		else
		{
			System.out.println("Already register");
		}
	}
	public String get_Name()
	{
		return Name;
	}
	public String get_CNIC()
	{
		return CNIC;
	}
	
	public String get_Address()
	{
		return Address;
	}
	
	public String get_PhoneNo()
	{
		return PhoneNo;
	}
	
	public String get_type()
	{
		return Acc_type;
	}
	
	public int get_AccNo()
	{
	    return AccountNo;
	}
	
	
}