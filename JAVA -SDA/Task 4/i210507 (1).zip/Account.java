package studyopedia;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Arrays;

public class Account
{
    private double balance;
    private Date dateCreated;
    private int accountNo;
    private int counter;
    private Customer customer;
    private Transaction[] transactions;
    private int transactionCount;

    public Account(int accountNo, Customer customer, int maxTransactions) 
    {
        this.accountNo = accountNo;
        this.customer = customer;
        this.balance = 0.0;
        this.dateCreated = new Date();
        this.counter = 0;
        this.transactions = new Transaction[maxTransactions];
        this.transactionCount = 0;
    }

    public double checkBalance() 
    {
        return balance;
    }

    public void printStatement()
    {
        System.out.println("Customer Name: " + customer.get_Name());
        System.out.println("Account Number: " + accountNo);
        System.out.println("Address: " + customer.get_Address());
        System.out.println("Phone Number: " + customer.get_PhoneNo());
        System.out.println("CNIC: " + customer.get_CNIC());

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");

        for (int i = 0; i < transactionCount; i++) 
        {
            Transaction transaction = transactions[i];
            System.out.println("Date: " + sdf.format(transaction.getDate()));
            System.out.println("Transaction Type: " + transaction.getType());
            System.out.println("Amount: " + transaction.getAmount());
            System.out.println("Balance: " + transaction.getBalance());
        }
    }

    public double makeDeposit(double amount) 
    {
        if (amount > 0) 
        {
            balance += amount;
            counter++;
            Transaction transaction = new Transaction("Deposit", amount, balance);
            addTransaction(transaction);
        }
        return balance;
    }

    public double transferFromAcctToAnother(double amount, Account destinationAccount) 
    {
        if (amount > 0 && balance >= amount) 
        {
            balance -= amount;
            destinationAccount.makeDeposit(amount);
            counter++;
            Transaction transaction = new Transaction("Transfer", amount, balance);
            addTransaction(transaction);
        }
        return balance;
    }

    public double makeWithdrawal(double amount) 
    {
        if (amount > 0 && balance >= amount) 
        {
            balance -= amount;
            counter++;
            Transaction transaction = new Transaction("Withdrawal", amount, balance);
            addTransaction(transaction);
        }
        return balance;
    }

    public int getAccountNo() 
    {
        return accountNo;
    }

    public int getCounter() 
    {
        return counter;
    }

    public Customer getCustomer()
    {   
        return customer;
    }

    private void addTransaction(Transaction transaction) 
    {
        if (transactionCount < transactions.length) {
            transactions[transactionCount] = transaction;
            transactionCount++;
        }
    }
}