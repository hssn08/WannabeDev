package studyopedia;

public class Admin
{
    private Account[] accountList;
    private int accountCount;

    public Admin(int maxAccounts) 
    {
        this.accountList = new Account[maxAccounts];
        this.accountCount = 0;
    }

    
	public Account[] getAccountList() 
    {
        return accountList;
    }

    public void setAccountList(Account[] accountList) 
    {
        this.accountList = accountList;
    }

    public Account openNewAccount(int accountNo, Customer customer, double initialBalance, double interestRate, double transactionFee)
    {
        SavingAccount newAccount = new SavingAccount(accountNo, customer, interestRate, accountNo);
        newAccount.makeDeposit(initialBalance);
        accountList[accountCount] = newAccount;
        accountCount++;
        return newAccount;
    }

    public Account openNewCheckingAccount(int accountNo, Customer customer, double initialBalance, double transactionFee) 
    {
        CheckingAccount newAccount = new CheckingAccount(accountNo, customer, transactionFee, accountNo);
        newAccount.makeDeposit(initialBalance);
        accountList[accountCount] = newAccount;
        accountCount++;
        return newAccount;
    }

    public boolean closeAccount(Account account)
    {
        for (int i = 0; i < accountCount; i++) {
            if (accountList[i] == account && account.checkBalance() == 0) {
                accountList[i] = null;
                return true;
            }
        }
        return false;
    }

    public boolean login(Customer customer, int accNo)
    {
        Account account = findAccountByAccountNo(accNo);

        if (account != null && account.getCustomer() == customer) 
        {
            return true; 
        }

        return false; 
    }

    public double specifyInterestRate(SavingAccount account, double interestRate)
    {
        for (int i = 0; i < accountCount; i++) {
            if (accountList[i] == account) {
                account.setAnnualInterestRate(interestRate);
                return interestRate;
            }
        }
        return -1; 
    }

    public void displayAllAccountDetails()
    {
        for (int i = 0; i < accountCount; i++) {
            Account account = accountList[i];
            if (account != null) {
                Customer customer = account.getCustomer();
                System.out.println("Account Number: " + account.getAccountNo());
                System.out.println("Customer Name: " + customer.get_Name());
                System.out.println("Address: " + customer.get_Address());
                System.out.println("Phone Number: " + customer.get_PhoneNo());
                System.out.println("CNIC: " + customer.get_CNIC());
                System.out.println("Balance: " + account.checkBalance());

                if (account instanceof SavingAccount)
                {
                    SavingAccount savingAccount = (SavingAccount) account;
                    System.out.println("Interest Rate: " + savingAccount.getAnnualInterestRate());
                    System.out.println("Account Type: Saving Account");
                }
                else if (account instanceof CheckingAccount)
                {
                    CheckingAccount checkingAccount = (CheckingAccount) account;
                    System.out.println("Transaction Fee: " + checkingAccount.getTransactionFee());
                    System.out.println("Account Type: Checking Account");
                }

                System.out.println();
            }
        }
    }

    public void displayAllAccountDeductions()
    {
        for (int i = 0; i < accountCount; i++) {
            Account account = accountList[i];
            if (account != null) {
                System.out.println("Account Number: " + account.getAccountNo());
                if (account instanceof SavingAccount)
                {
                    SavingAccount savingAccount = (SavingAccount) account;
                    System.out.println("Zakat Deduction: " + savingAccount.calculateZakat());
                    System.out.println("Interest Deduction: " + savingAccount.calculateAnnualInterest());
                } 
                else if (account instanceof CheckingAccount)
                {
                    CheckingAccount checkingAccount = (CheckingAccount) account;
                    System.out.println("Tax Deduction: " + checkingAccount.calculateTax());
                    System.out.println("Transaction Fees Deduction: " + checkingAccount.applyTransactionFees());
                }
                System.out.println();
            }
        }
    }

    Account findAccountByAccountNo(int accountNo)
    {
        for (int i = 0; i < accountCount; i++) {
            if (accountList[i] != null && accountList[i].getAccountNo() == accountNo) {
                return accountList[i];
            }
        }
        return null; 
    }
}

