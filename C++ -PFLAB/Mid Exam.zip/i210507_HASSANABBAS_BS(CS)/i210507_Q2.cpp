#include<iostream>
using namespace std;
int main(){
char x,y,z;
int a,b,c,d,e,f,bill;
cout<<"Choose from main menu"<<endl;
cout<<"*****************"<<endl;
cout<<"1: APPETIZERS AND STARTERS"<<endl;
cout<<"2: LOADED FRIES"<<endl;
cout<<"3: FAST FOODS"<<endl;
cin>> x;
switch(x){
case 1:
cout<<"1: BREADS AND NAANS"<<endl;
cout<<"2: MEATY BITES"<<endl;
cout<<"3: WINGS"<<endl;
cout<<"4: FRIES"<< endl;
cin>> a;
switch(a){
case 1:
cout<<"108: \tRs.445"<<endl;
cout<<"107: \tRs.445"<<endl;
cout<<"820: \tRs.525"<<endl;
cout<<"328: \tRs.295"<<endl;
cout<<"329: \tRs.435"<<endl;
cin>> d;
switch(d){
case 108:
bill+=445;
break;
case 107:
bill+=445;
break;
case 820:
bill+=525;
break;
case 328:
bill+=295;
break;
case 329:
bill+=435;
break;
}
break;
}
break;
case 2:
cout<<"1: LOADED FRIES"<<endl;
cout<<"2: SOUPS"<<endl;
cin>>b;
break;
case 3:
cout<<"223: Chicken Tikka Burger\tRs.635"<<endl;
cout<<"837: Chicken Streak Burger\tRs.825"<<endl;
cout<<"200: Grilled Chicken Burger\tRs.645"<<endl;
break;
}
return 0;
}

