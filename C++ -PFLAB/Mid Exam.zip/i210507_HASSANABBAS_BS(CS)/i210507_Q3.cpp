#include<iostream>
using namespace std;
int checkPerfectNumber(int);
int main(){
int x,y;
cout<<"Enter number: ";
cin>>x;
if(x>0){
checkPerfectNumber(x);
}
else
return 0;
}
int checkPerfectNumber(int z){
int a=1,b=0;
while(a<z){
if(z%a==0){
b+=a;
}
a++;
}
if(b==z){
cout<<z<<" is PERFECT NUMBER";
}
else{
cout<<z<<" is NOT PERFECT NUMBER";
}
}
