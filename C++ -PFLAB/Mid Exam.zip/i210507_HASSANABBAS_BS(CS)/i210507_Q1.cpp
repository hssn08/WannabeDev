#include<iostream>
using namespace std;
int display_date(int);
int main(){
int x;
cout<<"Enter seconds: ";
cin>>x;
display_date(x);
return 0;
}
int display_date(int z){
int a,b,c,d,e,f;
a=z/(60*60*24*365);
if(a<1){
a=0;
}
else{
z=z-a*(60*60*24*365);
}
b=z/(60*60*24*30);
if(b<1){
b=0;
}
else{
z=z-b*(60*60*24*30);
}
c=z/(60*60*24);
if(c<1){
c=0;
}
else{
z=z-c*(60*60*24);
}
d=z/(60*60);
if(d<1){
d=0;
}
else{
z=z-d*(60*60);
}
e=z/(60);
if(e<1){
e=0;
}
else{
z=z-e*(60);
}
f=z;
cout<<"Years = "<<a<<endl;
cout<<"Months = "<<b<<endl;
cout<<"Days = "<<c<<endl;
cout<<"Hours = "<<d<<endl;
cout<<"Minutes = "<<e<<endl;
cout<<"Seconds = "<<f<<endl;
}



