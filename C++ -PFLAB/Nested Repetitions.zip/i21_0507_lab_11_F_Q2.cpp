#include<iostream>
using namespace std;
int main(){
	int N,y,z;
	cout<<"Enter number:";
	cin>>N;
	for(y=2;y<=N;y++){
		cout<<endl;
		cout<<"*** Table of "<<y<<" ***"<<endl;
		cout<<endl;
	for(z=1;z<=10;z++){
		cout<<z<<" * "<< y<< " = "<<z*y<<endl;
	}	
	}
	return 0;
}
