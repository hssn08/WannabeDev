#include<iostream>
using namespace std;
int main(){
	int x, y, a, b,even=0,avg=0;
	cout<<"Enter the starting value: "<<endl;
	cin>>x;
	a=x;
	cout<<"Enter the ending value: "<<endl;
	cin>>y;
	b=y;
	while(x<=y){
		if(x%2==0){
		even+=x;
		avg++;
	}
		x++;
	}
	cout<<"Sum of even numbers is:"<<even<<endl;
	cout<<"Average of even numbers from "<<a<<" to "<<b<<" is: "<<even/avg<<endl;
	return 0;
}
