#include<iostream>
using namespace std;
int main(){
	int x,y=1,z=1;
	char i;
	cout<<"Enter number of rows:";
	cin>>x;
	while(y<=x){
		z=1;
		i='a';
	while(z<=y){
		cout<<i;
		z++;
		i++;
	}
	y++;
		cout<<endl;
	}
	return 0;
}
	
	
	
