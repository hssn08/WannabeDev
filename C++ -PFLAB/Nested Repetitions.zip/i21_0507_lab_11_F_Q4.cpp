#include<iostream>
using namespace std;
int main(){
	int x,y;
	for(x=1;x<=10;x++){
		for(y=10;y>=x;y--){
			cout<<" ";
		}
		for(int z=1;z<=x;z++){
		cout<<"*";
	}
	cout<<endl;
}
return 0;
}
