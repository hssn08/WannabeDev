#include<iostream>
using namespace std;
int main(){
int *pointer;
int small;
int big;
int array[5];
pointer=array;


cout<<"Enter the value of Array"<<endl;


for(int i=0;i<5;i++){
cout<<"Array ["<<i+1<<"] = ";
cin>>*(pointer+i);
}


small=*(pointer);
big=*(pointer);


for(int i=1;i<5;i++){
if(small>*(pointer+i)){
small=*(pointer+i);
}
}


cout<<"Smallest= "<<small<<endl;


for(int i=1;i<5;i++){
if(big<*(pointer+i)){
big=*(pointer+i);
}
}


cout<<"Largest= "<<big<<endl;
}
