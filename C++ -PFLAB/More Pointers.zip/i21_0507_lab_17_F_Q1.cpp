#include<iostream>
using namespace std;
int main(){
int *pointer;
int array[5];
pointer=array;
for(int i=0;i<5;i++){
cout<<"Array ["<<i+1<<"] = ";
cin>>*(pointer+i);
}
for(int i=0;i<5;i++){
cout<<*(pointer+i);
}
cout<<endl;
for(int j=4;j>=0;j--){
cout<<*(pointer+j);
}
}
