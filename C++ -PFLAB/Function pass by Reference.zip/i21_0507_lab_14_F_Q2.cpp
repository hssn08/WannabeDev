#include<iostream>
using namespace std;
int hours(int&,int);
int minutes(int,int&);
int main(){
	int x,y,z;
	cout<<"Enter hours: ";
	cin>>x;
	cout<<"Enter minutes: ";
	cin>>y;
	cout<<"CONVERSION"<<endl;
	cout<<"1-All into hours"<<endl;
	cout<<"2-All into minutes"<<endl;
	cin>>z;
	switch(z){
		case 1: 
		hours(x,y);
		cout<<"Hours: "<<x;
		break;
		case 2: 
		minutes(x,y);
		cout<<"Minutes: "<<y;
	}
}
int hours(int &x, int y){
	x+=y/60;
}
int minutes(int x, int &y){
	y+=x*60;
}
