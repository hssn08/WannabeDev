#include<iostream>
#include<cmath>
#include<iomanip>
using namespace std;
int square(int&);
int power(int,int, int&);
int main(){
	int x,y,result;
	cout<<"Enter a value: ";
	cin>>x;
	cout<<"Numbers\tSquares\tPowers"<<endl;
	for(int i=1;i<=10;i++){
		y=i;
		power(x,i,result);
		square(y);
	cout<<i<<"\t"<<y<<"\t"<<result<<endl;
	}
	return 0;
}
int square(int &y){
	y=y*y;
}
int power(int x,int i, int &result){
	int k;
	result=1;
	for(k=1;k<=i;k++){
		result*=x;
	}
}
