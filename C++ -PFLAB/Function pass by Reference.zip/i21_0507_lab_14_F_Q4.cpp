#include<iostream>
using namespace std;
int order(int&,int&,int&);
int main(){
int x,y,z;
cout<<"Enter the 3 number: ";
cin>>x>>y>>z;
cout<<"Before ordering: "<<x<<" "<<y<<" "<<z<<" "<<endl;
cout<<"After ordering: ";
order(x,y,z);
}
int order(int &x,int &y,int &z){
	if(x<y&&x<z){
		cout<<x<<" ";
     if(y<z){
     	cout<<y<<" "<<z;
    
	 }
	 if(z<y){
     	cout<<z<<" "<<y;
    
	 }
	}
	else if(y<x&&y<z){
		cout<<y<<" ";
		     if(x<z){
     	cout<<x<<" "<<z;
    
	 }
	 if(z<x){
     	cout<<z<<" "<<x;
    
	 }
	}
	else if(z<x&&z<y){
		cout<<z<<" ";
    
	 if(y<x){
     	cout<<y<<" "<<x;
    
	 }
	 if(x<y){
     cout<<x<<" "<<y;
	 }
}
	}

