#include<iostream>
using namespace std;
int linearsearch(int,int&,int&);
int main(){
	int item=0,index1=0,index2=0;
	cout<<"Enter the item: ";
	cin>>item;
	linearsearch(item,index1,index2);
	cout<<"The address is: '"<<index1<<"' '"<<index2<<"'"<<endl;
	
}
int linearsearch(int item,int &index1,int &index2){
	int i,j;
	int array[3][5]={{1,3,5,7,9},{2,4,6,8,10},{1,2,3,5,7}};
	for(i=0;i<=2;i++){
		for(j=0;j<=4;j++){
			if(array[i][j]==item){
				index1=i;
				index2=j;
				break;
			}
		}
	}
}
