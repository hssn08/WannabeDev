#include<iostream>
using namespace std;
int fact(int);
int main(){
int x;
cout<<"Enter number: ";
cin>>x;
cout<<"The factorial is: "<<fact(x)<<endl;
return 0;
}
int fact(int z){
int a=1;
for(int f=1;f<=z;f++)
{
a=f*a;
}
return a;
}
