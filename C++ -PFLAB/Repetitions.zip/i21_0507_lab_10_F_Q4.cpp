#include<iostream>
using namespace std;
int main(){
	int x, i=1;
	cout<<"Enter a value: ";
	cin>>x;
	if(x<=2){
		cout<<"invalid";
	}
	else{
	cout<<"The table is:-"<<endl;
	while(i<=10){
		cout<<x<<" x "<<i<<" = "<<x*i<<endl;
		i++;
	}
}
return 0;
}
