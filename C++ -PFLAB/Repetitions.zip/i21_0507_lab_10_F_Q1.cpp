#include<iostream>
using namespace std;
int main(){
for (i=1;i<=5;i++)
cout<<"Hello world";
return 0;
}
