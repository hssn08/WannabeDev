#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
float choc,numb,sales,tax;
cout<<"Enter the price of mini chocolate bar: ";
cin>> choc;
cout<<"Enter the number of chocolates sold: ";
cin>> numb;
cout<<"The amount of sales revenue is: "<< choc*numb<<endl;
tax=0.10*(choc*numb);
cout<<"The total sales amount of chocolates after tax deduction is: "<< (choc*numb)-tax<<endl;
return 0;
}

