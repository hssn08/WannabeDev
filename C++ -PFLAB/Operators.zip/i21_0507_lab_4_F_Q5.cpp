#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
int a,b,c;
cout<<"Enter the value of a: ";
cin>> a;
cout<<"Enter the value of b: ";
cin>> b;
cout<<"Enter the value of c: ";
cin>> c;
cout<<"a^2+b^2+c^2+2(ab+bc+ca)= "<< a*a+b*b+c*c+2*(a*b+b*c+c*a)<<"\t";
return 0;
}
