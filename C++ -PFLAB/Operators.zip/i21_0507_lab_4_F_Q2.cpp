#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
int numOne=20, numTwo=10;
cout<<"Addition of numOne and numTwo is: "<< numOne+numTwo<<"\n";
cout<<"Subtraction of numOne and numTwo is: "<< numOne-numTwo<<"\n";
cout<<"Division of numOne and numTwo is: "<< numOne/numTwo<<"\n";
cout<<"Modulus of numOne and numTwo is: "<< numOne%numTwo<<"\n";
return 0;
}
