#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
float r,c,pi=3.14;
cout<<"Enter the radius: ";
cin>> r;
c=2*pi*r;
cout<<"The circumference of circle is: "<< c<<"\t";
return 0;
}


