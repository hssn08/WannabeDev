#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
int v,g;
cout<<"Enter input: ";
cin>> v;
cout<< v<<"\n";
v=g;
v*=2;
cout<< v<<"\n";
v+=10;
cout<< v<<"\n";
v/=2;
cout<< v<<"\n";
v-=g;
cout<<"The value of variable is: "<< v<<"\t";
return 0;
}

