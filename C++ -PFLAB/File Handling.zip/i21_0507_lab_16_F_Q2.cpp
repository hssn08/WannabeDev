#include<iostream>
#include<fstream>
#include<string>
using namespace std;
void displaycontent(ifstream &file){
	char ch;
	while(file.get(ch)){
		cout<<ch;
	}
}
	void countalp(ifstream &file){
		int count;
		char ch;
		while(file.get(ch)){
			 if((ch >= 97 && ch <= 122) || (ch >= 65 && ch <= 90)){
				count+=1;
			}
		}
			cout<<"\nThe number of alphabets is: "<<count;
		}
		void countword(ifstream &file){
		int count;
		char ch;
		while(file.get(ch)){
			if(ch == 32||ch=='\n'){
			count++;
			}
		}
		count+=1; //for ending of the text.
			cout<<"\nThe number of words is: "<<count;
		}

int main(){
	ifstream file;
	file.open("file1.txt");
	displaycontent(file);
	file.clear();
	file.seekg(0);
	countalp(file);
	file.clear();
	file.seekg(0);
	countword(file);
	file.clear();
	file.seekg(0);
	return 0;
}

