
#include <iostream>
#include <fstream>
using namespace std;

void decrypt(int key, char c);


int main() {
	int key;
	cout << "Key for Decryption: ";
	cin >> key;
	char d;
	decrypt(key, d);
}
void decrypt(int key, char d) {
	ifstream filen; 
	ofstream filee;

	filen.open("File2.txt");
	filee.open("File3.txt");

	while (filen.get(d)) {
		d=d-key;
		filee<<d;
	}

	filen.close();
	filee.close();
	cout << "Decrypted" << endl;
}
