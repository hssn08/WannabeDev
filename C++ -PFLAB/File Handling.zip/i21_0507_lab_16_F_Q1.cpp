#include<iostream>
#include<fstream>
using namespace std;
int main(){
	ofstream PF;
	PF.open("file1.txt");
	PF<<"Welcome to \"Programming Fundamentals\""<<endl;
	PF<<"It is our Lab_15";
	PF.close();
	return 0;
}

