
#include <iostream>
#include <fstream>
using namespace std;

void encrypt(int key, char c);


int main() {
	int key;
	cout << "Key for Encryption: ";
	cin >> key;
	char d;
	encrypt(key, d);
}

void encrypt(int key, char d) {
	ifstream filen; 
	ofstream filee;

	filen.open("File1.txt");
	filee.open("File2.txt");

	while (filen.get(d)) {
		d=d+key;
		filee<<d;
	}

	filen.close();
	filee.close();
	cout << "encrypted" << endl;
}
