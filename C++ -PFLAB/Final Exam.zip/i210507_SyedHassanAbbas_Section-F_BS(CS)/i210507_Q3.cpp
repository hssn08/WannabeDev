#include<iostream>
#include<time.h>
#include<cstdlib>
using namespace std;
int main(){
srand(time(NULL));
int array[4][7];
for(int i=0;i<5;i++){
for(int j=0;j<8;j++){
array[i][j]=(rand() % 2);
cout<<array[i][j];
cout<<"\t";
}
cout<<endl;
cout<<endl;
}
}


