#include<iostream>
using namespace std;
double power(double, int);
int main(){
int argumentmiss,argumentyes=0;
int p=2;
double n=0;
cout<<"Enter the value: ";
cin>>n;
argumentmiss=power(n,p);
cout<<"Enter the exponent: ";
cin>>p;
argumentyes=power(n,p);
cout<<"Result is= "<<argumentyes<<endl;
cout<<"Result without exponent: "<<argumentmiss<<endl;
}
double power(double n, int p){
int i;
double result=1;
for(i=0; i<p; i++){
result=result*n;
}
return result;
}
