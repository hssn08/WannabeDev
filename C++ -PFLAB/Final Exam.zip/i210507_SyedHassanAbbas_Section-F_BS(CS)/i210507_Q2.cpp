#include<iostream>
using namespace std;
int main(){


int x,x1,x2,x3;


cout<<"First Run:"<<endl;

cout<<"Enter year: ";

cin>>x;

(x%4==0) ? (x%100==0) ? (x%400==0)?  cout<<x<<" is a Leap year." : cout<<x<<" is not a Leap year." : cout<<x<<" is a Leap year." : cout<<x<<" is not a Leap year.";


cout<<endl;

cout<<endl;




cout<<"Second Run:"<<endl;

cout<<"Enter year: ";

cin>>x1;

(x1%4==0) ? (x1%100==0) ? (x1%400==0)?  cout<<x1<<" is a Leap year." : cout<<x1<<" is not a Leap year." : cout<<x1<<" is a Leap year." : cout<<x1<<" is not a Leap year.";

cout<<endl;

cout<<endl;




cout<<"Third Run:"<<endl;
cout<<"Enter year: ";

cin>>x2;

(x2%4==0) ? (x2%100==0) ? (x2%400==0)?  cout<<x2<<" is a Leap year." : cout<<x2<<" is not a Leap year." : cout<<x2<<" is a Leap year." : cout<<x2<<" is not a Leap year.";

cout<<endl;

cout<<endl;




cout<<"Fourth Run:"<<endl;

cout<<"Enter year: ";

cin>>x3;

(x3%4==0) ? (x3%100==0) ? (x3%400==0)?  cout<<x3<<" is a Leap year." : cout<<x3<<" is not a Leap year." : cout<<x3<<" is a Leap year." : cout<<x3<<" is not a Leap year.";

cout<<endl;

return 0;

}

