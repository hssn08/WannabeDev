#include<iostream>
using namespace std;
int main(){
int x=0,i=0,j=0,l=0,temp;
cout<<"Please enter size of an array: ";
cin>>x;
int* pointer= new int[x];
for(int i=0;i<x;i++){
cout<<"Array["<<i<<"]= ";
cin>>*(pointer+i);
}
for(int j=0;j<x;j++){
for(int l=j+1;l<x;l++){
if(*(pointer+j)>*(pointer+l)){
temp=*(pointer+j);
*(pointer+j)=*(pointer+l);
*(pointer+l)=*(pointer+j);
}
}
}

cout<<"Second Largest Element ="<<*(pointer+x-2)<<endl;
cout<<"Second Smallest Element ="<<*(pointer+1)<<endl;
}
