#include<iostream>
using namespace std;
int main(){
char x;
cout<<"Enter something: ";
cin>>x;
switch(x){
case 'A'...'z':
cout<<"It is an alphabet"<<endl;
break;
case '0'...'9':
cout<<"It is a digit"<<endl;
break;
default:cout<<"It is a special character";
}
return 0;
}
