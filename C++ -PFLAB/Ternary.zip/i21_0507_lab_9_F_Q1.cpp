#include<iostream>
using namespace std;
int main(){
int x,y,z;
cout<<"Enter first number: "<<endl;
cin>>x;
cout<<"Enter second number: "<<endl;
cin>>y;
cout<<"Enter third number: "<<endl;
cin>>z;
x>y&&x>z ? cout<<x<<" is greatest" : y>x&&y>z ? cout<<y<<" is greatest" : cout<<z<<" is greatest";
return 0;
}
