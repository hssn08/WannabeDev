#include<iostream>
using namespace std;
int main(){
int x;
cout<<"Enter input electricity unit"<<endl;
cin>>x;
int a=50;
int b=100;
int c=250;
if(x==0){
cout<<"error"<<endl;
}
else if(x<=50){
cout<<"Your bill is: "<<(x*7)+((x*7)*0.16)<<endl;
}
else if(x>50&&x<=100){
x-=a;
cout<<"Your bill is: "<<((x*10)+(a*7))+(((x*10)+(a*7))*0.16)<<endl;
}
else if(x>100&&x<=250){
x-=b;
cout<<"Your bill is: "<<((x*14)+(a*7)+((b-a)*10))+((x*14)+((a*7)+((b-a)*10))*0.16)<<endl;
}
else if(x>250){
x-=c;
cout<<"Your bill is: "<<((x*20)+(a*7)+((c-b)*10))+((x*20)+(a*7)+((c-b)*10)*0.16)<<endl;
}
return 0;
}





