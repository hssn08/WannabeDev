#include<iostream>
using namespace std;
int main(){
int x,y;
char z;
cout<<"Enter First number: "<<endl;
cin>>x;
cout<<"Enter second number: "<<endl;
cin>>y;
cout<<"Enter operator: "<<endl;
cin>>z;
switch(z){
case '+':
cout<<x+y<<endl;
break;
case '-':
cout<<x-y<<endl;
break;
case '/':
cout<<x/y<<endl;
break;
case '*':
cout<<x*y<<endl;
break;
default:cout<<"invalid operator"<<endl;
}
return 0;
}
