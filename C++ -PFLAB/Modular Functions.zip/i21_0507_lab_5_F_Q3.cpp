#include<iostream>
#include<iomanip>
using namespace std;
int timesTen(int);
int main(){
int x;
cout<<"enter a number";
cin>> x;
timesTen(x);
return 3;
}
int timesTen(int y){
int ten;
ten=y*10;
cout<<"Ten times the value is:"<< ten;
}


