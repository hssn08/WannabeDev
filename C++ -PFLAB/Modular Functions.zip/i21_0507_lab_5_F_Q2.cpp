#include<iostream>
#include<iomanip>
using namespace std;
double volume(double);
int main(){
double r;
cout<<"enter radius:";
cin>> r;
volume(r);
return 0;
}
double volume(double r){
double v;
v = (4/3)*3.1415*r*r*r;
cout<<"The volume is:"<< v;
return v;
}
