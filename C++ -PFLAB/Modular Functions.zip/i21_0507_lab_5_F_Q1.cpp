#include<iostream>
#include<iomanip>
using namespace std;
void limit();
int main(){
limit();
return 0;
}
void limit(){
cout<<"The upper limit of integer is: 2147483647"<<"\n";
cout<<"The lower limit of integer is: -2147483648"<<"\n";
}
