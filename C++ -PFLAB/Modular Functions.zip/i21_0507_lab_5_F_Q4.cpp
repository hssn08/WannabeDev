#include<iostream>
#include<iomanip>
using namespace std;
int thirdangle(int angle1,int angle2);
int main(){
int angle1;
int angle2;
cout<<"enter 1st angle"<<endl;
cin>> angle1;
cout<<"enter 2nd angle"<<endl;
cin>> angle2;
cout<<"third angle is:"<< thirdangle(angle1,angle2)<<"\n";
return 0;
}
int thirdangle(int angle1,int angle2){
int angle3;
int add;
add=angle1=angle2;
angle3=180-add;
return angle3;
}

