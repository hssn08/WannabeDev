#include<iostream>
using namespace std;
int main(){
	int array[10];
	int x;
	for(x=0;x<=9;x++){
		cout<<"Enter number: ";
		cin>>array[x];
}
for(x=0;x<=9;x++){
			if (array[x]%2==0){
		cout<<"even number #"<<x<<" is: "<<array[x]<<endl;
}
}
return 0;
}
