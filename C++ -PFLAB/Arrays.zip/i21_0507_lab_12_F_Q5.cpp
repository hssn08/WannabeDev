#include<iostream>
using namespace std;
int main(){
	int y,sum;
	int firstarray[3];
	int secondarray[3];
	for(int x=0;x<3;x++){
		cout<<"Enter array 1 value"<<x+1<<": ";
		cin>>firstarray[x];
	}
		for(int x=0;x<3;x++){
		cout<<"Enter array 2 value"<<x+1<<": ";
		cin>>secondarray[x];
	}
		for(int x=0;x<3;x++){
        y=(firstarray[x]*secondarray[x]);
        sum+=y;
}
cout<<"Scalar product is: "<<sum<<endl;
return 0;
}
