#include<iostream>
using namespace std;
int main(){
	int my_array[21]={13, 99, 6, 76, 11, 83, 8, 67, 66, 22, 96, 46, 21, 65, 48, 22, 28, 11, 83,
87,10};
int x;
for(x=20;x>=0;x--){
	cout<<my_array[x]<<"  ";
}
}
