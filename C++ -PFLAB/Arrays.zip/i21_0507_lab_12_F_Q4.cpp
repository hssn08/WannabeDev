#include<iostream>
using namespace std;
int main(){
	int array[8] = {5, 6, 2, 12, 45, 15, 20, 3};
	cout<<"Enter number: ";
	int y,z;
	cin>>y;
	for(int x=0;x<=8;x++){
		if(y==array[x]){
			cout<<"number found in array"<<endl;
			z=1;
		}
	}
	if(z==0){
		cout<<"number not found in array"<<endl;
	}
	return 0;
}
