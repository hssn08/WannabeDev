#include<iostream>
using namespace std;
int main(){
	int array[5],sum,max,min,avg;
	for(int x=0;x<5;x++){
		cout<<"enter value: ";
		cin>>array[x];
		max=array[0];
		min=array[0];
	}
		for(int x=0;x<5;x++){
		sum+=array[x];
		if(max<array[x])
		max=array[x];
		if(min>array[x])
		min=array[x];
	}
	avg=sum/5;
	cout<<"minimum is: "<<min<<endl;
	cout<<"maximum is: "<<max<<endl;
	cout<<"sum is: "<<sum<<endl;
	cout<<"average is: "<<avg<<endl;
	return 0;
	}
