#include<iostream>
using namespace std;
void calculate_biscuits(int);
int quantity_of_sugar(int,int,int);
int quantity_of_butter(int,int,int);
int quantity_of_flour(int,int,int);
int main(){
int a;
cout<<"enter number of biscuits: "<<endl;
cin>> a;
calculate_biscuits(a);
return 0;
}
void calculate_biscuits(int a){
int f,a1,a2,g,h,a3;
cout<<"quantity of sugar is: "<< quantity_of_sugar(a,f,a1)<<" grams"<<endl;
cout<<"quantity of butter is: "<<quantity_of_butter(a,g,a2)<<" grams"<<endl;
cout<<"quantity of flour is: "<< quantity_of_flour(a,h,a3)<<" grams"<<endl;
}
int quantity_of_sugar(int a,int f,int a1){
f=5;
a1=5*a;
return a1;
}
int quantity_of_butter(int a,int g, int a2){
g=10;
a2=10*a;
return a2;
}
int quantity_of_flour(int a,int h,int a3){
h=20;
a3=20*a;
return a3;
}




