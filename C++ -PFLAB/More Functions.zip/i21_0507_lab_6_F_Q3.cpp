#include<iostream>
using namespace std;
float area_of_square(float);
float area_of_circle(float);
int main(){
float a=2,b=4;
area_of_circle(a);
area_of_circle(b);
cout<<"the area of shaded is: "<< area_of_square(b)-area_of_circle(a)<<endl;
return 0;
}
float area_of_circle(float r){
float areacircle;
areacircle=3.14*r*r;
return areacircle;
}
float area_of_square(float s){
float areasquare;
areasquare=s*s;
return areasquare;
}


