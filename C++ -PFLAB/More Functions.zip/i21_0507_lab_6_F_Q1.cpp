#include<iostream>
#include<cmath>
using namespace std;
int power(int,int);
int main(){
int a=3;
int b=4;
power(a,b);
cout<< power(a,b)<<endl;
return 0;
}
int power(int x,int y){
int z;
z=pow(x,y);
return z;
}
