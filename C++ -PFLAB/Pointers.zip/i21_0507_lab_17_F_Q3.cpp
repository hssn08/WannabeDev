#include<iostream>
using namespace std;
int main(){
char array[100];
char *pointer;
int vowel=0;
int nonvowel=0;
pointer=array;
cout<<"Enter a message: ";
cin.getline (pointer, 100);
for(int i=0;*(pointer+i)!='\0';i++){
if(*(pointer+i)=='a'||*(pointer+i)=='e'||*(pointer+i)=='i'||*(pointer+i)=='o'||*(pointer+i)=='u'||*(pointer+i)=='A'||*(pointer+i)=='E'||*(pointer+i)=='I'||*(pointer+i)=='O'||*(pointer+i)=='U'){
vowel+=1;
}
else if(*(pointer+i) != ' '){
nonvowel+=1;
}
}
cout<<"The number of vowels is: "<<vowel<<endl;
cout<<"The number of consonants is: "<<nonvowel<<endl;
}


