#include<iostream>
using namespace std;
int main(){
int x=0,positive=0,neg=0,even=0,odd=0;
cout<<"Enter size of array: ";
cin>>x;
int *pointer=new int[x];
for(int i=0;i<x;i++){
cout<<"Array ["<<i+1<<"] = ";
cin>>*(pointer+i);
}
for(int i=0;i<x;i++){
if(*(pointer+i)%2==0){
even+=1;
}
else{
odd+=1;
}
}
for(int i=0;i<x;i++){
if(*(pointer+i)>0){
positive+=1;
}
else if(*(pointer+i)<0){
neg+=1;
}
}
cout<<"The number of even integers is: "<<even<<endl;
cout<<"The number of odd integers is: "<<odd<<endl;
cout<<"The number of positive integers is: "<<positive<<endl;
cout<<"The number of negative integers is: "<<neg<<endl;
}
