#include<iostream>
using namespace std;
bool even_odd(int);
int main(){
int x;
cout<< "enter a number :"<<"\t";
cin>>x;
even_odd(x);
if(even_odd(x)==0){
cout<<"the number is odd.\n";
}
else if(even_odd(x)==1)
{
cout<<"the number is even\n";
}
return 0;
}
bool even_odd(int z){
bool b=true;
bool c=false;
if (z%2==0){
return b;
}
else
{
return c;
}
}
