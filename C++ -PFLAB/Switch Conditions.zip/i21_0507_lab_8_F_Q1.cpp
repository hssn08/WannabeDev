#include<iostream>
using namespace std;
int swap(int &,int &);
int main(){
int a=10;
int b=20;
cout<< "before swap a: "<<a<<", b: "<<b<<endl;
swap(a,b);
cout<< "after swap a: "<<a<<", b: "<<b<<endl;
return 0;
}
int swap(int &x,int &y){
int z;
z=x;
x=y;
y=z;
return 0;
}

