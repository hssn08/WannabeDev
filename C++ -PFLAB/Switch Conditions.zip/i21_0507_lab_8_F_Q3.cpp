#include<iostream>
using namespace std;
int Cal(int,int,char);
int main(){
int x,y;
char z;
cout<<"enter integer 1: ";
cin>>x;
cout<<"\nenter integer 2: ";
cin>>y;
cout<<"\nenter operator(+-/*): ";
cin>>z;
Cal(x,y,z);
return 0;
}
int Cal(int a,int b,char c){
if(c=='*'){
cout<<a*b<<"\t";
}
else if(c=='+'){
cout<<a+b<<"\t";
}
else if(c=='-'){
cout<<a-b<<"\t";
}
else if(c=='/'){
cout<<a/b<<"\t";
}
else{
cout<<"Enter a valid operator";
}
return 0;
}





