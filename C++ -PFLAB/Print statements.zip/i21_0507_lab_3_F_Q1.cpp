#include<iostream>
using namespace std;
int main()
{
string name,roll;
float gpa;
cout<<"Enter Your name:";
cin>> name;
cout<<"Enter Your roll number:";
cin>> roll;
cout<<"Enter Your CGPA:";
cin>> gpa;
cout<<"\nYour name is: " <<name;
cout<<"\nYour roll number is: " <<roll;
cout<<"\nYour CGPA is: " <<gpa;
return 0;
}

