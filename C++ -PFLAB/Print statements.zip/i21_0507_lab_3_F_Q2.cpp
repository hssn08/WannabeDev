#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
cout<<"---------------a---------------\n";
cout<<setw(12)<<"*\n"<<setw(10)<<"*"<<setw(3)<<"*\n"<<setw(9)<<"*"<<setw(5)<<"*\n"<<setw(8)<<"*"<<setw(7)<<"*\n"<<setw(7)<<"*"<<setw(9)<<"*\n"<<setw(6)<<"*"<<setw(11)<<"*\n"<<setw(7)<<"*"<<setw(9)<<"*\n"<<setw(8)<<"*"<<setw(7)<<"*\n"<<setw(9)<<"*"<<setw(5)<<"*\n"<<setw(10)<<"*"<<setw(3)<<"*\n"<<setw(12)<<"*\n";
cout<<"---------------b---------------\n";
cout<<"*******\n******\n*****\n****\n***\n**\n*\n";
cout<<"---------------c---------------\n";
cout<<"*******\n ******\n  *****\n   ****\n    ***\n     **\n      *\n";
cout<<"---------------d---------------\n";
cout<<setw(10)<<"******\n"<<setw(3)<<"*"<<setw(8)<<"*\n"<<setw(2)<<"*"<<setw(10)<<"*\n"<<setw(1)<<"*"<<setw(12)<<"*\n"<<setw(2)<<"*"<<setw(10)<<"*\n"<<setw(3)<<"*"<<setw(8)<<"*\n"<<setw(10)<<"******\n";
return 0;
}
