#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
cout<<setw(11)<<"*****"<<setw(27)<<"*****\n"<<setw(5)<<"*"<<setw(8)<<"*"<<setw(18)<<"*"<<setw(9)<<"*\n"<<setw(4)<<"*"<<setw(10)<<"*"<<setw(16)<<"*"<<setw(11)<<"*\n"<<setw(3)<<"*"<<setw(12)<<"*"<<setw(14)<<"*"<<setw(13)<<"*\n"<<setw(2)<<"*"<<setw(14)<<"*"<<setw(12)<<"*"<<setw(15)<<"*\n"<<setw(1)<<"*"<<setw(16)<<"*"<<setw(10)<<"*"<<setw(16)<<"*\n"<<setw(1)<<"*"<<setw(16)<<"*"<<setw(10)<<"*"<<setw(16)<<"*";
return 0;
}
