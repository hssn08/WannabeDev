#include<iostream>
using namespace std;
int main(){
	int matrix[5][5];
	for(int x=0;x<5;x++){
	for(int y=0;y<5;y++){
		cin>>matrix[x][y];
	}
}
for(int i=0;i<5;i++){
	
	for(int j=0;j<5;j++){
	cout<<matrix[i][j]<<" ";
}
cout<<endl;
}
}
