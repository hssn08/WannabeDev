#include<iostream>
using namespace std;
int main(){
	int z;
		int o[3][3];
		for(int x=0;x<3;x++){
		for(int y=0;y<3;y++){
		cin>>o[x][y];
		if(x>y){
			z+=o[x][y];
		}
}
}
		cout<<"sum of lower triangular matrix: "<<z;
}

