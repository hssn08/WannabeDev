#include<iostream>
using namespace std;
int countvowels(char[]);
int main(){
char x[100];
cout<<"Enter string: ";
cin>>x;
cout<<"The number of vowels is: "<<countvowels(x)-1<<endl;
return 0;
}
int countvowels(char array[100]){
		int vowel=0;
for(int i=0;i<=100;i++){
	if(array[i]=='a'|| array[i]=='A'){
		vowel+=1;
	}
	else if(array[i]=='e'|| array[i]=='E'){
		vowel+=1;
	}
	else if(array[i]=='i'|| array[i]=='I'){
		vowel+=1;
	}
	else if(array[i]=='o'|| array[i]=='O'){
		vowel+=1;
	}
	else if(array[i]=='u'|| array[i]=='U'){
		vowel+=1;
	}
}
	return vowel;
}
