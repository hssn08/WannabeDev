#include<iostream>
using namespace std;
int countvowels(char[]);
int main(){
char x[100];
cout<<"Enter string: ";
cin>>x;
countvowels(x);
return 0;
}
int countvowels(char array[100]){
	int j=-1;
char lower[27]={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
for(int i=0;i<26;i++){
	for(int k=0;k<100;k++){
		if(array[k]==lower[i]){
        j++;
		}
	}
	if(j>0){
		cout<<lower[i]<<" is used "<<j<<endl;
		j=0;
	}
}
return 0;
}
