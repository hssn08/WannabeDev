#include<iostream>
using namespace std;
int main(){
	int z1=0,z2=0,z3=0,z4=0,z5=0;
	int matrix[5][5];
	for(int x=0;x<5;x++){
	for(int y=0;y<5;y++){
		cin>>matrix[x][y];
	}
	
}
for(int i=0;i<5;i++){
	
	for(int j=0;j<5;j++){
if(i==0){
	z1+=matrix[0][j];
}
else if(i==1){
	z2+=matrix[1][j];
}
else if(i==2){
	z3+=matrix[2][j];
}
else if(i==3){
	z4+=matrix[3][j];
}
else if(i==4){
	z5+=matrix[4][j];
}
}
}
int sumarray[5]={z1,z2,z3,z4,z5};
cout<<"sum array= ";
for(int k=0;k<5;k++){
	cout<<sumarray[k]<<" ";
}
}
