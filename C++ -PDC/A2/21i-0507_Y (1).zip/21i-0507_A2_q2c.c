#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

void custom_alltoall(void *sendbuffer, int sendcount, MPI_Datatype sendtype,
                     void *recvbuffer, int recvcount, MPI_Datatype recvtype,
                     MPI_Comm comm) {
    int rank, size;
    MPI_Comm_rank(comm, &rank);
    MPI_Comm_size(comm, &size);

    MPI_Request requests[size * 2];
    MPI_Status statuses[size * 2];

    int i = 0;
    while (i < size) {
        if (i != rank) {
            MPI_Isend(sendbuffer + i * sendcount, sendcount, sendtype, i, 0, comm, &requests[i]);
        }
        MPI_Irecv(recvbuffer + i * recvcount, recvcount, recvtype, i, 0, comm, &requests[i + size]);
        i++;
    }

    MPI_Waitall(size * 2, requests, statuses);
}

int main(int argc, char *argv[]) {
    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int sendbuffer[size];
    int recvbuffer[size];

    int i = 0;
    while (i < size) {
        sendbuffer[i] = rank * size + i;
        i++;
    }

    custom_alltoall(sendbuffer, 1, MPI_INT, recvbuffer, 1, MPI_INT, MPI_COMM_WORLD);

    printf("Process %d received: ", rank);
    int j = 0;
    while (j < size) {
        printf("%d ", recvbuffer[j]);
        j++;
    }
    printf("\n");

    MPI_Finalize();
    return 0;
}
