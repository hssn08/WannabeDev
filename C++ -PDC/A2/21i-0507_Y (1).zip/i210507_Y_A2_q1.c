#include <stdio.h>

#define INF 9999999
#define NUM_CITIES 8

int tsp(int city, int n, int graph[][n], int visited[], int count, int cost, int min_cost, int path[]) {
    if (count == n && graph[city][0]) {
        if (min_cost > cost + graph[city][0]) {
            min_cost = cost + graph[city][0];
            for (int i = 0; i < n; ++i) {
                path[i] = visited[i] - 1;
            }
        }
        return min_cost;
    }
    for (int i = 0; i < n; ++i) {
        if (visited[i] == 0 && graph[city][i]) {
            visited[i] = count + 1;
            min_cost = tsp(i, n, graph, visited, count + 1, cost + graph[city][i], min_cost, path);
            visited[i] = 0;
        }
    }
    return min_cost;
}

int main() {
    int graph[NUM_CITIES][NUM_CITIES];
    int example_graph[8][8] = {
            {-1000, 25, 92, 78, 117, 34, 51, 68}, 
            {25, -1000, 13, 81, 40, 125, 72, 95}, 
            {92, 13, -1000, 18, 63, 108, 27, 46},  
            {78, 81, 18, -1000, 52, 141, 89, 112},  
            {117, 40, 63, 52, -1000, 78, 31, 105},  
            {34, 125, 108, 141, 78, -1000, 90, 123}, 
            {51, 72, 27, 89, 31, 90, -1000, 54},  
            {68, 95, 46, 112, 105, 123, 54, -1000}
    };
    for (int i = 0; i < NUM_CITIES; ++i) {
        for (int j = 0; j < NUM_CITIES; ++j) {
            graph[i][j] = example_graph[i][j];
        }
    }

    int visited[NUM_CITIES];
    for (int i = 0; i < NUM_CITIES; ++i) {
        visited[i] = 0;
    }
    visited[0] = 1;

    int min_cost = INF;
    int path[NUM_CITIES];

    min_cost = tsp(0, NUM_CITIES, graph, visited, 1, 0, min_cost, path);

    printf("Minimum cost: %d\n", min_cost);
    printf("Path: ");
    for (int i = 0; i < NUM_CITIES; ++i) {
        printf("%d->", path[i]);    
    }
    printf("0\n");

    return 0;
}
