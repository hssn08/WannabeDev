#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char *argv[]) {
    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int send_counts[size];
    int displs[size];
    int recv_counts[size];

    int i = 0;
    while (i < size) {
        send_counts[i] = i + 1;
        recv_counts[i] = size;
        i++;
    }

    displs[0] = 0;
    i = 1;
    while (i < size) {
        displs[i] = displs[i - 1] + send_counts[i - 1];
        i++;
    }

    int local_data[send_counts[rank]];
    i = 0;
    while (i < send_counts[rank]) {
        local_data[i] = rank + 1;
        i++;
    }

    int gathered_data[size * size];

    i = 0;
    while (i < size) {
        if (i != rank) {
            MPI_Send(local_data, send_counts[rank], MPI_INT, i, 0, MPI_COMM_WORLD);
        }

        if (i != rank) {
            MPI_Recv(&gathered_data[displs[i]], recv_counts[i], MPI_INT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        } else {
            int k = 0;
            while (k < send_counts[rank]) {
                gathered_data[displs[rank] + k] = local_data[k];
                k++;
            }
        }
        i++;
    }

    printf("Process %d gathered data: ", rank);
    int j = 0;
    while (j < size * size) {
        if (gathered_data[j] != 0) {
            printf("%d ", gathered_data[j]);
        }
        j++;
    }
    printf("\n");

    MPI_Finalize();
    return 0;
}
