#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

void custom_alltoallv(void *sendbuf, int *sendcounts, int *sdispls, MPI_Datatype sendtype,
                      void *recvbuf, int *recvcounts, int *rdispls, MPI_Datatype recvtype,
                      MPI_Comm comm) {
    int rank, size;
    MPI_Comm_rank(comm, &rank);
    MPI_Comm_size(comm, &size);

    MPI_Request requests[size * 2];
    MPI_Status statuses[size * 2];


    for (int i = 0; i < size; i++) {
        if (i != rank) {
            MPI_Isend(sendbuf + sdispls[i], sendcounts[i], sendtype, i, 0, comm, &requests[i]);
        }
        MPI_Irecv(recvbuf + rdispls[i], recvcounts[i], recvtype, i, 0, comm, &requests[i + size]);
    }

 
    MPI_Waitall(size * 2, requests, statuses);
}

int main(int argc, char *argv[]) {
    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int sendbuf[5] = {1, 2, 3, 4, 5}; 
    int recvbuf[size * 5]; 


    int sendcounts[size] = {1, 2, 3, 4, 5};
    int sdispls[size];
    sdispls[0] = 0;
    for (int i = 1; i < size; i++) {
        sdispls[i] = sdispls[i - 1] + sendcounts[i - 1];
    }

  
    int recvcounts[size];
    for (int i = 0; i < size; i++) {
        recvcounts[i] = sendcounts[(rank + i) % size];
    }
    int rdispls[size];
    rdispls[0] = 0;
    for (int i = 1; i < size; i++) {
        rdispls[i] = rdispls[i - 1] + recvcounts[i - 1];
    }

    custom_alltoallv(sendbuf, sendcounts, sdispls, MPI_INT, recvbuf, recvcounts, rdispls, MPI_INT, MPI_COMM_WORLD);

    printf("Process %d received: ", rank);
    for (int i = 0; i < size * 5; i++) {
        printf("%d ", recvbuf[i]);
    }
    printf("\n");

    MPI_Finalize();
    return 0;
}
