allgather:#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char *argv[]) {
    int rank, size;
    int *recvbuf, *sendbuf;
    MPI_Status status;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    recvbuf = (int*)malloc(sizeof(int) * size);
    sendbuf = (int*)malloc(sizeof(int));
    
    *sendbuf = rank;

    for (int i = 0; i < size; i++) {
        if (i != rank) {
            MPI_Send(sendbuf, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
        }
    }

    for (int i = 0; i < size; i++) {
        if (i != rank) {
            MPI_Recv(&recvbuf[i], 1, MPI_INT, i, 0, MPI_COMM_WORLD, &status);
        } else {
            recvbuf[i] = *sendbuf;
        }
    }

    printf("Process %d received: ", rank);
    for (int i = 0; i < size; i++) {
        printf("%d ", recvbuf[i]);
    }
    printf("\n");

    free(recvbuf);
    free(sendbuf);

    MPI_Finalize();
    return 0;
}