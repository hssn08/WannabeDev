#include <iostream>
#include <fstream>
#include <pthread.h>
#include <sched.h> 
#include <vector>
#include <chrono>
using namespace std;

const int MAX_THREADS = 2; // i3-115G4 has 2 cores 4 virtual cores.

struct Node {
    int val;
    Node* next;

    Node(int value) : val(value), next(nullptr) {}
};

class linkedlist {
public:
    Node* head;

    linkedlist() : head(nullptr) {}

    ~linkedlist() {
        Node* current = head;
        while (current) {
            Node* nextNode = current->next;
            delete current;
            current = nextNode;
        }
    }

    void add(int value) {
        Node* newNode = new Node(value);
        if (!head) {
            head = newNode;
        } else {
            Node* current = head;
            while (current->next) {
                current = current->next;
            }
            current->next = newNode;
        }
    }
   void readRollNumbersFromFile(const char* filename) {
        ifstream inputFile(filename);
        int number;

        while (inputFile >> number) {
            add(number);
        }

        inputFile.close();
    }

    void displayList() {
        cout << "Linked list: ";
        Node* current = head;
        while (current) {
            cout << current->val << " ";
            current = current->next;
        }
        cout << endl;
    }

    Node* merge(Node* left, Node* right) {
        if (!left) return right;
        if (!right) return left;

        Node* result = nullptr;

        if (left->val <= right->val) {
            result = left;
            result->next = merge(left->next, right);
        } else {
            result = right;
            result->next = merge(left, right->next);
        }

        return result;
    }

    Node* mergeSort(Node* head) {
        if (!head || !head->next) {
            return head;
        }

        Node* middle = getMiddle(head);
        Node* nextToMiddle = middle->next;
        middle->next = nullptr;

        Node* left = mergeSort(head);
        Node* right = mergeSort(nextToMiddle);

        return merge(left, right);
    }

    Node* getMiddle(Node* head) {
        if (!head) return head;

        Node* slow = head;
        Node* fast = head->next;

        while (fast && fast->next) {
            slow = slow->next;
            fast = fast->next->next;
        }

        return slow;
    }

    void sort() {
        head = mergeSort(head);
    }

    void addRollNumbersToList(const vector<int>& numbers) {
        for (int number : numbers) {
            add(number);
        }
    }
};

struct ThreadArgs {
    linkedlist* list;
    vector<int> numbers;
    int threadId;
};

void* addRollNumbersToListParallel(void* arg) {
    ThreadArgs* args = (ThreadArgs*)arg;
    linkedlist* list = args->list;
    vector<int> numbers = args->numbers;

    list->addRollNumbersToList(numbers);

    return nullptr;
}

void* mergeSortParallel(void* arg) {
    ThreadArgs* args = (ThreadArgs*)arg;
    linkedlist* list = args->list;

 
    if (list->head == nullptr || list->head->next == nullptr) {
        return nullptr;
    }

  
    linkedlist leftHalf;
    linkedlist rightHalf;
    Node* middle = list->getMiddle(list->head);
    rightHalf.head = middle->next;
    middle->next = nullptr;
    leftHalf.head = list->head;

    //Calculate the number of elements in each half
    int numLeft = 0;
    int numRight = 0;
    Node* current = leftHalf.head;
    while (current) {
        numLeft++;
        current = current->next;
    }
    current = rightHalf.head;
    while (current) {
        numRight++;
        current = current->next;
    }

   
    ThreadArgs leftArgs = {&leftHalf, {}, args->threadId};
    ThreadArgs rightArgs = {&rightHalf, {}, args->threadId};


    pthread_t leftThread;
    pthread_t rightThread;
    pthread_create(&leftThread, nullptr, mergeSortParallel, &leftArgs);
    pthread_create(&rightThread, nullptr, mergeSortParallel, &rightArgs);

  
    pthread_join(leftThread, nullptr);
    pthread_join(rightThread, nullptr);

 
    list->head = list->merge(leftHalf.head, rightHalf.head);

   
    leftHalf.head = nullptr;
    rightHalf.head = nullptr;

    return nullptr;
}

void setAffinity(pthread_t thread, int coreId) {
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(coreId, &cpuset);
    pthread_setaffinity_np(thread, sizeof(cpu_set_t), &cpuset);
}
double speedupActual(double T1, double Tn, int n) {
    return T1 / Tn * n;
}


double speedupAmdahl(double T1, double Tn, int n, double fp) {
    double fs = 1 - fp;
    return 1 / ((fp / n) + fs);
}

int main() {
 auto start = chrono::high_resolution_clock::now();
linkedlist two;
cout<<"\n----------------------SERIAL-------------------------\n";
cout<<endl;
    const char* filename = "numbers.txt";
    two.readRollNumbersFromFile(filename);


    cout << "Unsorted ";
    two.displayList();

    cout << "\nSorted ";
    two.sort();
    two.displayList();

auto end = chrono::high_resolution_clock::now();
    chrono::duration<double> duration = end - start;
    
cout<<"\n----------------------PARRALLELL-------------------------\n";











 auto start1 = chrono::high_resolution_clock::now();




    linkedlist one;
        ifstream inputFile("numbers.txt");
        int number;
        vector<int> allNumbers;
        while (inputFile >> number) {
            allNumbers.push_back(number);
        }
        inputFile.close();

        vector<int> numbersToAdd[MAX_THREADS];
        const int NUMBERS_PER_THREAD = allNumbers.size() / MAX_THREADS;
        for (int i = 0; i < MAX_THREADS; ++i) {
            int startIndex = i * NUMBERS_PER_THREAD;
            int endIndex = (i == MAX_THREADS - 1) ? allNumbers.size() : (i + 1) * NUMBERS_PER_THREAD;
            for (int j = startIndex; j < endIndex; ++j) {
                numbersToAdd[i].push_back(allNumbers[j]);
            }
        }

        pthread_t addThreads[MAX_THREADS];
        ThreadArgs addArgs[MAX_THREADS];

        for (int i = 0; i < MAX_THREADS; ++i) {
            addArgs[i].list = &one;
            addArgs[i].numbers = numbersToAdd[i];
            pthread_create(&addThreads[i], nullptr, addRollNumbersToListParallel, &addArgs[i]);
         //  setAffinity(addThreads[i], i % 2); // Alternate cores 0 and 1
        }
 cout<<endl;
        for (int i = 0; i < MAX_THREADS; ++i) {
            pthread_join(addThreads[i], nullptr);
            cout << "Thread " << i << " finished adding." << endl;

        }

    cout << "\nUnsorted ";
    one.displayList();
    cout<<endl;

    pthread_t sortThreads[MAX_THREADS];
    ThreadArgs sortArgs[MAX_THREADS];
    for (int i = 0; i <=0; ++i) {
        sortArgs[i] = {&one, {}, i};
        pthread_create(&sortThreads[i], nullptr, mergeSortParallel, &sortArgs[i]);
       //setAffinity(sortThreads[i], i % 2); // Alternate threads between cores 0 and 1
    }
    pthread_join(sortThreads[0], nullptr);
    for (int i = 0; i <MAX_THREADS; ++i) {
        cout << "Thread " << i << " finished sorting." << endl;
    }

    cout << "\nSorted ";
    one.displayList();
    cout<<endl;

    auto end1 = chrono::high_resolution_clock::now();
    chrono::duration<double> duration1 = end1 - start1;


    cout << "Execution time Serial: " << duration.count() << " seconds" << endl;
    cout << "Execution time Parrallel: " << duration1.count() << " seconds" << endl;



     double T1 = duration.count() ; 
    double Tn = duration1.count(); 
    int n = 2; 
    double fp = 0.5; 

    cout << "Speedup (Actual): " << speedupActual(T1, Tn, n) << endl;

   
    cout << "Speedup (Amdahl's Law): " << speedupAmdahl(T1, Tn, n, fp) << endl;
    return 0;
}
