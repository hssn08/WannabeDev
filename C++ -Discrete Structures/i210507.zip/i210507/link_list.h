#include<iostream>

using namespace std;

class Node
{
public:
	Node* next;
	int data;

	Node()
	{
		data = 0;
		next = NULL;
	}

	Node(int d, Node* n)
	{
		n->data = d;
		next = n;
	}

	Node(int d)
	{
		data = d;
		next = NULL;
	}


};

class LinkedList {

public:

	Node* head;
	Node* en;

	LinkedList()
	{
		head = NULL;
		en = NULL;
	}

	int begin()
	{
		return head->data;
	}
	int end()
	{
		if (!empty())
		{
			Node* nn = head;

			while (nn->next != NULL)
			{
				nn = nn->next;
			}
			return nn->data;
		}
		return 0;
	}

	bool empty()
	{
		if (head == NULL)
		{
			return true;
		}
		return false;
	}

	void insert(int a)
	{
		Node* n = new Node(a);
		n->next = NULL;

		if (head == NULL)
		{
			head = n;
			en = n;
		}
		else
		{

			Node* nn = head;

			while (nn != NULL)
			{
				nn = nn->next;
			}

			nn = n;
			en = n;
			
		}
	}



};