#pragma once
#include<iostream>
#include"../Project7/stack.h"
#include"../Project7/link_list.h"
#include <list>
#include<string>
using namespace std;


class connectedcomponent
{

    int V;
    list<int> project[5200000];

public:
// List to store data iteratively

    LinkedList i;

// Constructors

    connectedcomponent()
    {
        V = 0;
    }

    connectedcomponent(int v)
    {
        V = v;
    }

// to make connections b/w nodes(edges)

    void addEdge(long long int v,long long int w)
    {
        project[v].push_back(w);
    }

//

    connectedcomponent getTranspose(long long int counter)
    {
        connectedcomponent g(V);
        long long int v = 0;

        while (v < counter)
        {
             list<int>::iterator i;
             i = project[v].begin();

            while (i != project[v].end())
            {
                g.project[*i].push_back(v);
                i++;
            }
            v++;
        }
        return g;
    }

//To Calculate The Connected Components of the graph

    void highestSCC(long long int counter, int numberofNodes[], int& largest)
    {
        long long int i = 0;

        while (i < counter)
        {
            if (numberofNodes[i] > largest)
            {
                largest = numberofNodes[i];
            }
            i++;
        }

    }

    void Display(int largest)
    {
        cout << "=======================================================================\n";
        cout << "\t\t\t\t=======\n";
        cout << "\t\t\t\tMEMBERS\n";
        cout << "\t\t\t\t=======\n";
        cout << "--> Hamza Tariq (i21-0707)\n";
        cout << "--> Bilal Ur Rehman (i21-0472)\n";
        cout << "--> Talha Zahoor (i21-0867)\n";
        cout << "\t\t\t===================\n";
        cout << "\t\t\tLargest SCC : " << largest << endl;
        cout << "\t\t\t===================\n";
        cout << "=======================================================================\n";
    }

    void calculateConected(long long int counter)
    {
        long long int i = 0;
        int numberofNodes[5200000];
        stack Stack;

        bool visited[5200000];

        while (i < counter)
        {
            visited[i] = false;
            numberofNodes[i] = 0;
            i++;
        }
        i = 0;

        while (i < counter)
        {
            if (visited[i] == false)
            {
                fillOrder(i, visited, Stack);
            }
            i++;
        }

        connectedcomponent gr = getTranspose(counter);
        i = 0;

        while (i < counter)
        {
            visited[i] = false;
            i++;
        }

        while (Stack.Empty() == false)
        {
            int v = Stack.Top();
            Stack.pop();
            if (visited[v] == false)
            {
                gr.connected(v, visited, numberofNodes, v);
            }
        }

        int largest = 0;
        

        highestSCC(counter, numberofNodes, largest);

        Display(largest);

        return;
    }

    

// To Fill the the Edges B/W the Nodes

    void fillOrder(int v, bool visited[], stack& Stack)
    {
        visited[v] = true;
        list<int>::iterator i;

        i = project[v].begin();

        while (i != project[v].end())
        {
            if (!visited[*i])
            {
                fillOrder(*i, visited, Stack);
            }
            i++;
        }
        Stack.push(v);
    }

//To Check the Connections of the Nodes

    void connected(int v, bool visited[], int n[], int x)
    {
        visited[v] = true;

        list<int>::iterator i;
        i = project[v].begin();

        while (i != project[v].end())
        {
            if (!visited[*i])
            {
                connected(*i, visited, n, x);
            }
            ++i;
        }

        n[x]++;
    }
};