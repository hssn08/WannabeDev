#pragma once
#include<iostream>
using namespace std;

class node
{
public:
    int data;
    node* next;

    node(int d)
    {
        data = d;
        next = NULL;
    }
};


class stack
{
public:
    node* top;

    stack()
    {
        top = NULL;

    }

    void push(int DataItem)
    {
        node* n = new node(DataItem);
        if (Empty())
        {
            top = n;
        }
        else
        {
            n->next = top;
            top = n;
        }
    }

    void pop()
    {

        if (Empty())
        {
            return;
        }
        else
        {
            node* n = new node(0);
            n = top;
            top = n->next;
        }
    }

    int Top()
    {
        return top->data;
    }

    bool Empty()
    {
        if (top == NULL)
        {
            return true;
        }
        return false;
    }

    ~stack()
    {
        while (top != NULL)
        {
            node* n = new node(0);
            n->next = top;
            delete top;
            top = n;
        }
    }
};