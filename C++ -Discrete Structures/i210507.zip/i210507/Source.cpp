#include<iostream>
#include<fstream>
#include<string>
#include"../Project7/Header.h"
using namespace std;

int main()
{
    fstream f;
    connectedcomponent g(8757130);
    string z;

    long long int val1 = 0, val2 = 0;
    long long int edges = 0;

    f.open("Google.txt");

    while (getline(f, z)) 
    {

        f >> val1 >> val2;
        
        g.addEdge(val1, val2);
        edges++;

    }
    g.calculateConected(edges);

    return 0;

    //  Create a graph given in the above diagram


}