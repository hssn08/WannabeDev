//Syed Hassan Abbas
//21I-0507
//BSCS Section F
#include<iostream>
using namespace std;
int main(){
	int x=0,y=1,a; //x is for range, y is for checking perfect number, a is for perfect number loop control
	cout<<"Enter a number: ";
	cin>>x;
	while(y<=x) //while the y is less than range
	{
		int z=0;
		a=1;
    while(a<y){  //while a is less than y
    	if(y%a==0){
    		z+=a; //z is for adding adding the factors
		}
		a++;
	}
		if(z==y){
			cout<<y<<" ";  //y is the perfect number
		}
		y++;
	}
	return 0;
	}


