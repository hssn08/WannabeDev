//Syed Hassan Abbas
//21I-0507
//BSCS Section F
#include<iostream>
using namespace std;
int main(){
	int x,y,z,i,j,k=0; //declatarion 
	float percent;
	cout<<"Enter the number of floors: "; 
	cin>>x;
	cout<<endl;
	if(x<1){
		while(x<1){ //this loop will cause the user to enter the value repeatedly until they enter it greater than 1
		cout<<"Unacceptable value. Try again with value bigger than 1"<<endl;
		cout<<"Enter the number of floors: ";
		cin>>x;
		}
	}
	else{
	for(int i=1;i<=x;i++){ //this loop is for entering the number of floors
	cout<<"Enter the number of rooms on floor "<<i<<": ";
	cin>>y;
		if(y<10){ //this condition and following loop is for the user to enter the value repeatedly if it is false until it turns true
		while(y<10){
		cout<<"Unacceptable value. Try again with value bigger than 10"<<endl;
			cout<<"Enter the number of rooms on floor "<<i<<": ";
		cin>>y;
		}
	}
	cout<<endl;
	cout<<"Enter the number of occupied rooms on floor "<<i<<": ";
	cin>>z;
	cout<<endl;
	j+=y; //j stores the total number of rooms
	k+=z; //k stores the total number of occupied rooms0
	}
float l=k;
float m=j;
	percent=(l/m)*100;
	cout<<"The total number of rooms is: "<<j<<endl;
	cout<<"The total number of occupied rooms is: "<<k<<endl;
	cout<<"The total number of unoccupied rooms is: "<<j-k<<endl;
	cout<<"The percentage of rooms occupied is: "<<percent<<endl;
}
return 0;
}
