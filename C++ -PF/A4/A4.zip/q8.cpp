//Syed Hassan Abbas
//21I-0507
//BSCS Section F
#include<iostream>
using namespace std;
int a();
int b();
int c();
int e();
int cap(); //this and the following 4 functions are for part d;
int line();
int upper();
int lower();

int main(){
	cout<<"a:-"<<endl;
	a();
	cout<<"b:-"<<endl;
	b();
	cout<<"c:-"<<endl;
	c();
	cout<<"d:-"<<endl;
	cap();
	line();
	upper();
	lower();
	line();
	lower();
	upper();
	line();
	cap();
	cout<<"e:-"<<endl;
	e();

}
int a(){
int i,j,x=22,y=1;
while(i<6){
	j=1;
	while(j<y){
		cout<<"\\";
		j++;
	}
	j=0;
	while(j<x){
		cout<<"!";
		j++;
	}
j=1;
	while(j<y){
		cout<<"/";
		j++;
	}
			x-=4;
			y+=2;
			i++;
cout<<endl;
}
}

int b(){
	int x=5,y=12,z=1,k=1;
	for(int i=6;i>=0;i--){
		for(int j=0;j<=x;j++){
		cout<<"*";
	}
	for(int j=0;j<=z;j++){
		cout<<" ";
	}
	for(int j=0;j<y;j++){
		cout<<"/";
	}
	for(int a=1;a<k;a++){
		cout<<"\\";
	}
		for(int j=0;j<=z;j++){
		cout<<" ";
	}
			for(int j=0;j<=x;j++){
		cout<<"*";
	}
	cout<<endl;
	x-=1;
	y-=2;
	z+=1;
	k+=2;
}
}
int c(){
		int z=8,x=2,y=1;
	for(int i=9;i>0;i--){
	for(int j=0;j<=z;j++){
		cout<<" ";
	}
	for(int k=1;k<x;k++){
		cout<<k;
	}
	for(int k=1;k<y;k++){
		int h=y-k;
		cout<<h;
	}
	z-=1;
	x+=1;
	y++;
	
	cout<<endl;
}
int e=1;
int w=8;
for(int a=8;a>0;a--){
	for(int b=0;b<=e;b++){
		cout<<" ";
	}
	for(int c=1;c<=w;c++){
		cout<<c;
	}
	e+=1;
w--;
cout<<endl;
}
}


int e(){
		int x=30,y=5;
for(int i=0;i<6;i++){
	for (int j=0;j<3;j++){
		
	for (int i=0;i<x;i++){
		cout<<" ";
	}
	if(j==0){
			for(int i=0;i<5;i++){
		cout<<"*";
	}
}
	cout<<"*";
	if(j!=0){
			for(int i=1;i<=y;i++){
				cout<<" ";
		}
	}
	if(j==0){
		for(int i=5;i<y;i++){
			cout<<" ";
		}
	}
cout<<"*";
	cout<<endl;
}


y+=5;
	x-=5;
}
for(int i=0;i<=36;i++){
	cout<<"*";
}
}

int cap(){
	int x=1,y=4;
	for(int j=5;j>=0;j--){
		for(int i=0;i<=y;i++){
		cout<<" ";
	}
	for(int i=0;i<x;i++){
		cout<<"/";
	}
	for(int i=0;i<2;i++){
		cout<<"*";
	}
	for(int i=0;i<x;i++){
		cout<<"\\";
	}
	x++;
	y--;
	cout<<endl;
}
}
int line(){
	cout<<"+";
	for(int i=0;i<=5;i++){
		cout<<"*-";
	}
	cout<<"+"<<endl;
}
int upper(){
		int x=1,y=1,z=3;
	for(int i=0;i<3;i++){
		cout<<"|";
		for(int i=0;i<=x;i++){
			cout<<"-";
		}
		for(int i=0;i<y;i++){
			cout<<"/\\";
		}
				for(int i=0;i<=z;i++){
			cout<<"-";
		}
				for(int i=0;i<y;i++){
			cout<<"/\\";
		}
				for(int i=0;i<=x;i++){
			cout<<"-";
		}
				cout<<"|";
		x--;
		y++;
		z-=2;
		cout<<endl;
	}
}
int lower(){
		int x=0,y=3,z=0;
for(int i=0;i<3;i++){
	cout<<"|";
	for(int i=0;i<x;i++){
		cout<<"-";
	}
	for(int i=0;i<y;i++){
		cout<<"\\/";
	}
		for(int i=0;i<z;i++){
		cout<<"-";
	}	
	for(int i=0;i<y;i++){
		cout<<"\\/";
	}
		for(int i=0;i<x;i++){
		cout<<"-";
	}
		cout<<"|";
	
	cout<<endl;
	x++;
	y--;
	z+=2;
}
}

