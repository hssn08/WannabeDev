//Syed Hassan Abbas
//21I-0507
//BSCS Section F
#include<iostream>
#include<cmath> 
using namespace std;
int main(){
	int x=0,y=0,l=0; //x is the number y is the power and l is for formula
	cout<<"Enter Integer: "; 
	cin>>x;
	int h=x;
	cout<<"Enter Power: ";
	cin>>y;
	int z= pow(x,y); //this variable stories 2^n
	int c= pow(x,y-1); //this variable stores 2^(n-1)
	int k= z+c; //this variable stores the whole formula of 2^n -2^n-1
	
if (z%2!=0){
	z+=3; //if the range is odd it will add 3 in the formula
}
for(;z>=0;z-=2){
	if(z<10){
		cout<<0; //this is for displaying the veritcal axis graph
	}
	cout<<z;
		for(int i=0;i<=k;i++){ //this is for displaying the stars
			cout<<" ";
		}
				cout<<"*"<<endl;
		l+=1;
		k-=l;
	}
for(int i=0;i<=h;i++){ //this is for displaying horizontal axis graph
	cout<<"   "<<i;
}
}
