//Syed Hassan Abbas
//21I-0507
//BSCS Section F
#include<iostream>
using namespace std;
int main(){
int vo;
	cout<<"Enter velocity: ";
	cin>>vo;
	float g=9.8;
	float time=0.01;
}
