//Syed Hassan Abbas
//21I-0507
//BSCS Section F
#include<iostream>
using namespace std;
int add(int,int );
int sub(int,int );
int div(int,int );
int mul(int,int );
int power(int,int);
int main(){
	int x,y;
	cout<<"Enter number 1:";
	cin>>x;
	cout<<"Enter number 2:";
	cin>>y;
	add(x,y);
	sub(x,y);
	div(x,y);
	mul(x,y);
	power(x,y);
}
int add(int x,int y){
	return 0;
}
int sub(int x,int y){
	return 0;
}
int div(int x,int y){
	return 0;
}
int mul(int x,int y){
	return 0;
}
int power(int x,int y){
	return 0;
}
