//Syed Hassan Abbas
//21I-0507
//BSCS Section F
#include<iostream>
using namespace std;
float calcterm(int,float);
float sumterm(float);
int main(){
	float x,z; //x is radian z is for calcterm function storage
	int n;
	cout<<"Enter radian: ";
	cin>>x;
	cout<<"Enter number of nth terms: ";
	cin>>n;
	for(int i=0;i<=n;i++){
		z+=calcterm(i,x);  //this variable will store function output until the loop runs
	}
	sumterm(z); //the calcterm output is sent to sumterm 
	return 0;
}
float calcterm(int c,float d){
	int pow=1,l=1,j;
	if(c==1){  //as the nth term #1 is 1 so it will return 1
		return 1;
	}
	else{
		for(int i=1;i<=c;++i){ //this loop is for power function
			pow*=d;
		}
		for(int i=1;i<=c;i++){ //this loop is for factorial
		l*=i;
		}
		j=pow/l; //nth term/factorial
	}
	return j;
}
float sumterm(float f){
	int s;
	s+=f;
cout<<"The sum of radians is: "<<s<<endl;
}

