#include<iostream>
#include<cmath>
using namespace std;
int main(){
	float x,y,z,desc,plusroot,minusroot;     //The x,y,z variables represent the values of a, b, and constant of the quadratic equation respectively. 
	cout<<"Enter value of a: ";             
	cin>>x;
	cout<<"Enter value of b: ";
	cin>>y;
	cout<<"Enter value of constant: ";
	cin>>z;
	desc=y*y-4*(x*z);                        //The discriminant variable had to be declared seperately to avoid useless complexity of program logic
	plusroot= desc>=0? (-y+sqrt(desc))/(2*x):-y/(2*x)+sqrt(-desc)/(2*x);              //Ternary conditional operator passes on to the 'False' (in this case negative discriminant) if the discriminant is imaginary
	minusroot= desc>=0? (-y-sqrt(desc))/(2*x):-y/(2*x)+sqrt(-desc)/(2*x);             
	desc>=0? cout<<"The roots are real: 1) "<<plusroot<<" 2) "<<minusroot : cout<<"The roots are imaginary: 1) "<<plusroot<<" 2) "<<minusroot;
	return 0;
}
