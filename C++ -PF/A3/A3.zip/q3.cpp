#include<iostream>
using namespace std;
int main(){
	int x,y,z;        //This program uses 3 nested switch statements.
	string s;
	cout<<"Welcome to FAST-NUCES!\nPress 1 for Islamabad campus. \nPress 2 for Lahore campus. \nPress 3 for Karachi campus. \nPress 4 for Peshawar campus. \nPress 5 for Faisalabad campus. \nPress 0 to talk to an operator."<<endl;
	cin>>x;
	switch(x){              //Here is the first switch for city choice
		case 1:
			cout<<"1) Welcome to Islamabad campus.\nPress 1 for admission related queries.\nPress 2 for academics related queries.\nPress 3 for accounts and fees related queries.\nPress 4 for information technology related queries.\nPress 5 for sports related queries.\nIf you know your desired extension, please dial it directly."<<endl;
		cin>>y;
		switch(y){          //Here lies the second switch for query choice
			case 1:
				cout<<"Press 1 for admission in school of computing\nPress 2 for admission in school of electrical engineering\nPress 3 for admission in school of management sciences"<<endl;
				cin>>z;
				switch(z){        //The third switch is repeated throughout the program 
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 2:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 3:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
            }
            break;
            case 2:
            	cout<<"Press 1 to apply for a degree/transcript generation\nPress 2 to freeze your semester\nPress 3 to add/drop courses"<<endl;
            	cin>>z;
            	switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 2:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 3:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
            }
            break;
            case 3:
            	cout<<"Press 1 for queries related to fee challan generation\nPress 2 to apply for financial aid\nPress 3 apply for a scholarship"<<endl;
            	cin>>z;
            	switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 2:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 3:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
            }
            break;
            case 4:
            	cout<<"Press 1 to apply for an email id generation\nPress 0 to talk to an IT expert"<<endl;
            	cin>>z;
            	switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 0:
                cout<<"Please wait."<<endl;
                break;
		    }	
		    break;
		    case 5:
		    	cout<<"Press 1 to get a sports venue booked\nPress 0 to talk to a representative"<<endl;
		    	cin>>z;
            	switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 0:
                cout<<"Please wait."<<endl;
                break;
            }
            break;
		    default:
		    	cout<<"Enter a valid choice."<<endl;
		}
		break;
		case 2: 
			cout<<"1) Welcome to Lahore campus.\nPress 1 for admission related queries.\nPress 2 for academics related queries.\nPress 3 for accounts and fees related queries.\nPress 4 for information technology related queries.\nPress 5 for sports related queries.\nIf you know your desired extension, please dial it directly."<<endl;
		cin>>y;
		switch(y){
			case 1:
				cout<<"Press 1 for admission in school of computing\nPress 2 for admission in school of electrical engineering\nPress 3 for admission in school of management sciences\nPress 4 for admission in school of civil engineering\nPress 5 for admission in school of science and humanities"<<endl;
				cin>>z;
				switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 2:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 3:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 4:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 5:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
            }
            break;
            case 2:
            	cout<<"Press 1 to apply for a degree/transcript generation\nPress 2 to freeze your semester\nPress 3 to add/drop courses"<<endl;
            	cin>>z;
            	switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 2:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 3:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
            }
            break;
            case 3:
            	cout<<"Press 1 for queries related to fee challan generation\nPress 2 to apply for financial aid\nPress 3 apply for a scholarship"<<endl;
            	cin>>z;
            	switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 2:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 3:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
            }
            break;
            case 4:
            	cout<<"Press 1 to apply for an email id generation\nPress 0 to talk to an IT expert"<<endl;
            	cin>>z;
            	switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 0:
                cout<<"Please wait."<<endl;
                break;
		    }	
		    break;
		    case 5:
		    	cout<<"Press 1 to get a sports venue booked\nPress 0 to talk to a representative"<<endl;
		    	cin>>z;
            	switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 0:
                cout<<"Please wait."<<endl;
                break;
            }
            break;
		    default:
		    	cout<<"Enter a valid choice."<<endl;
		}
		break;
		case 3:
			cout<<"1) Welcome to Karachi campus.\nPress 1 for admission related queries.\nPress 2 for academics related queries.\nPress 3 for accounts and fees related queries.\nPress 4 for information technology related queries.\nPress 5 for sports related queries.\nIf you know your desired extension, please dial it directly."<<endl;
		cin>>y;
		switch(y){
			case 1:
				cout<<"Press 1 for admission in school of computing\nPress 2 for admission in school of electrical engineering\nPress 3 for admission in school of management sciences"<<endl;
				cin>>z;
				switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 2:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 3:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
            }
            break;
            case 2:
            	cout<<"Press 1 to apply for a degree/transcript generation\nPress 2 to freeze your semester\nPress 3 to add/drop courses"<<endl;
            	cin>>z;
            	switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 2:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 3:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
            }
            break;
            case 3:
            	cout<<"Press 1 for queries related to fee challan generation\nPress 2 to apply for financial aid\nPress 3 apply for a scholarship"<<endl;
            	cin>>z;
            	switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 2:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 3:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
            }
            break;
            case 4:
            	cout<<"Press 1 to apply for an email id generation\nPress 0 to talk to an IT expert"<<endl;
            	cin>>z;
            	switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 0:
                cout<<"Please wait."<<endl;
                break;
		    }	
		    break;
		    case 5:
		    	cout<<"Press 1 to get a sports venue booked\nPress 0 to talk to a representative"<<endl;
		    	cin>>z;
            	switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 0:
                cout<<"Please wait."<<endl;
                break;
            }
            break;
		    default:
		    	cout<<"Enter a valid choice."<<endl;
		}
		break;
				case 4:
			cout<<"1) Welcome to Peshawar campus.\nPress 1 for admission related queries.\nPress 2 for academics related queries.\nPress 3 for accounts and fees related queries.\nPress 4 for information technology related queries.\nIf you know your desired extension, please dial it directly."<<endl;
		cin>>y;
		switch(y){
			case 1:
				cout<<"Press 1 for admission in school of computing\nPress 2 for admission in school of electrical engineering"<<endl;
				cin>>z;
				switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 2:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
            }
            break;
            case 2:
            	cout<<"Press 1 to apply for a degree/transcript generation\nPress 2 to freeze your semester\nPress 3 to add/drop courses"<<endl;
            	cin>>z;
            	switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 2:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 3:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
            }
            break;
            case 3:
            	cout<<"Press 1 for queries related to fee challan generation\nPress 2 to apply for financial aid\nPress 3 apply for a scholarship"<<endl;
            	cin>>z;
            	switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 2:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 3:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
            }
            break;
            case 4:
            	cout<<"Press 1 to apply for an email id generation\nPress 0 to talk to an IT expert"<<endl;
            	cin>>z;
            	switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 0:
                cout<<"Please wait."<<endl;
                break;
		    }	
		    break;
		    default:
		    	cout<<"Enter a valid choice."<<endl;
		}
		break;
		case 5:
			cout<<"1) Welcome to Faisalabad campus.\nPress 1 for admission related queries.\nPress 2 for academics related queries.\nPress 3 for accounts and fees related queries.\nPress 4 for information technology related queries.\nPress 5 for sports related queries.\nIf you know your desired extension, please dial it directly."<<endl;
		cin>>y;
		switch(y){
			case 1:
				cout<<"Press 1 for admission in school of computing\nPress 2 for admission in school of electrical engineering\nPress 3 for admission in school of management sciences\nPress 4 for admission in school of civil engineering\nPress 5 for admission in school of science and humanities"<<endl;
				cin>>z;
				switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 2:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 3:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 4:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 5:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
            }
            break;
            case 2:
            	cout<<"Press 1 to apply for a degree/transcript generation\nPress 2 to freeze your semester\nPress 3 to add/drop courses"<<endl;
            	cin>>z;
            	switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 2:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 3:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
            }
            break;
            case 3:
            	cout<<"Press 1 for queries related to fee challan generation\nPress 2 to apply for financial aid\nPress 3 apply for a scholarship"<<endl;
            	cin>>z;
            	switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 2:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 3:
                cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
            }
            break;
            case 4:
            	cout<<"Press 1 to apply for an email id generation\nPress 0 to talk to an IT expert"<<endl;
            	cin>>z;
            	switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 0:
                cout<<"Please wait."<<endl;
                break;
		    }	
		    break;
		    case 5:
		    	cout<<"Press 1 to get a sports venue booked\nPress 0 to talk to a representative"<<endl;
		    	cin>>z;
            	switch(z){
				case 1:
				cout<<"Please enter your query: ";
				cin>>s;
                cout<<"Your query is registered. We will get back to you soon."<<endl;
                break;
                case 0:
                cout<<"Please wait."<<endl;
                break;
            }
            break;
		    default:
		    	cout<<"Enter a valid choice."<<endl;
		}
		break;
		case 0:
			cout<<"Please wait to talk to the operator"<<endl;
			break;
		}

return 0;
}
