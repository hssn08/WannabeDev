#include<iostream>
using namespace std;
int main(){
	int a,b,c,d,e,f,g;                    //These variables are for different notes, highest to lowest in order respectively.
	int x,y;
	cout<<"Enter amount(from 100 to 100,000): ";
	cin>>x;
	if(x>=100&&x<=100000){
		cout<<"Enter prefferred notes: ";          
		cin>>y;
		switch (y){                        //The switch here is for checking the preferred notes.
		case 500:
			if(x>=500*200){               //The program first checks if the amount is greater than the 200 preferred.
				a=200;
				x-=500*200;
			}
			else{
				a=x/500;                 //If not, then it simply divides the amount with the note variable and deducts the note variable from the total amount
				x-=500*a;                //Leaving behind the residual value for the other notes.
			}
			if(x>=100){
				b=x/100;
				x-=100*b;
			}
				if(x>=50){
				c=x/50;
				x-=50*c;
			}
				if(x>=20){
				d=x/20;
				x-=20*d;
			}
				if(x>=10){
				e=x/10;
				x-=10*e;
			}
				if(x>=5){
				f=x/5;
				x-=5*f;
			}
				if(x>=1){
				g=x*1;
				x-=1*g;
			}
			cout<<"Currency Note: Number"<<endl;
			cout<<"500          : "<<a<<endl;
			cout<<"100          : "<<b<<endl;
			cout<<"50           : "<<c<<endl;
			cout<<"20           : "<<d<<endl;
			cout<<"10           : "<<e<<endl;
			cout<<"5            : "<<f<<endl;
			cout<<"1            : "<<g<<endl;
			break;
			
			case 100:
			if(x>=100*200){                   //Here the 500 note is replaced by the preffered note, it will go on like this throughout the program.
				b=200;
				x-=100*200;
			}
			else{
				b=x/100;
				x-=100*b;
			}
			if(x>=500){
				a=x/500;
				x-=500*a;
			}
				if(x>=50){
				c=x/50;
				x-=50*c;
			}
				if(x>=20){
				d=x/20;
				x-=20*d;
			}
				if(x>=10){
				e=x/10;
				x-=10*e;
			}
				if(x>=5){
				f=x/5;
				x-=5*f;
			}
				if(x>=1){
				g=x*1;
				x-=1*g;
			}
			cout<<"Currency Note: Number"<<endl;
			cout<<"500          : "<<a<<endl;
			cout<<"100          : "<<b<<endl;
			cout<<"50           : "<<c<<endl;
			cout<<"20           : "<<d<<endl;
			cout<<"10           : "<<e<<endl;
			cout<<"5            : "<<f<<endl;
			cout<<"1            : "<<g<<endl;
			break;
			
			case 50:
			if(x>=50*200){
				c=200;
				x-=50*200;
			}
			else{
				c=x/50;
				x-=50*c;
			}
				if(x>=500){
				a=x/500;
				x-=500*a;
			}
			if(x>=100){
				b=x/100;
				x-=100*b;
			}
				if(x>=20){
				d=x/20;
				x-=20*d;
			}
				if(x>=10){
				e=x/10;
				x-=10*e;
			}
				if(x>=5){
				f=x/5;
				x-=5*f;
			}
				if(x>=1){
				g=x*1;
				x-=1*g;
			}
			cout<<"Currency Note: Number"<<endl;
			cout<<"500          : "<<a<<endl;
			cout<<"100          : "<<b<<endl;
			cout<<"50           : "<<c<<endl;
			cout<<"20           : "<<d<<endl;
			cout<<"10           : "<<e<<endl;
			cout<<"5            : "<<f<<endl;
			cout<<"1            : "<<g<<endl;
			break;
			
			case 20:
			if(x>=20*200){
				d=200;
				x-=20*200;
			}
			else{
				d=x/20;
				x-=20*d;
			}
				if(x>=500){
				a=x/500;
				x-=500*a;
			}
			if(x>=100){
				b=x/100;
				x-=100*b;
			}
				if(x>=50){
				c=x/50;
				x-=50*c;
			}
				if(x>=10){
				e=x/10;
				x-=10*e;
			}
				if(x>=5){
				f=x/5;
				x-=5*f;
			}
				if(x>=1){
				g=x*1;
				x-=1*g;
			}
			cout<<"Currency Note: Number"<<endl;
			cout<<"500          : "<<a<<endl;
			cout<<"100          : "<<b<<endl;
			cout<<"50           : "<<c<<endl;
			cout<<"20           : "<<d<<endl;
			cout<<"10           : "<<e<<endl;
			cout<<"5            : "<<f<<endl;
			cout<<"1            : "<<g<<endl;
			break;
				
			case 10:
			if(x>=10*200){
				e=200;
				x-=10*200;
			}
			else{
				e=x/10;
				x-=10*e;
			}
				if(x>=500){
				a=x/500;
				x-=500*a;
			}
			if(x>=100){
				b=x/100;
				x-=100*b;
			}
				if(x>=50){
				c=x/50;
				x-=50*c;
			}
				if(x>=20){
				d=x/20;
				x-=20*d;
			}
				if(x>=5){
				f=x/5;
				x-=5*f;
			}
				if(x>=1){
				g=x*1;
				x-=1*g;
			}
			cout<<"Currency Note: Number"<<endl;
			cout<<"500          : "<<a<<endl;
			cout<<"100          : "<<b<<endl;
			cout<<"50           : "<<c<<endl;
			cout<<"20           : "<<d<<endl;
			cout<<"10           : "<<e<<endl;
			cout<<"5            : "<<f<<endl;
			cout<<"1            : "<<g<<endl;
			break;
				
			case 5:
			if(x>=5*200){
				f=200;
				x-=5*200;
			}
			else{
				f=x/5;
				x-=5*f;
			}
				if(x>=500){
				a=x/500;
				x-=500*a;
			}
			if(x>=100){
				b=x/100;
				x-=100*b;
			}
				if(x>=50){
				c=x/50;
				x-=50*c;
			}
				if(x>=20){
				d=x/20;
				x-=20*d;
			}
				if(x>=10){
				e=x/10;
				x-=10*e;
			}
				if(x>=1){
				g=x*1;
				x-=1*g;
			}
			cout<<"Currency Note: Number"<<endl;
			cout<<"500          : "<<a<<endl;
			cout<<"100          : "<<b<<endl;
			cout<<"50           : "<<c<<endl;
			cout<<"20           : "<<d<<endl;
			cout<<"10           : "<<e<<endl;
			cout<<"5            : "<<f<<endl;
			cout<<"1            : "<<g<<endl;
			break;
			
			case 1:
			if(x>=200){
				g=200;
				x-=200;
			}
			else{
				g=x;
				x-=g;
			}
				if(x>=500){
				a=x/500;
				x-=500*a;
			}
			if(x>=100){
				b=x/100;
				x-=100*b;
			}
				if(x>=50){
				c=x/50;
				x-=50*c;
			}
				if(x>=20){
				d=x/20;
				x-=20*d;
			}
				if(x>=10){
				e=x/10;
				x-=10*e;
			}
				if(x>=5){
				f=x*5;
				x-=5*f;
			}
			cout<<"Currency Note: Number"<<endl;
			cout<<"500          : "<<a<<endl;
			cout<<"100          : "<<b<<endl;
			cout<<"50           : "<<c<<endl;
			cout<<"20           : "<<d<<endl;
			cout<<"10           : "<<e<<endl;
			cout<<"5            : "<<f<<endl;
			cout<<"1            : "<<g<<endl;
			break;
			}
			}
			else{
				cout<<"Enter a number withing range"<<endl;                 //This is for when the user enters a value out of range specified in the question.
			}
			return 0;
	}
