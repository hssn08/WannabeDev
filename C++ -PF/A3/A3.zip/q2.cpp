#include<iostream>
using namespace std;
int main(){                   //the program is pretty straightforward and self explanatory so i do not feel any comments are required
string outlook;
cout<<"Welcome to Trip Advisor"<<endl;
cout<<"Enter the outlook (sunny,overcast,rain)"<<endl;
cin>>outlook;
if(outlook=="sunny"){
int humidity;
cout<<"Enter the humidity(0-100)"<<endl;
cin>>humidity;
if(humidity<40){
cout<<"Go for trip"<<endl;
}
else if(humidity>=40&&humidity<60){
string temperature;
cout<<"Enter the temperature(normal/high)"<<endl;
cin>>temperature;
if(temperature=="normal"){
cout<<"Go for trip"<<endl;
}
else if(temperature=="high"){
cout<<"Stay at home"<<endl;
}
}
else if(humidity>60){
cout<<"Stay at home"<<endl;
}
}
else if(outlook=="overcast"){
int precip;
cout<<"Enter the chance of Precipitation(0-100)"<<endl;
cin>>precip;
if(precip<50){
string wind;
cout<<"Enter the wind factor(moderate/strong)"<<endl;
cin>>wind;
if(wind=="moderate"){
cout<<"Go for trip"<<endl;
}
else if(wind=="strong"){
cout<<"Stay at home"<<endl;
}
}
else if(precip>=50){
cout<<"Stay at home"<<endl;
}
}
else if(outlook=="rain"){
string visibility;
cout<<"Enter the visibility(normal/poor)"<<endl;
cin>>visibility;
if(visibility=="normal"){
cout<<"Go for trip"<<endl;
}
else if(visibility=="poor"){
cout<<"Stay at home"<<endl;
}
}
return 0;
}


