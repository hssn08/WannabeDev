#include<iostream>
using namespace std;
int main(){
	float g,bill,i,billa,billb,billc,aa,bb; //g variable is the number of GBs and the bill is the total amount due.
	char p;
	cout<<"Enter GBs: ";
	cin>>g;
	i=g;            //the i variable is given the value of g for later use in the program
	cout<<"Enter the Package(A/B/C): ";
	cin>>p;
	switch (p){
	case 'A':       //drop down case statements, OR operator was not working on my compiler.
	case 'a':
	if(g>1){
	g-=1;
	g*=1000;
	g/=100;           //here g is multiplied and divided so that it is converts from GBs to MBs and then points to be divided with each unit of 100 mbs.
	bill=(g*20)+100;
	cout<<"The total bill is: "<<bill<<endl;
	}
	else{
	cout<<"The total bill is: 100";
	}
	break;
	
	case 'B':
	case 'b':
	if(g>2.5){
	g-=2.5;
	g*=1000;
	g/=100;
	bill=(g*10)+200;
	cout<<"The total bill is: "<<bill<<endl;
	}
	else{
	cout<<"The total bill is: 200";
	}
	break;
	
	case 'C':
	case 'c':
	cout<<"The total bill is: 1000";
	break;
}
cout<<"\n--------Part B--------"<<endl;
aa=i;
bb=i;
	if(aa>1){                 //this is almost the same as PART A but here aa is used instead of a, same logic is applied after little modification
	aa-=1;
	aa*=1000;
	aa/=100;
	billa=(aa*20)+100;          //The bill is divided into three parts, each per package respectively so that they can be compared.
	}
	else{
	billa=100;
}
	if(bb>2.5){                 
	bb-=2.5;
	bb*=1000;
	bb/=100;
	billb=(bb*10)+200;
	}
	else{
	billb=200;
}
billc=1000;                       //Because the package c is unlimited.
switch(p){
	case 'A':
	case 'a':
		if(billa<billb && billa<billc){                 //4 conditions for four different scenarios. 
			cout<<"Package A is good for you"<<endl;
		}
		else if(billa<billb && billa>billc){
			cout<<"You could've saved Rs."<<billa-billc<<" if you selected Package C"<<endl;
		}
		else if(billa>billb && billa>billc){
			cout<<"You could've saved Rs."<<billa-billc<<" if you selected Package C & You could've saved Rs."<<billa-billb<<" if you selected Package B"<<endl;
		}
		else if(billa>billb && billa<billc){
			cout<<"You could've saved Rs."<<billa-billb<<" if you selected Package B"<<endl;
}
break;
	case 'B':
	case 'b':
		if(billb<billa && billb<billc){
			cout<<"Package B is good for you"<<endl;
		}
		else if(billb<billa && billb>billc){
			cout<<"You could've saved Rs."<<billb-billc<<" if you selected Package C"<<endl;
		}
		else if(billb>billa && billb>billc){
			cout<<"You could've saved Rs."<<billb-billc<<" if you selected Package C & You could've saved Rs."<<billb-billa<<" if you selected Package A"<<endl;
		}
		else if(billb>billa && billb<billc){
			cout<<"You could've saved Rs."<<billb-billa<<" if you selected Package A"<<endl;
		}
break;
	case 'C':
	case 'c':
		if(billc<billa && billc<billb){
			cout<<"Package C is good for you"<<endl;
		}
		else if(billc<billa && billc>billb){
			cout<<"You could've saved Rs."<<billc-billb<<" if you selected Package B"<<endl;
		}
		else if(billc>billa && billc>billb){
			cout<<"You could've saved Rs."<<billc-billb<<" if you selected Package B & You could've saved Rs."<<billc-billa<<" if you selected Package A"<<endl;
		}
		else if(billc>billa && billc<billb){
			cout<<"You could've saved Rs."<<billc-billa<<" if you selected Package A"<<endl;
break;
}
}
return 0;	
}
