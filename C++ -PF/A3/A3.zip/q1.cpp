#include<iostream>
#include<cstdlib>
#include <time.h> 
using namespace std;
int main(){
srand (time(NULL));           //All teams are assigned seperate variables for point assignment
string TeamA="Afghanistan";
string TeamB="Australia";
string TeamC="Bangladesh";
string TeamD="England";
string TeamE="India";
string TeamF="Ireland";
string TeamG="Pakistan";
string TeamH="Scotland";
string TeamI="South Africa";
string TeamJ="Sri Lanka";
string TeamK="West Indies";
string TeamL="Zimbabwe";
int a1 = rand() % 100;        //100 Random numbers are generated for each match
int a2 = rand() % 100;   
int a3 = rand() % 100;   
int a4 = rand() % 100;   
int a5 = rand() % 100;   
int a6 = rand() % 100;   
int a7 = rand() % 100;   
int a8 = rand() % 100;   
int a9 = rand() % 100;   
int a10 = rand() % 10000;   
int a11 = rand() % 10000;  
int a12 = rand() % 10000;  
int a13 = rand() % 1000;  
int a14 = rand() % 100;  
int toss = rand() % 99;     //99 random numbers so that the toss can be split three ways fairly
int a,b,c,d,e,f,g,h,i,j,k,l;
cout<< "Round One: \n";
if (a1%2==0){
cout<< "Match 1: "<< TeamA <<" vs. "<< TeamB <<", won by "<< TeamA<<endl;         //The losing teams are given 0 points 
a=1;
b=0;
}
else{
cout<< "Match 1: "<< TeamA <<" vs. "<< TeamB <<", won by "<< TeamB<<endl;
b=1;
a=0;
}
if (a2%2==0){
cout<< "Match 2: "<< TeamC <<" vs. "<< TeamD <<", won by "<< TeamC<<endl;
c=1;
d=0;
}
else{
cout<< "Match 2: "<< TeamC <<" vs. "<< TeamD <<", won by "<< TeamD<<endl;
d=1;
c=0;
}
if (a3%2==0){
cout<< "Match 3: "<< TeamE <<" vs. "<< TeamF <<", won by "<< TeamE<<endl;
e=1;
f=0;
}
else{
cout<< "Match 3: "<< TeamE <<" vs. "<< TeamF <<", won by "<< TeamF<<endl;
f=1;
e=0;
}
if (a4%2==0){
cout<< "Match 4: "<< TeamG <<" vs. "<< TeamH <<", won by "<< TeamG<<endl;
g=1;
h=0;
}
else{
cout<< "Match 4: "<< TeamG <<" vs. "<< TeamH <<", won by "<< TeamH<<endl;
h=1;
g=0;
}
if (a5%2==0){
cout<< "Match 5: "<< TeamI <<" vs. "<< TeamJ <<", won by "<< TeamI<<endl;
i=1;
j=0;
}
else{
cout<< "Match 5: "<< TeamI <<" vs. "<< TeamJ <<", won by "<< TeamJ<<endl;
j=1;
i=0;
}
if (a6%2==0){
cout<< "Match 6: "<< TeamK <<" vs. "<< TeamL <<", won by "<< TeamK<<endl;
k=1;
l=0;
}
else{
cout<< "Match 6: "<< TeamK <<" vs. "<< TeamL <<", won by "<< TeamL<<endl;
l=1;
k=0;
}
if(a==0){             //The losing teams variable are given null value
TeamA="";
}
if(b==0){
TeamB="";
}
if(c==0){
TeamC="";
}
if(d==0){
TeamD="";
}
if(e==0){
TeamE="";
}
if(f==0){
TeamF="";
}
if(g==0){
TeamG="";
}
if(h==0){
TeamH="";
}
if(i==0){
TeamI="";
}
if(j==0){
TeamJ="";
}
if(k==0){
TeamK="";
}
if(l==0){
TeamL="";
}
cout<< "Round Two: \n";
if (a7%2==0){
cout<< "Match 7: "<< TeamA <<TeamB <<" vs. "<< TeamC <<TeamD <<", won by "<< TeamA <<TeamB<<endl;
a=2;
b=2;
d=0;
c=0;
}
else{
cout<< "Match 7: "<< TeamA <<TeamB <<" vs. "<< TeamC <<TeamD <<", won by "<< TeamC <<TeamD<<endl;
d=2;
c=2;
a=0;
b=0;
}
if (a8%2==0){
cout<< "Match 8: "<< TeamE <<TeamF <<" vs. "<< TeamG <<TeamH <<", won by "<< TeamE <<TeamF<<endl;
e=2;
f=2;
g=0;
h=0;
}
else{
cout<< "Match 8: "<< TeamE <<TeamF <<" vs. "<< TeamG <<TeamH <<", won by "<< TeamG <<TeamH<<endl;
g=2;
h=2;
e=0;
f=0;
}
if (a9%2==0){
cout<< "Match 9: "<< TeamI <<TeamJ <<" vs. "<< TeamK <<TeamL <<", won by "<< TeamI <<TeamJ<<endl;
i=2;
j=2;
k=0;
l=0;
}
else{
cout<< "Match 9: "<< TeamI <<TeamJ <<" vs. "<< TeamK <<TeamL <<", won by "<< TeamK <<TeamL<<endl;
k=2;
l=2;
i=0;
j=0;
}
if(a==0){
TeamA="";
}
if(b==0){
TeamB="";
}
if(c==0){
TeamC="";
}
if(d==0){
TeamD="";
}
if(e==0){
TeamE="";
}
if(f==0){
TeamF="";
}
if(g==0){
TeamG="";
}
if(h==0){
TeamH="";
}
if(i==0){
TeamI="";
}
if(j==0){
TeamJ="";
}
if(k==0){
TeamK="";
}
if(l==0){
TeamL="";
}
int m=0,n=0,o=0;
cout<< "Round Three(round-robin): \n";
if (a10<7000){
cout<< "Match 10: "<< TeamA <<TeamB <<TeamC <<TeamD<<" vs. "<< TeamE <<TeamF <<TeamG<< TeamH <<", won by "<< TeamA <<TeamB <<TeamC <<TeamD<<endl;
m=1;
}
else{
cout<< "Match 10: "<< TeamA <<TeamB <<TeamC <<TeamD<<" vs. "<< TeamE <<TeamF <<TeamG<< TeamH <<", won by "<< TeamE <<TeamF <<TeamG<< TeamH<<endl;
n=1;
}
if (a11<7000){
cout<< "Match 11: "<< TeamE <<TeamF <<TeamG<< TeamH<<" vs. "<< TeamI <<TeamJ <<TeamK<< TeamL <<", won by "<< TeamE <<TeamF <<TeamG<< TeamH<<endl;
n=1;
}
else{
cout<< "Match 11: "<< TeamE <<TeamF <<TeamG<< TeamH<<" vs. "<< TeamI <<TeamJ <<TeamK<< TeamL <<", won by "<< TeamI <<TeamJ <<TeamK<< TeamL <<endl;
o=1;
}
if (a12<7000){
cout<< "Match 12: "<< TeamI <<TeamJ <<TeamK<< TeamL<<" vs. "<< TeamA <<TeamB <<TeamC <<TeamD <<", won by "<< TeamI <<TeamJ <<TeamK<< TeamL<<endl;
o=1;
}
else{
cout<< "Match 12: "<< TeamI <<TeamJ <<TeamK<< TeamL<<" vs. "<< TeamA <<TeamB <<TeamC <<TeamD <<", won by "<< TeamA <<TeamB <<TeamC <<TeamD<<endl;
m=1;
}
int p=m+n+o;          //The variable p is used for calculating if the victory is three sided or two sided
if(p==3){
if (toss<=33){
cout<< TeamA <<TeamB <<TeamC <<TeamD<<" qualified for the final after winning the toss"<<endl;
if (a13%2==0){
cout<< "Match 13: "<< TeamE <<TeamF <<TeamG<< TeamH<<" vs. "<< TeamI <<TeamJ <<TeamK<< TeamL<<", won by "<< TeamE <<TeamF <<TeamG<< TeamH<<endl;
if (a14%2==0){
cout<<"Final Match: \n";
cout<< "Match 14: "<< TeamA <<TeamB <<TeamC <<TeamD<<" vs. "<< TeamE <<TeamF <<TeamG<< TeamH<<", won by "<< TeamA <<TeamB <<TeamC <<TeamD<<endl;
cout<<"Congratulations to "<< TeamA <<TeamB <<TeamC <<TeamD<<" for winning the T20 World Cup 2020."<<endl;
}
else{
cout<<"Final Match: \n";
cout<< "Match 14: "<< TeamA <<TeamB <<TeamC <<TeamD<<" vs. "<< TeamE <<TeamF <<TeamG<< TeamH<<", won by "<< TeamE <<TeamF <<TeamG<< TeamH<<endl;
cout<<"Congratulations to "<< TeamE <<TeamF <<TeamG<< TeamH<<" for winning the T20 World Cup 2020."<<endl;
}
}
else{
cout<< "Match 13: "<< TeamE <<TeamF <<TeamG<< TeamH<<" vs. "<< TeamI <<TeamJ <<TeamK<< TeamL<<", won by "<< TeamI <<TeamJ <<TeamK<< TeamL<<endl;
if (a14%2==0){
cout<<"Final Match: \n";
cout<< "Match 14: "<< TeamA <<TeamB <<TeamC <<TeamD<<" vs. "<< TeamI <<TeamJ <<TeamK<< TeamL<<", won by "<< TeamA <<TeamB <<TeamC <<TeamD<<endl;
cout<<"Congratulations to "<< TeamA <<TeamB <<TeamC <<TeamD<<" for winning the T20 World Cup 2020."<<endl;
}
else{
cout<<"Final Match: \n";
cout<< "Match 14: "<< TeamA <<TeamB <<TeamC <<TeamD<<" vs. "<< TeamI <<TeamJ <<TeamK<< TeamL<<", won by "<< TeamI <<TeamJ <<TeamK<< TeamL<<endl;
cout<<"Congratulations to "<< TeamI <<TeamJ <<TeamK<< TeamL<<" for winning the T20 World Cup 2020."<<endl;
}
}
}

else if (toss<=66&&toss>33){
cout<< TeamE <<TeamF <<TeamG<< TeamH<<" qualified for the final after winning the toss"<<endl;
if (a13%2==0){
cout<< "Match 13: "<< TeamA <<TeamB <<TeamC <<TeamD<<" vs. "<< TeamI <<TeamJ <<TeamK<< TeamL<<", won by "<< TeamA <<TeamB <<TeamC <<TeamD<<endl;
if (a14%2==0){
cout<<"Final Match: \n";
cout<< "Match 14: "<< TeamA <<TeamB <<TeamC <<TeamD<<" vs. "<< TeamE <<TeamF <<TeamG<< TeamH<<", won by "<< TeamA <<TeamB <<TeamC <<TeamD<<endl;
cout<<"Congratulations to "<< TeamA <<TeamB <<TeamC <<TeamD<<" for winning the T20 World Cup 2020."<<endl;
}
else{
cout<<"Final Match: \n";
cout<< "Match 14: "<< TeamA <<TeamB <<TeamC <<TeamD<<" vs. "<< TeamE <<TeamF <<TeamG<< TeamH<<", won by "<< TeamE <<TeamF <<TeamG<< TeamH<<endl;
cout<<"Congratulations to "<< TeamE <<TeamF <<TeamG<< TeamH<<" for winning the T20 World Cup 2020."<<endl;
}
}
else{
cout<< "Match 13: "<< TeamA <<TeamB <<TeamC <<TeamD<<" vs. "<< TeamI <<TeamJ <<TeamK<< TeamL<<", won by "<< TeamI <<TeamJ <<TeamK<< TeamL<<endl;
if (a14%2==0){
cout<<"Final Match: \n";
cout<< "Match 14: "<< TeamE <<TeamF <<TeamG<< TeamH<<" vs. "<< TeamI <<TeamJ <<TeamK<< TeamL<<", won by "<< TeamE <<TeamF <<TeamG<< TeamH<<endl;
cout<<"Congratulations to "<< TeamE <<TeamF <<TeamG<< TeamH <<" for winning the T20 World Cup 2020."<<endl;
}
else{
cout<<"Final Match: \n";
cout<< "Match 14: "<< TeamE <<TeamF <<TeamG<< TeamH<<" vs. "<< TeamI <<TeamJ <<TeamK<< TeamL<<", won by "<< TeamI <<TeamJ <<TeamK<< TeamL<<endl;
cout<<"Congratulations to "<< TeamI <<TeamJ <<TeamK<< TeamL<<" for winning the T20 World Cup 2020."<<endl;
}
}
}
else{
cout<< TeamI <<TeamJ <<TeamK<< TeamL<<" qualified for the final after winning the toss"<<endl;
if (a13%2==0){
cout<< "Match 13: "<< TeamA <<TeamB <<TeamC <<TeamD<<" vs. "<< TeamE <<TeamF <<TeamG<< TeamH<<", won by "<< TeamA <<TeamB <<TeamC <<TeamD<<endl;
if (a14%2==0){
cout<<"Final Match: \n";
cout<< "Match 14: "<< TeamA <<TeamB <<TeamC <<TeamD<<" vs. "<< TeamI <<TeamJ <<TeamK<< TeamL<<", won by "<< TeamA <<TeamB <<TeamC <<TeamD<<endl;
cout<<"Congratulations to "<< TeamA <<TeamB <<TeamC <<TeamD<<" for winning the T20 World Cup 2020."<<endl;
}
else{
cout<<"Final Match: \n";
cout<< "Match 14: "<< TeamA <<TeamB <<TeamC <<TeamD<<" vs. "<< TeamI <<TeamJ <<TeamK<< TeamL<<", won by "<< TeamI <<TeamJ <<TeamK<< TeamL<<endl;
cout<<"Congratulations to "<< TeamI <<TeamJ <<TeamK<< TeamL<<" for winning the T20 World Cup 2020."<<endl;
}
}
else{
cout<< "Match 13: "<< TeamA <<TeamB <<TeamC <<TeamD<<" vs. "<< TeamE <<TeamF <<TeamG<< TeamH<<", won by "<< TeamE <<TeamF <<TeamG<< TeamH<<endl;
if (a14%2==0){
cout<<"Final Match: \n";
cout<< "Match 14: "<< TeamE <<TeamF <<TeamG<< TeamH<<" vs. "<< TeamI <<TeamJ <<TeamK<< TeamL<<", won by "<< TeamE <<TeamF <<TeamG<< TeamH<<endl;
cout<<"Congratulations to "<< TeamE <<TeamF <<TeamG<< TeamH <<" for winning the T20 World Cup 2020."<<endl;
}
else{
cout<<"Final Match: \n";
cout<< "Match 14: "<< TeamE <<TeamF <<TeamG<< TeamH<<" vs. "<< TeamI <<TeamJ <<TeamK<< TeamL<<", won by "<< TeamI <<TeamJ <<TeamK<< TeamL<<endl;
cout<<"Congratulations to "<< TeamI <<TeamJ <<TeamK<< TeamL<<" for winning the T20 World Cup 2020."<<endl;
}
}
}
}
else if(p==2){
cout<<"Final Match: \n";
if (m==0){
if (a13%2==0){
cout<< "Match 13: "<< TeamE <<TeamF <<TeamG<< TeamH<<" vs. "<< TeamI <<TeamJ <<TeamK<< TeamL<<", won by "<< TeamE <<TeamF <<TeamG<< TeamH<<endl;
cout<<"Congratulations to "<< TeamE <<TeamF <<TeamG<< TeamH <<" for winning the T20 World Cup 2020."<<endl;
}
else{
cout<< "Match 13: "<< TeamE <<TeamF <<TeamG<< TeamH<<" vs. "<< TeamI <<TeamJ <<TeamK<< TeamL<<", won by "<< TeamI <<TeamJ <<TeamK<< TeamL<<endl;
cout<<"Congratulations to "<< TeamI <<TeamJ <<TeamK<< TeamL<<" for winning the T20 World Cup 2020."<<endl;
}
}
else if (n==0){
if (a13%2==0){
cout<< "Match 13: "<< TeamA <<TeamB <<TeamC <<TeamD<<" vs. "<< TeamI <<TeamJ <<TeamK<< TeamL<<", won by "<< TeamA <<TeamB <<TeamC <<TeamD<<endl;
cout<<"Congratulations to "<< TeamA <<TeamB <<TeamC <<TeamD<<" for winning the T20 World Cup 2020."<<endl;
}
else{
cout<< "Match 13: "<< TeamA <<TeamB <<TeamC <<TeamD<<" vs. "<< TeamI <<TeamJ <<TeamK<< TeamL<<", won by "<< TeamI <<TeamJ <<TeamK<< TeamL<<endl;
cout<<"Congratulations to "<< TeamI <<TeamJ <<TeamK<< TeamL<<" for winning the T20 World Cup 2020."<<endl;
}
}
else if (o==0){
if (a13%2==0){
cout<< "Match 13: "<< TeamA <<TeamB <<TeamC <<TeamD<<" vs. "<< TeamE <<TeamF <<TeamG<< TeamH<<", won by "<< TeamA <<TeamB <<TeamC <<TeamD<<endl;
cout<<"Congratulations to "<< TeamA <<TeamB <<TeamC <<TeamD<<" for winning the T20 World Cup 2020."<<endl;
}
else{
cout<< "Match 13: "<< TeamA <<TeamB <<TeamC <<TeamD<<" vs. "<< TeamE <<TeamF <<TeamG<< TeamH<<", won by "<< TeamE <<TeamF <<TeamG<< TeamH<<endl;
cout<<"Congratulations to "<< TeamE <<TeamF <<TeamG<< TeamH<<" for winning the T20 World Cup 2020."<<endl;
}
}
}
return 0;
}
//All the other variables are null so only the victorious team will be displayed. This is full of redundance but is a quite firm strategy for programming tournaments


