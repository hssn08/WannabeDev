#include<iostream>
using namespace std;
int main(){
	int x,a,b,c,d,e,f,bill;                 //Nested switch statements, the program is self explanatory.
	cout<<"1. Burgers\n2. Pizzas\n3. Sandwiches\nPlease enter your choice (1/2/3): ";
	cin>>x;
	switch (x){
		case 1:
			cout<<"1. Crispy Chicken Burger (600 Rs.)\n2. Beef Burger (650 Rs.)\n3. Fish Burger (700 Rs.)\nPlease enter your choice (1/2/3): ";
			cin>>a;
			cout<<"Enter quantity: ";
			cin>>b;
			switch(a){
				case 1:
					bill+=600*b;            //the bill is multiplies with quantity variable b
					break;
				case 2:
					bill+=650*b;
					break;
				case 3:
					bill+=700*b;
					break;
				default:
					cout<<"Please enter a valid choice."<<endl;
			}
			break;
		case 2:
				cout<<"1. Chicken Tikka\n2. Chicken Fajita\n3. Four Seasons\nPlease enter your choice (1/2/3): ";
			cin>>c;
			c=0;
			switch (c){
				case 0: 
				cout<<"1. Small(850 Rs.)\n2. Medium(1200 Rs.)\n3. Large(1600 Rs.)\nPlease enter your choice(1/2/3): ";
				cin>>c;
				break;
			}
			cout<<"Enter quantity: ";
			cin>>d;
			switch(c){
				case 1:
					bill+=850*d;
					break;
				case 2:
					bill+=1200*d;
					break;
				case 3:
					bill+=1600*d;
					break;
				default:
					cout<<"Please enter a valid choice."<<endl;
			}
			break;
		case 3:
			cout<<"1. Club(300 Rs.)\n2. Chicken(325 Rs.)\n3. Vegetables(315 Rs.)\nPlease enter your choice(1/2/3): ";
			cin>>e;
			cout<<"Enter Quantity: ";
			cin>>f;
			switch(e){
					case 1:
					bill+=300*f;
					break;
				case 2:
					bill+=325*f;
					break;
				case 3:
					bill+=315*f;
					break;
				default:
					cout<<"Please enter a valid choice."<<endl;
			}
			break;
	}
	cout<<"Your bill is: "<<bill<<endl;
	return 0;
}
