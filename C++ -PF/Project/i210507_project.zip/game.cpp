//============================================================================
// Name        : Hassan Abbas
// Author      : FAST CS Department Hassan Abbas
// Version     :
// Copyright   : (c) Reserved
// Description : Basic 2D game of Rush Hour...
//============================================================================

#ifndef RushHour_CPP_
#define RushHour_CPP_
#include "util.h"
#include <iostream>
#include<string>
#include<ctime>
#include<cstdlib>
#include<cmath> // for basic math functions such as cos, sin, sqrt
using namespace std;

// seed the random numbers generator by current time (see the documentation of srand for further help)...

/* Function sets canvas size (drawing area) in pixels...
 *  that is what dimensions (x and y) your game will have
 *  Note that the bottom-left coordinate has value (0,0) and top-right coordinate has value (width-1,height-1)
 * */
void SetCanvasSize(int width, int height) {
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, width, 0, height, -1, 1); // set the screen size to given width and height.
	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity();
}
int x7=444; //Variables for drawing passenger
int x8=700;
int x18=33; // // //
int xI = 0, yI = 0; // variables for car
int x2=320 , y2=400; //variables for dropoff
int x3=500 , y3=650;
int x4=720 , y4=500;
int x6=800 , y6=100;
int x9=100 , y9=500;
int z=200, k=200;   // // //
int menux=500, menuy=500;
int menu=900;
int menucon=0;
int taxic=0;
int taxicolor=0;
int score;
void drawCaryellow() {
	DrawSquare(xI, yI, 10, colors[YELLOW]);
	DrawSquare(xI+10, yI+10, 10, colors[YELLOW]);
	DrawSquare(xI, yI+10, 10, colors[YELLOW]);
	DrawSquare(xI+10, yI, 10, colors[YELLOW]);
	DrawCircle(xI+4,yI,4,colors[BLACK]);
	DrawCircle(xI+15,yI,4,colors[BLACK]);
	glutPostRedisplay();
}
void drawCarred() {
	DrawSquare(xI, yI, 10, colors[RED]);
	DrawSquare(xI+10, yI+10, 10, colors[RED]);
	DrawSquare(xI, yI+10, 10, colors[RED]);
	DrawSquare(xI+10, yI, 10, colors[RED]);
	DrawCircle(xI+4,yI,4,colors[BLACK]);
	DrawCircle(xI+15,yI,4,colors[BLACK]);
	glutPostRedisplay();
}
void drawCar1() {
	DrawSquare(x2, y2, 10, colors[RED]);
	DrawSquare(x2+10, y2+10, 10, colors[RED]);
	DrawSquare(x2, y2+10, 10, colors[RED]);
	DrawSquare(x2+10, y2, 10, colors[RED]);
	DrawSquare(x2+20, y2, 10, colors[RED]);
	DrawCircle(x2+5,y2,4,colors[BLACK]);
	DrawCircle(x2+20,y2,4,colors[BLACK]);
	glutPostRedisplay();
}
void drawCar2() {
	DrawSquare(x3, y3, 10, colors[BLUE]);
	DrawSquare(x3+10, y3+10, 10, colors[BLUE]);
	DrawSquare(x3, y3+10, 10, colors[BLUE]);
	DrawSquare(x3+10, y3, 10, colors[BLUE]);
	DrawSquare(x3+20, y3, 10, colors[BLUE]);
	DrawCircle(x3+5,y3,4,colors[BLACK]);
	DrawCircle(x3+20,y3,4,colors[BLACK]);
	glutPostRedisplay();
}
void drawCar3() {
	DrawSquare(x4, y4, 10, colors[WHITE]);
	DrawSquare(x4+10, y4+10, 10, colors[WHITE]);
	DrawSquare(x4, y4+10, 10, colors[WHITE]);
	DrawSquare(x4+10, y4, 10, colors[WHITE]);
	DrawSquare(x4+20, y4, 10, colors[WHITE]);
	DrawCircle(x4+5,y4,4,colors[BLACK]);
	DrawCircle(x4+20,y4,4,colors[BLACK]);
	glutPostRedisplay();
}
void drawMan(){

	DrawCircle(x7,x7,7,colors[BLACK]);
	DrawLine( x7 , x7-25 ,  x7 , x7-5 , 6 , colors[BLACK] );
	DrawLine( x7 , x7-13 ,  x7-10 , x7-13 , 2 , colors[BLACK] );
	DrawLine( x7 , x7-13 ,  x7+10 , x7-3 , 2 , colors[BLACK] );
	DrawLine( x7-2 , x7-25 ,  x7-2 , x7-35 , 2 , colors[BLACK] );
	DrawLine( x7+2 , x7-25 ,  x7+2 , x7-35 , 2 , colors[BLACK] );
	glutPostRedisplay();
	}
void drawMan2(){
DrawCircle(x8,x8,7,colors[BLACK]);
	DrawLine( x8 , x8-25 ,  x8 , x8-5 , 6 , colors[BLACK] );
	DrawLine( x8 , x8-13 ,  x8-10 , x8-13 , 2 , colors[BLACK] );
	DrawLine( x8 , x8-13 ,  x8+10 , x8-3 , 2 , colors[BLACK] );
	DrawLine( x8-2 , x8-25 ,  x8-2 , x8-35 , 2 , colors[BLACK] );
	DrawLine( x8+2 , x8-25 ,  x8+2 , x8-35 , 2 , colors[BLACK] );
	glutPostRedisplay();
	}
void drawMan3(){
DrawCircle(x18,x18,7,colors[BLACK]);
	DrawLine( x18 , x18-25 ,  x18 , x18-5 , 6 , colors[BLACK] );
	DrawLine( x18 , x18-13 ,  x18-10 , x18-13 , 2 , colors[BLACK] );
	DrawLine( x18 , x18-13 ,  x18+10 , x18-3 , 2 , colors[BLACK] );
	DrawLine( x18-2 , x18-25 ,  x18-2 , x18-35 , 2 , colors[BLACK] );
	DrawLine( x18+2 , x18-25 ,  x18+2 , x18-35 , 2 , colors[BLACK] );
	glutPostRedisplay();
	}
void drawDrop1(){
	DrawCircle(x6,y6,20,colors[GREEN]);
}
void drawDrop2(){
	DrawCircle(x9,y9,20,colors[GREEN]);
}
void drawDrop3(){ //dropoff point function
	DrawCircle(z,k,20,colors[GREEN]);
}
bool flag = true;
void moveCar() {
	
	if (xI> 10 && flag) {
		xI -= 10;
		cout << "going left";
		if(xI < 100)
			
			flag = false;

	}
	else if (xI < 1010 && !flag) {
		cout << "go right";
		xI += 10;
		if (xI > 900)
			flag = false;
	}
}
bool flag2 = true;
void moveCar1() { //random vehicle functions
	
	if (x2 > 10 && flag2) {
		x2 -= 10;
		cout << "going left";
		if(x2 < 100)
			
			flag2 = false;

	}
	else if (x2 < 340 && !flag2) {
		cout << "go right";
		x2 += 10;
		if (x2 > 330)
			flag2 = true;
	}
	}
	
bool flag3 = true;
void moveCar2() {
	
	if (x3 > 250 && flag3) {
		x3 -= 10;
		cout << "going left";
		if(x3 < 260)
			
			flag3 = false;

	}
	else if (x3 < 700 && !flag3) {
		cout << "go right";
		x3 += 10;
		if (x3 > 670)
			flag3 = true;
	}
	}
	
	bool flag4 = true;
void moveCar3() {
	
	if (y4 > 300 && flag4) {
		y4 -= 10;
		cout << "going left";
		if(y4 < 310)
			
			flag4 = false;

	}
	else if (y4 < 650 && !flag4) {
		cout << "go right";
		y4 += 10;
		if (y4 > 640)
			flag4 = true;
	}
	}

/*
 * Main Canvas drawing function.
 * */

void GameDisplay()/**/{
	// set the background color using function glClearColor.
	// to change the background play with the red, green and blue values below.
	// Note that r, g and b values must be in the range [0,1] where 0 means dim rid and 1 means pure red and so on.

	glClearColor(0.0/*Red Component*/, 1,	//148.0/255/*Green Component*/,
			0.2/*Blue Component*/, 1 /*Alpha component*/); // Red==Green==Blue==1 --> White Colour
	glClear (GL_COLOR_BUFFER_BIT); //Update the colors
	//Red Square
	//DrawSquare(400, 20, 40, colors[RED]);
	
	//Green Square
	//DrawSquare( 250 , 250 ,20,colors[GREEN]); 
	
	//Display Score
	//DrawString( 50, 800, "Score=0", colors[MISTY_ROSE]);
	
	// Trianlge Vertices v1(300,50) , v2(500,50) , v3(400,250)
	//DrawTriangle( 300, 450 , 340, 450 , 320 , 490, colors[MISTY_ROSE] ); 
	


	//DrawLine(int x2, int y2, int x1, int y1, int lwidth, float *color)
	//DrawLine( 550 , 50 ,  550 , 480 , 10 , colors[MISTY_ROSE] );
	if(xI>970){
	xI-=10;
	}	
	if(yI>780){
	yI-=10;
	}
	if(xI<50){
	xI+=10;
	}
	if(yI<50){
	yI+=10;
	}
	
	if(menucon==0){ //for drawing menu
	DrawSquare(0, 0, 2000, colors[BLUE]);
	DrawString( 300, 400, "WELCOME TO RUSH HOUR By Hassan Abbas", colors[MISTY_ROSE]);
	DrawString( 300, 350, "Press 1 to choose taxi color", colors[MISTY_ROSE]);
	DrawString( 300, 300, "Press 2 to view leaderboard", colors[MISTY_ROSE]);
	}
	if(menucon==1){
	DrawSquare(0, 0, 2000, colors[WHITE]);
	DrawString( 300, 400, "Choose your taxi color", colors[BLACK]);
	DrawString( 300, 350, "Press 3 to choose yellow taxi", colors[YELLOW]);
	DrawString( 300, 300, "Press 4 to choose red taxi", colors[RED]);
	}
		if(menucon==2){
	DrawSquare(0, 0, 2000, colors[BROWN]);
	DrawString( 300, 400, "USER 1 :  SCORE 0", colors[BLACK]);
        DrawString( 300, 350, "USER 2 :  SCORE 0", colors[BLACK]);
        DrawString( 300, 300, "USER 3 :  SCORE 0", colors[BLACK]);
        DrawString( 300, 250, "USER 4 :  SCORE 0", colors[BLACK]);
        DrawString( 300, 200, "USER 5 :  SCORE 0", colors[BLACK]);
        DrawString( 300, 150, "USER 6 :  SCORE 0", colors[BLACK]);
        DrawString( 300, 100, "PRESS 1 TO CHOOSE TAXI COLOR", colors[BLACK]);
	}
		
	if(menucon==3){
	DrawString( 600, 815, "SCORE= ", colors[BLACK]);
	DrawString( 750, 815, Num2Str(score) , colors[RED]);                     //score string
	DrawString( 300, 815, "Press 1 to change taxi color", colors[BLACK]);
	DrawLine( 990 , 50 ,  50 , 50 , 10 , colors[MISTY_ROSE] );                    //borders
	DrawLine( 50 , 50 ,  50 , 800 , 10 , colors[MISTY_ROSE] );
        DrawLine( 50 , 800 ,  990 , 800 , 10 , colors[MISTY_ROSE] );
	DrawLine( 990 , 50 ,  990 , 800 , 10 , colors[MISTY_ROSE] );
for(int i=0;i<=990;i+=50){
DrawLine( i , 50 ,  i , 800 , 2 , colors[MISTY_ROSE] );
}
	

	DrawSquare(200, 700, 40, colors[RED]);
	DrawSquare(200, 660, 40, colors[RED]);           //building or walls
	DrawSquare(200, 620, 40, colors[RED]);
	DrawSquare(200, 580, 40, colors[RED]);
	
	DrawSquare(600, 400, 40, colors[RED]);
	DrawSquare(600, 360, 40, colors[RED]);
	DrawSquare(600, 320, 40, colors[RED]);
	DrawSquare(600, 280, 40, colors[RED]);
	DrawSquare(600,240, 40, colors[RED]);
	
	DrawSquare(640,240, 40, colors[RED]);
	DrawSquare(680,240, 40, colors[RED]);
	DrawSquare(720,240, 40, colors[RED]);
	DrawSquare(760,240, 40, colors[RED]);
	
	DrawSquare(300,440, 40, colors[RED]);
	DrawSquare(340,440, 40, colors[RED]);
	DrawSquare(380,440, 40, colors[RED]);
	DrawSquare(260,440, 40, colors[RED]);
	
	DrawSquare(600,740, 40, colors[RED]);
	DrawSquare(640,740, 40, colors[RED]);
	DrawSquare(680,740, 40, colors[RED]);
	DrawSquare(560,740, 40, colors[RED]);
	
	DrawSquare(260,340, 40, colors[RED]);
	DrawSquare(300,340, 40, colors[RED]);
	DrawSquare(340,340, 40, colors[RED]);
	DrawSquare(380,340, 40, colors[RED]);
	DrawSquare(420,340, 40, colors[RED]);
	
	DrawSquare(420,340, 40, colors[RED]);
	DrawSquare(420,300, 40, colors[RED]);
	DrawSquare(420,260, 40, colors[RED]);
	DrawSquare(420,220, 40, colors[RED]);
	
	DrawSquare(540,540, 40, colors[RED]);
	DrawSquare(580,540, 40, colors[RED]);
	DrawSquare(620,540, 40, colors[RED]);
	DrawSquare(500,540, 40, colors[RED]);
	
	DrawSquare(820,500, 40, colors[RED]);
	DrawSquare(820,460, 40, colors[RED]);
	DrawSquare(820,420, 40, colors[RED]);
	DrawSquare(820,380, 40, colors[RED]);
	
	DrawSquare(100,140, 40, colors[RED]);
	DrawSquare(100,180, 40, colors[RED]);
	DrawSquare(100,220, 40, colors[RED]);
	DrawSquare(100,100, 40, colors[RED]);
	
	DrawSquare(240,100, 40, colors[RED]);
	DrawSquare(280,100, 40, colors[RED]);
	DrawSquare(320,100, 40, colors[RED]);
	DrawSquare(360,100, 40, colors[RED]);
	
	DrawTriangle(300, 550 , 340, 550 , 320 , 590, colors[GREEN] ); 
        DrawLine( 320 , 550 ,  320 , 500 , 6 , colors[BLACK] );             //TREES
        DrawLine( 300 , 500 ,  340 , 500 , 2 , colors[BLACK] );
        
        DrawTriangle(300, 250 , 340, 250 , 320 , 290, colors[GREEN] ); 
        DrawLine( 320 , 250 ,  320 , 200 , 6 , colors[BLACK] );
        DrawLine( 300 , 200 ,  340 , 200 , 2 , colors[BLACK] );
        
        DrawTriangle(800, 650 , 840, 650 , 820 , 690, colors[GREEN] ); 
        DrawLine( 820 , 650 ,  820 , 600 , 6 , colors[BLACK] );
        DrawLine( 800 , 600 ,  840 , 600 , 2 , colors[BLACK] );
       
if(taxic==1){
taxicolor=1;          //condition for taxi color
}
if(taxic==2){
taxicolor=2;
}


      
//collision tree
 if(xI==290){
 if(yI>=490 && yI<=580){
 xI-=10;
 score-=2;                         // COLLISION CONDITIONS FOR TREES
 }
 }
  if(xI==330){
 if(yI>=490 && yI<=580){
 xI+=10;
  score-=2;
 }
 }
 if(yI==490){
 if(xI>=290 && xI<=330){
 yI-=10;
  score-=2;
 }
 }
  if(yI==580){
 if(xI>=290 && xI<=330){
 yI+=10;
  score-=2;
 }
 }  
 
 //collision tree 2
 if(xI==290){
 if(yI>=190 && yI<=280){
 xI-=10;
  score-=2;
 }
 }
  if(xI==330){
 if(yI>=190 && yI<=280){
 xI+=10;
  score-=2;
 }
 }
 if(yI==190){
 if(xI>=290 && xI<=330){
 yI-=10;
  score-=2;
 }
 }
  if(yI==280){
 if(xI>=290 && xI<=330){
 yI+=10;
  score-=2;
 }
 } 
 
 //collision tree 3
 if(xI==790){
 if(yI>=590 && yI<=680){
 xI-=10;
  score-=2;
 }
 }
  if(xI==830){
 if(yI>=590 && yI<=680){
 xI+=10;
  score-=2;
 }
 }
 if(yI==590){
 if(xI>=790 && xI<=830){
 yI-=10;
  score-=2;
 }
 }
  if(yI==680){
 if(xI>=790 && xI<=830){
 yI+=10;
  score-=2;
 }
 }   
        
        
        
        
//collision box
 if(xI==190){                        //COLLISION CONDITIONS FOR BUILDINGS OR WALLS
 if(yI>=570 && yI<=730){
 xI-=10;
  score-=2;
 }
 }                                                                          
  if(xI==230){
 if(yI>=570 && yI<=730){
 xI+=10;
  score-=2;
 }
 }
 if(yI==570){
 if(xI>=190 && xI<=230){
 yI-=10;
  score-=2;
 }
 }
  if(yI==730){
 if(xI>=190 && xI<=230){
 yI+=10;
  score-=2;
 }
 }
 //collision box 2
  if(xI==590){
 if(yI>=230 && yI<=430){
 xI-=10;
  score-=2;
 }
 }
  if(xI==630){
 if(yI>=230 && yI<=430){
 xI+=10;
  score-=2;
 }
 }
 if(yI==230){
 if(xI>=590 && xI<=630){
 yI-=10;
  score-=2;
 }
 }
  if(yI==430){
 if(xI>=590 && xI<=630){
 yI+=10;
  score-=2;
 }
 }
 //collision box 3
  if(xI==630){
 if(yI>=230 && yI<=260){
 xI-=10;
  score-=2;
 }
 }
  if(xI==790){
 if(yI>=230 && yI<=260){
 xI+=10;
  score-=2;
 }
 }
 if(yI==230){
 if(xI>=630 && xI<=790){
 yI-=10;
  score-=2;
 }
 }
  if(yI==270){
 if(xI>=630 && xI<=790){
 yI+=10;
  score-=2;
 }
 }
 //collision box 4
  if(xI==410){
 if(yI>=430 && yI<=470){
 xI+=10;
  score-=2;
 }
 }
  if(xI==250){
 if(yI>=430 && yI<=470){
 xI-=10;
  score-=2;
 }
 }
 if(yI==430){
 if(xI>=250 && xI<=410){
 yI-=10;
  score-=2;
 }
 }
  if(yI==470){
 if(xI>=250 && xI<=410){
 yI+=10;
  score-=2;
 }
 }
 //collision box 5
  if(xI==550){
 if(yI>=730 && yI<=770){
 xI-=10;
  score-=2;
 }
 }
  if(xI==710){
 if(yI>=730 && yI<=770){
 xI+=10;
  score-=2;
 }
 }
 if(yI==730){
 if(xI>=550 && xI<=710){
 yI-=10;
  score-=2;
 }
 }
  if(yI==770){
 if(xI>=550 && xI<=710){
 yI+=10;
  score-=2;
 }
 }
 //collision box 6
  if(xI==250){
 if(yI>=330 && yI<=370){
 xI-=10;
  score-=2;
 }
 }
  if(xI==450){
 if(yI>=330 && yI<=370){
 xI+=10;
  score-=2;
 }
 }
 if(yI==330){
 if(xI>=250 && xI<=450){
 yI-=10;
  score-=2;
 }
 }
  if(yI==370){
 if(xI>=250 && xI<=450){
 yI+=10;
  score-=2;
 }
 }
 //collision box 7
  if(xI==410){
 if(yI>=210 && yI<=370){
 xI-=10;
  score-=2;
 }
 }
  if(xI==450){
 if(yI>=210 && yI<=370){
 xI+=10;
  score-=2;
 }
 }
 if(yI==210){
 if(xI>=410 && xI<=450){
 yI-=10;
  score-=2;
 }
 }
  if(yI==370){
 if(xI>=410 && xI<=450){
 yI+=10;
  score-=2;
 }
 }
 //collision box 8
  if(xI==810){
 if(yI>=370 && yI<=530){
 xI-=10;
  score-=2;
 }
 }
  if(xI==850){
 if(yI>=370 && yI<=530){
 xI+=10;
  score-=2;
 }
 }
 if(yI==370){
 if(xI>=810 && xI<=850){
 yI-=10;
  score-=2;
 }
 }
  if(yI==530){
 if(xI>=810 && xI<=850){
 yI+=10;
  score-=2;
 }
 }
 //collision box 9
  if(xI==90){
 if(yI>=90 && yI<=250){
 xI-=10;
  score-=2;
 }
 }
  if(xI==130){
 if(yI>=90 && yI<=250){
 xI+=10;
  score-=2;
 }
 }
 if(yI==90){
 if(xI>=90 && xI<=130){
 yI-=10;
  score-=2;
 }
 }
  if(yI==250){
 if(xI>=90 && xI<=130){
 yI+=10;
  score-=2;
 }
 }
 //collision box 10
  if(xI==230){
 if(yI>=90 && yI<=130){
 xI-=10;
  score-=2;
 }
 }
  if(xI==390){
 if(yI>=90 && yI<=130){
 xI+=10;
  score-=2;
 }
 }
 if(yI==90){
 if(xI>=230 && xI<=390){
 yI-=10;
  score-=2;
 }
 }
  if(yI==130){
 if(xI>=230 && xI<=390){
 yI+=10;
  score-=2;
 }
 }
 //collision box 11
   if(xI==490){
 if(yI>=530 && yI<=570){
 xI-=10;
  score-=2;
 }
 }
  if(xI==650){
 if(yI>=530 && yI<=570){
 xI+=10;
  score-=2;
 }
 }
 if(yI==530){
 if(xI>=490 && xI<=650){
 yI-=10;
  score-=2;
 }
 }
  if(yI==570){
 if(xI>=490 && xI<=650){
 yI+=10;
  score-=2;
 }
 }
 if(xI==444&&yI==444){
   score-=5;
   }

 if(x7==2444){
 drawDrop1();
 }
 if(x6==2800){
 drawMan2();
 }
 if(x8==2700){
 drawDrop2();
 }
 if(x9==2100&&y9==2500){
 drawMan3();
 }
 if(x18==10972){
 drawDrop3();
 }
 
 


	/* DrawCircle(50,670,10,colors[RED]);
	DrawCircle(70,670,10,colors[RED]);
	DrawCircle(90,670,10,colors[RED]);
	DrawRoundRect(500,200,50,100,colors[DARK_SEA_GREEN],70);
	DrawRoundRect(100,200,100,50,colors[DARK_OLIVE_GREEN],20);	
	DrawRoundRect(100,100,50,100,colors[DARK_OLIVE_GREEN],30);
	DrawRoundRect(200,100,100,50,colors[LIME_GREEN],40);
	DrawRoundRect(350,100,100,50,colors[LIME_GREEN],20);
	*/
	if(taxicolor==1){        //yellow taxi
	drawCaryellow();
	}
	if(taxicolor==2){
	drawCarred();          //red taxi
	}
	drawCar1();  //random cars
	drawCar2();
	drawCar3();
	drawMan(); //passenger 1
	}
	glutSwapBuffers(); // do not modify this line..



/*This function is called (automatically) whenever any non-printable key (such as up-arrow, down-arraw)
 * is pressed from the keyboard
 *
 * You will have to add the necessary code here when the arrow keys are pressed or any other key is pressed...
 *
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 *
 * */
}
void NonPrintableKeys(int key, int x, int y) {
	if (key
			== GLUT_KEY_LEFT /*GLUT_KEY_LEFT is constant and contains ASCII for left arrow key*/) {
		// what to do when left key is pressed...
		xI -= 10;

	} else if (key
			== GLUT_KEY_RIGHT /*GLUT_KEY_RIGHT is constant and contains ASCII for right arrow key*/) {
		xI += 10;
	} else if (key
			== GLUT_KEY_UP/*GLUT_KEY_UP is constant and contains ASCII for up arrow key*/) {
		yI += 10;
	}

	else if (key
			== GLUT_KEY_DOWN/*GLUT_KEY_DOWN is constant and contains ASCII for down arrow key*/) {
		yI -= 10;
	}

	/* This function calls the Display function to redo the drawing. Whenever you need to redraw just call
	 * this function*/

	glutPostRedisplay();

}

/*This function is called (automatically) whenever any printable key (such as x,b, enter, etc.)
 * is pressed from the keyboard
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 * */
void PrintableKeys(unsigned char key, int x, int y) {
	if (key == 27/* Escape key ASCII*/) {
		exit(1); // exit the program when escape key is pressed.
	}

	if (key == 'b' || key == 'B') //Key for placing the bomb
			{
		//do something if b is pressed
		cout << "b pressed" << endl;

	}
	if(key==49){
	menucon=1;          // 49 is 1 and so on
	}
	if(key==50){
	menucon=2;
	}
	if(key==51){
	taxic=1;
	menucon=3;
	}
	if(key==52){
	taxic=2;
	menucon=3;
	}
	
	if(xI>=430&&xI<=460||yI>=430&&yI<=460){
	if(key==32){
	x7+=2000;
	}
	}
	if(xI>=780&&xI<=820||yI>=80&&yI<=120){
	if(key==32){         //32 is space
	score+=10;
	x6+=2000;
	y6+=2000;
	}
	}
	
	
	if(xI>=680&&xI<=720||yI>=680&&yI<=720){
	if(key==32){
	x8+=2000;
	}
	}
	if(xI>=180&&xI<=220||yI>=480&&yI<=520){
	if(key==32){
	score+=10;
	x9+=2000;
	y9+=2000;
	
	}
	}

	if(xI>=320&&xI<=340||yI>=320&&yI<=340){
	if(key==32){
	x18=10972;
	}
	}
	if(xI>=180&&xI<=220||yI>=180&&yI<=220){
	if(key==32){

	z+=1350;
	k+=1350;
	}
	}
		glutPostRedisplay();
}



/*
 * This function is called after every 1000.0/FPS milliseconds
 * (FPS is defined on in the beginning).
 * You can use this function to animate objects and control the
 * speed of different moving objects by varying the constant FPS.
 *
 * */
void Timer(int m) {

	// implement your//moveCar();
	moveCar1();
	moveCar2();
moveCar3();
	// once again we tell the library to call our Timer function after next 1000/FPS
	glutTimerFunc(100, Timer, 0);
}

/*This function is called (automatically) whenever your mouse moves witin inside the game window
 *
 * You will have to add the necessary code here for finding the direction of shooting
 *
 * This function has two arguments: x & y that tells the coordinate of current position of move mouse
 *
 * */
void MousePressedAndMoved(int x, int y) {
	cout << x << " " << y << endl;
	glutPostRedisplay();
}
void MouseMoved(int x, int y) {
	//cout << x << " " << y << endl;
	glutPostRedisplay();
}

/*This function is called (automatically) whenever your mouse button is clicked witin inside the game window
 *
 * You will have to add the necessary code here for shooting, etc.
 *
 * This function has four arguments: button (Left, Middle or Right), state (button is pressed or released),
 * x & y that tells the coordinate of current position of move mouse
 *
 * */
void MouseClicked(int button, int state, int x, int y) {

	if (button == GLUT_LEFT_BUTTON) // dealing only with left button
			{
		cout << GLUT_DOWN << " " << GLUT_UP << endl;

	} else if (button == GLUT_RIGHT_BUTTON) // dealing with right button
			{
			cout<<"Right Button Pressed"<<endl;

	}
	glutPostRedisplay();
}
/*
 * our gateway main function
 * */
int main(int argc, char*argv[]) {
string strvark;
cout<<"Enter your name: ";
cin>>strvark;
	int width = 1020, height = 840; // i have set my window size to be 800 x 600
	InitRandomizer(); // seed the random number generator...
	glutInit(&argc, argv); // initialize the graphics library...
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // we will be using color display mode
	glutInitWindowPosition(50, 50); // set the initial position of our window
	glutInitWindowSize(width, height); // set the size of our window
	glutCreateWindow("Rush Hour by Hassan Abbas"); // set the title of our game window
	SetCanvasSize(width, height); // set the number of pixels...

	// Register your functions to the library,
	// you are telling the library names of function to call for different tasks.
	//glutDisplayFunc(display); // tell library which function to call for drawing Canvas.

	glutDisplayFunc(GameDisplay); // tell library which function to call for drawing Canvas.
	glutSpecialFunc(NonPrintableKeys); // tell library which function to call for non-printable ASCII characters
	glutKeyboardFunc(PrintableKeys); // tell library which function to call for printable ASCII characters
	// This function tells the library to call our Timer function after 1000.0/FPS milliseconds...
	glutTimerFunc(1000.0, Timer, 0);

	glutMouseFunc(MouseClicked);
	glutPassiveMotionFunc(MouseMoved); // Mouse
	glutMotionFunc(MousePressedAndMoved); // Mouse

	// now handle the control to library and it will call our registered functions when
	// it deems necessary...
	glutMainLoop();
	return 1;
}
#endif /* RushHour_CPP_ */
