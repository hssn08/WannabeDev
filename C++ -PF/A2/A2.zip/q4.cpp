#include<iostream>
#include<iomanip>
using namespace std;
float xtime(float,float);
float ytime(float,float);
float zdistance(float,float);
int main(){
float X,Y,x_speed,y_speed,z_speed,z_minutes;
cout<<"Enter x distance(km): \t";
cin>>X;
cout<<endl;

cout<<"Enter x speed(ms): \t";
cin>>x_speed;
cout<<endl;

cout<<"Enter y distance(km): \t";
cin>>Y;
cout<<endl;

cout<<"Enter y speed(kmh): \t";
cin>>y_speed;
cout<<endl;

cout<<"Enter z time(minutes): \t";
cin>>z_minutes;
cout<<endl;

cout<<"Enter z speed(kmh): \t";
cin>>z_speed;
cout<<endl;

z_minutes*=60;
X*=1000;
Y*=1000;
y_speed/=3.6;
z_speed/=3.6;
xtime(X,x_speed);

ytime(Y,y_speed);

zdistance(z_minutes,z_speed);

float totaltime,totaldistance;

totaltime=(xtime(X,x_speed)+ytime(Y,y_speed)+z_minutes)/3600;

totaldistance=(X+Y+zdistance(z_minutes,z_speed))/1000;

cout<<"the average speed is= "<<"\t"<<totaldistance/totaltime;
return 0;
}
float xtime(float a,float b){
float x_time=a/b;
return x_time;
}
float ytime(float c,float d){
float y_time=c/d;
return y_time;
}
float zdistance(float e,float f){
float z_distance=e*f;
return z_distance;
}


