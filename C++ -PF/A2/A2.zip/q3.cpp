#include<iostream>
#include<cmath>
#include<iomanip>
using namespace std;
float lhs(float);
float rhs(float);
float difference(float,float);
float series(float);
int main(){
int x;
cout<<"Enter angle (90,60,30): ";
cin>> x;
float j=x*0.0174533;
lhs(j);
rhs(j);
cout<< "LHS is: "<<setprecision(8)<<fixed<< lhs(j)<< endl;
cout<< "RHS is: "<<setprecision(8)<<fixed<< rhs(j)<< endl;
float l=lhs(j);
float r=rhs(j);
difference(l,r);
cout<< "difference is: "<<setprecision(8)<<fixed<<difference(l,r)<< endl;
series(j);
return 0;
}
float lhs(float y){
float a=sin(y);
return a;
}
float rhs(float z){
float b = z-((z*z*z)/(3*2*1))+((z*z*z*z*z)/(5*4*3*2*1))-((z*z*z*z*z*z*z)/(7*6*5*4*3*2*1))+((z*z*z*z*z*z*z*z*z)/(9*8*7*6*5*4*3*2*1));
return b;
}
float difference(float e, float f){
float c=(f-e);
return c;
}
float series(float i){
float p,o,g,s,h;
p=i;
cout<< "First term is :"<<setprecision(8)<<fixed<<fixed<< p<<endl;
o=i-((i*i*i)/(3*2*1));
cout<< "Series of two terms is :"<<setprecision(8)<<fixed<< o<<endl;
g=i-((i*i*i)/(3*2*1))-((i*i*i*i*i)/(5*4*3*2*1));
cout<< "Series of three terms is :"<<setprecision(8)<<fixed<<g<<endl;
s=i-((i*i*i)/(3*2*1))+((i*i*i*i*i)/(5*4*3*2*1))-((i*i*i*i*i*i*i)/(7*6*5*4*3*2*1));
cout<< "Series of four terms is :"<<setprecision(8)<<fixed<< s<<endl;
h=i-((i*i*i)/(3*2*1))+((i*i*i*i*i)/(5*4*3*2*1))-((i*i*i*i*i*i*i)/(7*6*5*4*3*2*1))+((i*i*i*i*i*i*i*i*i)/((9*8*7*6*5*4*3*2*1)));
cout<< "Series of five terms is :"<<setprecision(8)<<fixed<< h<<endl;
return 0;
}




