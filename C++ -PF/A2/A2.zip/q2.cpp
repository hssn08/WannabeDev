#include<iostream>
#include<iomanip>
using namespace std;
float length(float, float);
int main(){
float a=72,b=54,X,V;
V=(a+b)/3.6;
//kmh metre per second
cout<<"enter seconds: "<<"\n";
cin>> X;
cout<<"The length of train is: "<< length(X,V)<<" metres\n";
return 0;
}
float length(float S,float T){
float L;
L=T*S;
return L;
}


