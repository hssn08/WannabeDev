#include<iostream>
#include<iomanip>
using namespace std;
float rpm(float D, float V);
int main(){
float D,V;
cout<< "enter diameter: "<<endl;
cin>> D;
cout<< "enter speed: "<<endl;
cin>> V;
cout<< "rpm is: "<< rpm(D,V)<<"\n";
return 0;
}
float rpm(float D, float V){
float revpm, pi=3.142;
V/=0.06;
revpm=V/(pi*2*(D/2));
//revolutions per minute = meters per minute / circumference 
return revpm;
}



