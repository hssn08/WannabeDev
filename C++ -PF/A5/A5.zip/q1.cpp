#include<iostream>
using namespace std;
int penalty(int, int);
int main(){
int y=50,x;
double dueamount[y];
double paidamount[y];
int paidday[y];
int paidmonth[y];
int paidyear[y];
int dueday[y];
int duemonth[y];
int dueyear[y];
int overdays[y];
double penalty[y];
int balance[y];
	char ch='Y';
	while(ch=='Y'){
cout<<"Enter Due Amount: ";
cin>>dueamount[x];
cout<<"Enter Due Date(DD/MM/YY): ";
cin>>dueday[x];
cin>>duemonth[x];
cin>>dueyear[x];
cout<<"Enter Paid Amount: ";
cin>>paidamount[x];
cout<<"Enter Paid Date(DD/MM/YY): ";
cin>>paidday[x];
cin>>paidmonth[x];
cin>>paidyear[x];
cout<<"Do you want to continue?(Y/N): ";
cin>>ch;
x++;
	}
	for(int i=0;i<=x;i++){
		if (paidyear[i]<dueyear[i]){
		if (paidmonth[i]<duemonth[i]){
			if (paidday[i]<dueday[i]){
				overdays[i]=0;
			}
			else{
				overdays[i]=paidday[i]-dueday[i];
		}
	}	
	else{
			overdays[i]+=30+paidday[i]-dueday[i];
		}
	}
	penalty[i]=overdays[i]*100;
	balance[i]=dueamount[i]-paidamount[i];
	double percentage=dueamount[i]*0.05;
	if(paidamount[i]<dueamount[i]){
		penalty[i]+=percentage;
	}
}
	cout<<"SNO\tDueamount\tDueDate\t\tPaidamount\tPaiddate\tNo of Days\tPenalty\tBalance\t"<<endl;
for(int i=0;i<x;i++){
	cout<<i+1<<"\t"<<dueamount[i]<<"\t\t"<<dueday[i]<<"\\"<<duemonth[i]<<"\\"<<dueyear[i]<<"\t\t"<<paidamount[i]<<"\t\t"<<paidday[i]<<"\\"<<paidmonth[i]<<"\\"<<paidyear[i]<<"\t\t"<<overdays[i]<<"\t"<<penalty[i]<<"\t"<<balance[i]<<endl;
}
return 0;
}


