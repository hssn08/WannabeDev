#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
int Var_1,Var_2,Var_3;
cout<<"Enter values of 1st variable: ";
cin>> Var_1;
cout<<"Enter values of 2nd variable: ";
cin>> Var_2;
cout<<"Enter values of 3st variable: ";
cin>> Var_3;
cout<<setw(9)<<"Variables"<<setw(12)<<"Numbers"<<setw(11)<<"Square"<<setw(9)<<"Cube"<<setw(9)<<"Half"<<"\n";
cout<<setw(5)<<"Var_1";
cout<<setw(10)<< Var_1;
cout<<setw(12)<< Var_1*Var_1;
cout<<setw(11)<< Var_1*Var_1*Var_1;
cout<<setw(9)<<setprecision(0)<<Var_1*0.5<<"\n";
cout<<setw(5)<<"Var_2";
cout<<setw(10)<< Var_2;
cout<<setw(13)<< Var_2*Var_2;
cout<<setw(12)<<right<< Var_2*Var_2*Var_2;
cout<<setw(7)<<setprecision(0)<< Var_2*0.5<<"\n";
cout<<setw(5)<<"Var_3";
cout<<setw(10)<< Var_3;
cout<<setw(12)<< Var_3*Var_3;
cout<<setw(12)<<setprecision(0)<< Var_3*Var_3*Var_3;
cout<<setw(8)<< Var_3*0.5<<"\n";
return 0;
}
