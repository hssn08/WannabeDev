#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
char a;
cout<<"enter a character: ";
cin>> a;
cout<<"\n";
cout<< a<< a<< a<< a<< a<< a<< a<< a<< a<< a<<"\n";
cout<<setw(1)<< a<< setw(8)<< a<<"\n";
cout<<setw(2)<< a<< setw(6)<< a<<"\n";
cout<<setw(4)<< a<< setw(1)<< a<<"\n";
cout<<setw(2)<< a<< setw(6)<< a<<"\n";
cout<<setw(1)<< a<< setw(8)<< a<<"\n";
cout<< a<< a<< a<< a<< a<< a<< a<< a<< a<< a<<"\n";
cout<<"\n";
cout<< a<< a<< a<< a<< a<< a<< a<< a<< a<< a<< a<< a<< a<< a<< a<< a<< a<< a<<"\n";
cout<< a<< a<<setw(14)<< a<< a<<"\n";
cout<< a<< a<< a<<setw(12)<< a<< a<< a<<"\n";
cout<< a<< a<< a<< a<<setw(10)<< a<< a<< a<< a<<"\n";
cout<< a<< a<< a<< a<< a<<setw(8)<< a<< a<< a<< a<< a<<"\n";
cout<< a<<  a<< a<< a<< a<<a<<setw(6)<< a<< a<< a<< a<< a<< a<<"\n";
cout<< a<< a<< a<< a<< a<< a<< a<<setw(4)<< a<< a<< a<< a<< a<< a<< a<<"\n";
cout<< a<< a<< a<< a<< a<< a<< a<< a<<setw(2)<< a<< a<< a<< a<< a<< a<< a<< a<<"\n";
cout<<"\n";
cout<<setw(5)<< a<<"\n";
cout<<setw(5)<< a<< a<<"\n";
cout<<setw(4)<< a<< a<< a<< a<<"\n";
cout<<setw(3)<< a<< a<< a<< a<< a<< a<<"\n";
cout<<setw(1)<< a<< a<< a<< a<< a<< a<< a<< a<< a<< a<<"\n";
cout<<setw(3)<< a<< a<< a<< a<< a<< a<<"\n";
cout<<setw(4)<< a<< a<< a<< a<<"\n";
cout<<setw(5)<< a<< a<<"\n";
cout<<setw(5)<< a<<"\n";
return 0;
}
