#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
cout<<"(a)\n";
float x=34.789;
cout<<setw(9)<<setprecision(2)<<fixed<< x<<"\n";
cout<<"(b)\n";
float y=7.0;
cout<<setw(5)<<setprecision(3)<<showpoint<<fixed<< y<<"\n";
cout<<"(c)\n";
unsigned long z=5.789e+12;
cout<<fixed<< z<<"\n";
cout<<"(d)\n";
int k=67;
cout<<setw(7)<<left<< k<<"\n";
return 0;
}
