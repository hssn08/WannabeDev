#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
float a,b,c;
cout<<"Enter the sales for day 1: ";
cin>> a;
cout<<"Enter the sales for day 2: ";
cin>> b;
cout<<"Enter the sales for day 3: ";
cin>> c;
cout<<"\n";
cout<<"Sales Figures \n-------------\n";
cout<<"Day 1: "<< a<<"\n";
cout<<"Day 2: "<< b<<"\n";
cout<<"Day 3: "<< c<<"\n";
cout<<"Total: "<< a+b+c<<"\n";
return 0;
}


