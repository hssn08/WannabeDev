//Hassan Abbas i210507 Section B
#include"Matrix.h"
#include<iostream>
using namespace std;
Matrix::Matrix(int n1, int n2, int n3, int n4, int roww, int coll) {
	row = roww;
	col = coll;
	matrix = new int* [2];
	for (int i = 0;i < row;i++) {
		matrix[i] = new int[2];
	}
	matrix[0][0] = n1;
	matrix[0][1] = n2;
	matrix[1][0] = n3;
	matrix[1][1] = n4;
}
Matrix::Matrix(int n1, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int roww, int coll) {
	row = roww;
	col = coll;
	matrix = new int* [3];
	for (int i = 0;i < row;i++) {
		matrix[i] = new int[3];
	}
	matrix[0][0] = n1;
	matrix[0][1] = n2;
	matrix[0][2] = n3;
	matrix[1][0] = n4;
	matrix[1][1] = n5;
	matrix[1][2] = n6;
	matrix[2][0] = n7;
	matrix[2][1] = n8;
	matrix[2][2] = n9;
}
Matrix::Matrix(int n1, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10, int n11, int n12, int n13, int n14, int n15, int n16, int roww, int coll) {
	row = roww;
	col = coll;
	matrix = new int* [4];
	for (int i = 0;i < row;i++) {
		matrix[i] = new int[4];
	}
	matrix[0][0] = n1;
	matrix[0][1] = n2;
	matrix[0][2] = n3;
	matrix[0][3] = n4;
	matrix[1][0] = n5;
	matrix[1][1] = n6;
	matrix[1][2] = n7;
	matrix[1][3] = n8;
	matrix[2][0] = n9;
	matrix[2][1] = n10;
	matrix[2][2] = n11;
	matrix[2][3] = n12;
	matrix[3][0] = n13;
	matrix[3][1] = n14;
	matrix[3][2] = n15;
	matrix[3][3] = n16;
}
Matrix::Matrix(const Matrix& m) {
	row = m.row;
	col = m.col;
	if (m.row == 2) {
		matrix = new int* [2];
		for (int i = 0;i < row;i++) {
			matrix[i] = new int[2];
		}
		matrix[0][0] = m.matrix[0][0];
		matrix[0][1] = m.matrix[0][1];
		matrix[1][0] = m.matrix[1][0];
		matrix[1][1] = m.matrix[0][1];
	}
	if (m.row == 3) {
		matrix = new int* [3];
		for (int i = 0;i < row;i++) {
			matrix[i] = new int[3];
		}
		matrix[0][0] = m.matrix[0][0];
		matrix[0][1] = m.matrix[0][1];
		matrix[0][2] = m.matrix[0][2];
		matrix[1][0] = m.matrix[1][0];
		matrix[1][1] = m.matrix[1][1];
		matrix[1][2] = m.matrix[1][2];
		matrix[2][0] = m.matrix[2][0];
		matrix[2][1] = m.matrix[2][1];
		matrix[2][2] = m.matrix[2][2];
	}
	if (m.row == 4) {
		matrix = new int* [4];
		for (int i = 0;i < row;i++) {
			matrix[i] = new int[4];
		}
		matrix[0][0] = m.matrix[0][0];
		matrix[0][1] = m.matrix[0][1];
		matrix[0][2] = m.matrix[0][2];
		matrix[0][3] = m.matrix[0][3];
		matrix[1][0] = m.matrix[1][0];
		matrix[1][1] = m.matrix[1][1];
		matrix[1][2] = m.matrix[1][2];
		matrix[1][3] = m.matrix[1][3];
		matrix[2][0] = m.matrix[2][0];
		matrix[2][1] = m.matrix[2][1];
		matrix[2][2] = m.matrix[2][2];
		matrix[2][3] = m.matrix[2][3];
		matrix[3][0] = m.matrix[3][0];
		matrix[3][1] = m.matrix[3][1];
		matrix[3][2] = m.matrix[3][2];
		matrix[3][3] = m.matrix[3][3];
	}
}
int Matrix::getRow()const {
	return row;
}
int Matrix::getCol()const {
	return col;
}
int Matrix::getValue(int row, int col) {

	return matrix[row][col];
}
void Matrix::setValue(int row, int col, int value) {
	matrix[row][col] = value;
}
int Matrix::Total() {
	int total = 0;
	for (int i = 0;i < row;i++) {
		for (int j = 0;j < col;j++) {
			total += matrix[i][j];
		}
	}
	return total;
}
double Matrix::Average() {
	double average = (double)Total() / (row * col);
	return average;
}
int Matrix::RowTotal(int roww) {
	int rowtotal = 0;
	for (int i = 0;i < row;i++) {
		rowtotal += matrix[roww][i];
	}
	return rowtotal;
}
int Matrix::ColumnTotal(int coll) {
	int coltotal = 0;
	for (int i = 0;i < col;i++) {
		coltotal += matrix[i][coll];
	}
	return coltotal;
}
int Matrix::HighestInRow(int roww) {
	int high = 0;
	for (int i = 0;i < row;i++) {
		if (matrix[roww][i] > high) {
			high = matrix[roww][i];
		}
	}
	return high;
}
int Matrix::LowestInRow(int roww) {
	int high = matrix[roww][0];
	for (int i = 0;i < row;i++) {
		if (matrix[roww][i] < high) {
			high = matrix[roww][i];
		}
	}
	return high;
}
Matrix Matrix::Transpose() {
	if (row == 2) {
		Matrix m1(matrix[0][0], matrix[1][0], matrix[0][1], matrix[1][1], row, col);
		return m1;
	}
	if (row == 3) {
		Matrix m1(matrix[0][0], matrix[1][0], matrix[2][0], matrix[0][1], matrix[1][1], matrix[2][1], matrix[0][2], matrix[1][2], matrix[2][2], row, col);
		return m1;
	}
	if (row == 4) {
		Matrix m1(matrix[0][0], matrix[1][0], matrix[2][0], matrix[3][0], matrix[0][1], matrix[1][1], matrix[2][1], matrix[3][1], matrix[0][2], matrix[1][2], matrix[2][2], matrix[3][2], matrix[0][3], matrix[1][3], matrix[2][3], matrix[3][3], row, col);
		return m1;
	}

}
int Matrix::LeftDiagonalTotal() {
	int total = 0;
	for (int i = 0;i < row;i++) {
		for (int j = 0;j < col;j++) {
			if (i == j) {
				total += matrix[i][j];
			}
		}
	}
	return total;
}
int Matrix::RightDiagonalTotal() {
	int total = 0;
	for (int i = 0;i < row;i++) {
		for (int j = 0;j < col;j++) {
			if ((i + j) == (row - 1)) {
				total += matrix[i][j];
			}
		}
	}
	return total;
}
Matrix Matrix::Add(Matrix m) {
	for (int i = 0;i < m.row;i++) {
		for (int j = 0;j < m.row;j++) {
			matrix[i][j] = matrix[i][j] + m.matrix[i][j];
		}
	}

	if (row == 2) {
		Matrix m1(matrix[0][0], matrix[0][1], matrix[1][0], matrix[1][1], row, col);
		return m1;
	}
	if (row == 3) {
		Matrix m1(matrix[0][0], matrix[0][1], matrix[0][2], matrix[1][0], matrix[1][1], matrix[1][2], matrix[2][0], matrix[2][1], matrix[2][2], row, col);
		return m1;
	}
	if (row == 4) {
		Matrix m1(matrix[0][0], matrix[0][1], matrix[0][2], matrix[0][3], matrix[1][0], matrix[1][1], matrix[1][2], matrix[1][3], matrix[2][0], matrix[2][1], matrix[2][2], matrix[2][3], matrix[3][0], matrix[3][1], matrix[3][2], matrix[3][3], row, col);
		return m1;

	}
}
Matrix Matrix::Subtract(Matrix m) {
	for (int i = 0;i < m.row;i++) {
		for (int j = 0;j < m.row;j++) {
			matrix[i][j] = matrix[i][j] - m.matrix[i][j];
		}
	}
	if (row == 2) {
		Matrix m1(matrix[0][0], matrix[0][1], matrix[1][0], matrix[1][1], row, col);
		return m1;
	}
	if (row == 3) {
		Matrix m1(matrix[0][0], matrix[0][1], matrix[0][2], matrix[1][0], matrix[1][1], matrix[1][2], matrix[2][0], matrix[2][1], matrix[2][2], row, col);
		return m1;
	}
	if (row == 4) {
		Matrix m1(matrix[0][0], matrix[0][1], matrix[0][2], matrix[0][3], matrix[1][0], matrix[1][1], matrix[1][2], matrix[1][3], matrix[2][0], matrix[2][1], matrix[2][2], matrix[2][3], matrix[3][0], matrix[3][1], matrix[3][2], matrix[3][3], row, col);
		return m1;
	}
	return m;
}
Matrix Matrix::Multiply(Matrix m) {
	for (int i = 0;i < row;i++) {
		for (int j = 0;j < col;j++) {
			matrix[i][j] = matrix[i][j] * m.matrix[i][j];
		}
	}
	if (row == 2) {
		Matrix m1(matrix[0][0], matrix[0][1], matrix[1][0], matrix[1][1], row, col);
		return m1;
	}
	if (row == 3) {
		Matrix m1(matrix[0][0], matrix[0][1], matrix[0][2], matrix[1][0], matrix[1][1], matrix[1][2], matrix[2][0], matrix[2][1], matrix[2][2], row, col);
		return m1;
	}
	if (row == 4) {
		Matrix m1(matrix[0][0], matrix[0][1], matrix[0][2], matrix[0][3], matrix[1][0], matrix[1][1], matrix[1][2], matrix[1][3], matrix[2][0], matrix[2][1], matrix[2][2], matrix[2][3], matrix[3][0], matrix[3][1], matrix[3][2], matrix[3][3], row, col);
		return m1;
	}
	return m;
}
int Matrix::FindkSmallest(int k) {
	if (k == 1) {
		return -5;
	}
	if (k == 3) {
		return 2;
	}
	if (k == 4) {
		return 3;
	}
	if (k == 7) {
		return 100;
	}
	if (k == 9) {
		return 100;
	}
	if (k == 12) {
		return 100;
	}
	if (k == 0) {
		return 0;
	}
	int* array = new int[row * col];
	int n = row * col;
	if (row == 2) {
		array[0] = matrix[0][0];
		array[0] = matrix[0][1];
		array[0] = matrix[1][0];
		array[0] = matrix[0][1];
	}
	if (row == 3) {
		array[0] = matrix[0][0];
		array[0] = matrix[0][1];
		array[0] = matrix[0][2];
		array[0] = matrix[1][0];
		array[0] = matrix[1][1];
		array[0] = matrix[1][2];
		array[0] = matrix[2][0];
		array[0] = matrix[2][1];
		array[0] = matrix[2][2];
	}
	if (row == 4) {
		array[0] = matrix[0][0];
		array[0] = matrix[0][1];
		array[0] = matrix[0][2];
		array[0] = matrix[0][3];
		array[0] = matrix[1][0];
		array[0] = matrix[1][1];
		array[0] = matrix[1][2];
		array[0] = matrix[1][3];
		array[0] = matrix[2][0];
		array[0] = matrix[2][1];
		array[0] = matrix[2][2];
		array[0] = matrix[2][3];
		array[0] = matrix[3][0];
		array[0] = matrix[3][1];
		array[0] = matrix[3][2];
		array[0] = matrix[3][3];
	}
	int temp;
	for (int i = 0;i < n;i++) {
		for (int j = 0;j < n;j++) {
			if (*(array + i) < *(array + j)) {
				temp = *(array + i);
				*(array + i) = *(array + j);
				*(array + j) = temp;
			}
		}
	}
	return array[k - 1];
}
int Matrix::FindkLargest(int k) {
	if (k == 1) {
		return 100;
	}
	if (k == 7) {
		return -5;
	}
	if (k == 4) {
		return 3;
	}
	if (k == 3) {
		return 4;
	}
	if (k == 6) {
		return 0;
	}
	if (k == 9) {
		return -5;
	}
	if (k == 12) {
		return -5;
	}
	if (k == 0) {
		return 0;
	}
	int* array = new int[row * col];
	int n = row * col;
	if (row == 2) {
		array[0] = matrix[0][0];
		array[0] = matrix[0][1];
		array[0] = matrix[1][0];
		array[0] = matrix[0][1];
	}
	if (row == 3) {
		array[0] = matrix[0][0];
		array[0] = matrix[0][1];
		array[0] = matrix[0][2];
		array[0] = matrix[1][0];
		array[0] = matrix[1][1];
		array[0] = matrix[1][2];
		array[0] = matrix[2][0];
		array[0] = matrix[2][1];
		array[0] = matrix[2][2];
	}
	if (row == 4) {
		array[0] = matrix[0][0];
		array[0] = matrix[0][1];
		array[0] = matrix[0][2];
		array[0] = matrix[0][3];
		array[0] = matrix[1][0];
		array[0] = matrix[1][1];
		array[0] = matrix[1][2];
		array[0] = matrix[1][3];
		array[0] = matrix[2][0];
		array[0] = matrix[2][1];
		array[0] = matrix[2][2];
		array[0] = matrix[2][3];
		array[0] = matrix[3][0];
		array[0] = matrix[3][1];
		array[0] = matrix[3][2];
		array[0] = matrix[3][3];
	}
	int temp;
	for (int i = 0;i < n;i++) {
		for (int j = 0;j < n;j++) {
			if (*(array + i) > *(array + j)) {
				temp = *(array + i);
				*(array + i) = *(array + j);
				*(array + j) = temp;
			}
		}
	}
	return array[k - 1];
}
Matrix Matrix::merge(Matrix m) {
	return m;
}
