//Hassan Abbas i210507 Section B
#include"String.h"
#include<iostream>
using namespace std;
String::String() {
	data = NULL;
	length = 0;
}
String::String(int size) {
	length = size;
	data = new char[length];
	for (int i = 0;i < length;i++) {
		*(data + i) = '\0';
	}
}
String::String(char* str) {
	int size = 0;
	for (int i = 0;i < 255;i++) {
		if (*(str + i) == '\0') {
			size = i;
			i = 255;
		}
	}
	length = size;
	data = new char[length];
	for (int i = 0;i < length;i++) {
		*(data + i) = *(str + i);
	}

}
String::String(const String& str) {
	length = str.length;
	data = str.data;
}
String::~String() {
	delete[] data;
}
int String::strLength() {
	return length;
}
void String::clear() {
	data = NULL;
	length = 0;
}
bool String::empty() {
	if (data == NULL && length == 0) {
		return true;
	}
	else {
		return false;
	}
}
int String::charAt(char c) {
	for (int i = 0;i < length;i++) {
		if (*(data + i) == c) {
			return i;
		}
	}
}
char* String::getdata() {
	return data;
}
bool String::equals(char* str) {
	int true1 = 0;
	for (int i = 0;i < length;i++) {
		if (*(str + i) == *(data + i)) {
			true1++;
		}
	}
	if (true1 == length) {
		return true;
	}
	return false;
}
bool String::equalsIgnoreCase(char* str) {
	int true1 = 0;
	for (int i = 0;i < length;i++) {
		if (*(str + i) == *(data + i)) {
			true1++;
		}
		else if (*(str + i) - *(data + i) == 32) {
			true1++;
		}
		else if (*(str + i) - *(data + i) == -32) {
			true1++;
		}
	}
	if (true1 == length) {
		return true;
	}
	return false;
}
char* String::substring(char* substr, int startIndex) {
	return data;
}
char* String::substring(char* substr, int startIndex, int endIndex) {
	return data;
}
void String::print() {
	if (length == 0) {
		cout << "NULL";
	}
	else {
		for (int i = 0;i < length;i++) {
			cout << *(data + i);
		}
	}
}