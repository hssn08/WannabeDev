#pragma once
#include<iostream>
using namespace std;
class CSR {
	int csrID;
	char* csrName;
	int hours;
	int complaintsResolved;
	float payrate;
	float wage;
	static int totalComplaintsResolved;
public:
	int getCSRID();
	char* getName();
	int getHours();
	int getComplaintsResolved();
	float getPayrate();
	float getWage();
	void setCSRID(int);
	void setName(char*);
	void setHours(int);
	void setComplaintsResolved(int);
	static void setTotalCpsResolved(int);
	void calcPayrate();
	void calcWage();
	static int getTotalCpsResolved();
};
