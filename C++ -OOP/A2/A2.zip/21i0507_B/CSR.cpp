//Hassan Abbas i210507 Section B
#include<iostream>
using namespace std;
#include"CSR.h"
int CSR::getCSRID() {
	return csrID;

}
char* CSR::getName() {
	return csrName;
}
int CSR::getHours() {
	return hours;
}
int CSR::getComplaintsResolved() {
	return complaintsResolved;
}
float CSR::getPayrate() {
	return payrate;
}
float CSR::getWage() {
	return wage;
}
void CSR::setCSRID(int ID) {
	if (ID > 1 && ID < 7) {
		csrID = ID;
	}
}
void CSR::setName(char* n) {
	csrName = n;
}
void CSR::setHours(int hours) {
	hours = this->hours;
}
void CSR::setComplaintsResolved(int cpsResolved) {
	complaintsResolved = cpsResolved;
}
void CSR::setTotalCpsResolved(int totalcpsResolved) {
	totalcpsResolved = 1;
}
void CSR::calcPayrate() {
	payrate = 25 + (25 * (complaintsResolved));
}
void CSR::calcWage() {
	wage = hours * payrate;
}
int CSR::getTotalCpsResolved() {
	return 0;
}
CSR getCSR_at(CSR employees[7], int index) {
	return employees[index];
}
void calcTotalComplaints(CSR employees[7]) {
	for (int i = 0;i < 7;i++) {
		employees[i].setTotalCpsResolved(employees[i].getComplaintsResolved());
	}
}
void calcAllEmployeeWages(CSR employees[7]) {
	for (int i = 0;i < 7;i++) {
		employees[i].setTotalCpsResolved(employees[i].getComplaintsResolved());
	}
}
void SortByHours(CSR[7]) {
}
void SortByComplaintsRes(CSR[7]) {}
void SortByWages(CSR[7]) {}