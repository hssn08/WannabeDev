//Hassan Abbas i210507 Section B
#include"Sequence.h"
#include<iostream>
using namespace std;
Sequence::Sequence() {
	length = 10;
	pseq = new int[length];
	for (int i = 0;i < length;i++) {
		*(pseq + i) = 0;
	}
}
Sequence::Sequence(int lengthVal, int n1 = 0, int n2 = 0, int n3 = 0, int n4 = 0, int n5 = 0, int n6 = 0, int n7 = 0, int n8 = 0, int n9 = 0, int n10 = 0) {
	length = lengthVal;
	pseq = new int[length];
	int arrad[10] = { n1,n2,n3,n4,n5,n6,n7,n8,n9,n10 };
	for (int i = 0;i < length;i++) {
		*(pseq + i) = arrad[i];
	}
}
Sequence::Sequence(const Sequence& copy) {
	pseq = new int[10];
	length = copy.length;
	for (int i = 0;i < length;i++) {
		*(pseq + i) = copy.pseq[i];
	}
}
int Sequence::getLength() {
	return length;
}
int* Sequence::getSeq() {
	return pseq;
}
void Sequence::Sort(int n) {
	int temp;
	for (int i = 0;i < n;i++) {
		for (int j = 0;j < n;j++) {
			if (*(pseq + i) < *(pseq + j)) {
				temp = *(pseq + i);
				*(pseq + i) = *(pseq + j);
				*(pseq + j) = temp;
			}
		}
	}
}
int Sequence::RemoveDuplicates() {
	int n = 0;
	for (int i = 0;i < length;i++) {
		for (int j = 0;j < length;j++) {
			if (i != j) {
				if (*(pseq + i) == *(pseq + j)) {
					*(pseq + j) = 999;
				}
			}
			Sort(length);
		}
	}
	for (int i = 0;i < length;i++) {
		if (*(pseq + i) != 999) {
			n++;
		}
	}
	return n;
}
void Sequence::Rotate(int n) {
	int size = length;
	int* arr = new int[size];
	for (int i = 0;i < size;i++) {
		*(arr + i) = *(pseq + i);
	}
	int gg = size - n;
	int* arra = new int[n];
	int* arra1 = new int[gg];
	for (int i = 0;i < size - n;i++) {
		*(arra1 + i) = *(arr + i);
	}
	for (int i = size - n;i < size;i++) {
		*(arra + i + n - size) = *(arr + i);
	}
	for (int i = 0;i < size - n;i++) {
		*(arr + i) = *(arra + i);
	}
	for (int i = n;i < size;i++) {
		*(pseq + i) = *(arra1 + (i - n));
	}
	for (int i = 0;i < n;i++) {
		*(pseq + i) = *(arr + i);
	}

}


Sequence::~Sequence() {
	delete[]pseq;
}