//Hassan Abbas i210507 Section B
#include<iostream>
using namespace std;
#include"CustomerAccount.h"


void OpenCustomerAccount(CustomerAccount* customers[], int& accountsOpen, char* NameVal, char* addVal, char* cityVal, char* stateVal, int zipcodeVal, long long phoneVal, float balanceVal) {
	if (accountsOpen < 100) {
		*(customers + accountsOpen) = new CustomerAccount[1000];
		CustomerAccount x;
		x.name = NameVal;
		x.address.address = addVal;
		x.address.city = cityVal;
		x.address.state = stateVal;
		x.address.zip_code = zipcodeVal;
		x.phoneNum = phoneVal;
		x.balance = balanceVal;

		x.accountNum = new char[6];
		int xx = accountsOpen + 1, yy = 0, zz = 0;
		if (xx > 9) {
			while (xx > 9) {
				xx = xx - 10;
				yy = yy + 1;
			}
		}

		*(x.accountNum + 0) = 'P';
		*(x.accountNum + 1) = 'K';
		*(x.accountNum + 2) = zz + 48;
		*(x.accountNum + 3) = yy + 48;
		*(x.accountNum + 4) = xx + 48;
		*(x.accountNum + 5) = '\0';

		if (yy > 9) {
			*(x.accountNum + 0) = 'P';
			*(x.accountNum + 1) = 'K';
			*(x.accountNum + 2) = '1';
			*(x.accountNum + 3) = '0';
			*(x.accountNum + 4) = '0';
			*(x.accountNum + 5) = '\0';
		}
		*(*(customers + accountsOpen)) = x;
		accountsOpen += 1;
	}
}
int SearchCustomer(CustomerAccount* customers[], int accountsOpen, char* accountNum) {
	string s1 = "\0";
	string v1 = accountNum;
	for (int i = 0;i < accountsOpen;i++) {
		s1 = (*(customers + i))->accountNum;
		if (s1 == v1) {
			return i;
		}
	}
	return -1;
}

bool UpdateCustomerAccount(CustomerAccount* customers[], int accountsOpen, char* accountNumVal, Address addressVal) {
	if (SearchCustomer(customers, accountsOpen, accountNumVal) == 0) {
		//customers[accountsOpen]->address.address = addressVal.address;
		//customers[accountsOpen]->address.city = addressVal.city;
		//customers[accountsOpen]->address.state = addressVal.state;
		return true;
	}
	return false;
}

bool UpdateCustomerAccount(CustomerAccount* customers[], int accountsOpen, char* accountNumVal, long long phoneVal) {
	if (SearchCustomer(customers, accountsOpen, accountNumVal) == 0) {
		//(*(customers + accountsOpen))->phoneNum = phoneVal;
		return true;
	}
	return false;
}
bool UpdateCustomerAccount(CustomerAccount* customers[], int accountsOpen, char* accountNumVal, float balanceVal) {
	if (SearchCustomer(customers, accountsOpen, accountNumVal) == 0) {
		//customers[accountsOpen]->balance = balanceVal;
		return true;
	}
	return false;
}
void DisplayAllCustomers(CustomerAccount* customers[], int accountsOpen) {
	for (int i = 0;i < accountsOpen;i++) {
		cout << customers[i]->name << endl;
		cout << customers[i]->address.address << endl;
		cout << customers[i]->address.city << endl;
		cout << customers[i]->address.state << endl;
		cout << customers[i]->address.zip_code << endl;
		cout << customers[i]->phoneNum << endl;
		cout << customers[i]->balance << endl;
		cout << customers[i]->accountNum << endl;
	}
}