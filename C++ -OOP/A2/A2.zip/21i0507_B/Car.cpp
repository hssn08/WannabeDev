//Hassan Abbas i210507 Section B
#include"../Assignment2/Car.h"
#include<iostream>
using namespace std;
Car::Car() {
	petrolLevel = 0;
}
Car::Car(int x) {
	petrolLevel = x;
}
void Car::setPetrolLevel(int x) {
	if (x >= 0 && x <= 45) {
		petrolLevel = x;
	}
}
int Car::getPetrolLevel() {
	return petrolLevel;
}
bool Car::MoveCar(int x) {
	if (petrolLevel > x) {
		for (int i = 0;i < x;i++) {
			petrolLevel--;
		}
		if (petrolLevel >= 0) {
			return true;
		}
	}
	else {
		return false;
	}
}
void Car::Refill() {
	petrolLevel = 45;
}
bool Car::isEmpty() {
	if (petrolLevel <= 0) {
		return true;
	}
	if (petrolLevel > 0) {
		return false;
	}
}