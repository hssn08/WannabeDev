#pragma once
#include<iostream>
using namespace std;
struct Address {
	char* address;
	char* city;
	char* state;
	int zip_code;
};
struct CustomerAccount {
	char* name;
	Address address;
	long long phoneNum;
	float balance;
	char* accountNum;
};
