//Hassan Abbas i210507 Section B
#include"Sandwich.h"
#include<iostream>
using namespace std;
Sandwich::Sandwich() {

}
Sandwich::Sandwich(char* fillingVal, double priceVal) {
	setFilling(fillingVal);
	setPrice(priceVal);
}
Sandwich::Sandwich(char* fillingVal, double priceVal, char* nameVal, char* sizeVal, bool ready_status) {
	setFilling(fillingVal);
	setPrice(priceVal);
	setName(nameVal);
	setSize(sizeVal);
	is_ready = ready_status;
}
Sandwich::Sandwich(const Sandwich& sandwich) {
	setFilling(sandwich.filling);
	setPrice(sandwich.price);
	setName(sandwich.name);
	setSize(sandwich.size);
	is_ready = sandwich.is_ready;
}
void Sandwich::setFilling(char* fillingVal) {
	filling = fillingVal;
}
void Sandwich::setPrice(double priceVal) {
	price = priceVal;
}
void Sandwich::setName(char* nameVal) {
	name = nameVal;
}
void Sandwich::setSize(char* sizeVal) {
	string sizeV = sizeVal;
	if (sizeV == "small" || sizeV == "medium" || sizeV == "large") {
		size = sizeVal;
	}
	else {
		size = NULL;
	}
}
char* Sandwich::getFilling() {
	return filling;
}
double Sandwich::getPrice() {
	return price;
}
char* Sandwich::getName() {
	return name;
}
char* Sandwich::getSize() {
	return size;
}
void Sandwich::makeSandwich() {
	if (filling != "NULL") {
		is_ready = true;
	}
}
bool Sandwich::check_status() {
	if (is_ready == 1) {
		return true;
	}
	else {
		return false;
	}
}