//Syed Hassan Abbas
//21I-0507
//OOP Assignment#1

#pragma once
#include<iostream>
using namespace std;
void PrintPattern1(int, int);
void PrintPatternSpc(int, int);
void onehalf(int, int);
void secondhalf(int, int);
void spaces(int);
void stars(int);
char* convertToTapCode(char* str) {
	char* ans = new char[255];
	for (int i = 0;i < 255;i++) {
		*(ans + i) = '\0';
	}
	int x = 0;
	char alpha[5][6] = { "abcde","fghij","lmnop","qrstu","vwxyz" };
	for (int k = 0;k < 25;k++) {
		for (int i = 0;i < 5;i++) {
			for (int j = 0;j < 5;j++) {
				if (*(str + k) == alpha[i][j]) {
					for (int l = 0;l <= i;l++) {
						*(ans + x) = '.';
						x++;
					}
					*(ans + x) = ' ';
					x++;
					for (int l = 0;l <= j;l++) {
						*(ans + x) = '.';
						x++;
					}
					*(ans + x) = ' ';
					x++;
					*(ans + x) = ' ';
					x++;
				}
			}
		}
	}
	ans[x] = '\0';
	ans[x - 1] = '\0';
	ans[x - 2] = '\0';

	return ans;
}

char* convertToString(char* str) {
	char alpha[5][6] = { "abcde","fghij","lmnop","qrstu","vwxyz" };
	char* ans = new char[255];
	for (int i = 0;i < 255;i++) {
		*(ans + i) = '\0';
	}
	int x = 0;
	int j = 0;
	int y = 0;
	int n = 0;
	for (int k = 0;k < 200;k++) {
		if (*(str + k) == ' ') {
			n++;
		}
		if (n == 0) {
			if (*(str + k) != ' ') {
				x++;

			}
		}
		if (n == 1) {
			if (*(str + k) != ' ') {
				y++;

			}
		}

		if (*(str + k) == '\0') {
			n += 2;
			y -= 1;
		}
		if (n == 3) {
			ans[j] = alpha[x - 1][y - 1];
			j++;
			x = 0;
			y = 0;
			n = 0;
		}
	}
	return ans;
}

char* additionOfBigInteger(char* Num1, char* Num2) {
	char* ptr = new char[255];
	for (int i = 0;i < 255;i++) {
		(*(ptr + i) = '\0');
	}
	int size1, size2, size3, n, size4, k;
	for (int i = 0;i < 255;i++) {
		if (*(Num1 + i) == '\0') {
			size1 = i;
			i = 255;
		}
	}
	for (int i = 0;i < 255;i++) {
		if (*(Num2 + i) == '\0') {
			size2 = i;
			i = 255;
		}
	}
	char* Num3 = new char[size1];
	if (size2 < size1) {
		size4 = size1 - size2;
		for (int i = 0;i <= size4;i++) {
			*(Num3 + i) = '0';
		}
		for (int i = size4;i <= size1;i++) {
			k = (*(Num2 + (i - size4)) - 48);
			*(Num3 + i) = k + 48;
		}
		for (int i = 0;i < size1;i++) {
			n = (*(Num1 + i) - 48) + (*(Num3 + i) - 48);
			if (n >= 10) {
				n -= 10;
				*(ptr + (i - 1)) += 1;
			}
			*(ptr + i) = n + 48;
		}
		for (int i = 0;i < 255;i++) {
			if (*(ptr + i) == '\0') {
				size3 = i;
				i = 255;
			}
		}
		return ptr;
	}
	char* Num4 = new char[size2];
	if (size1 < size2) {
		size4 = size2 - size1;
		for (int i = 0;i <= size4;i++) {
			*(Num4 + i) = '0';
		}
		for (int i = size4;i <= size2;i++) {
			k = (*(Num1 + (i - size4)) - 48);
			*(Num4 + i) = k + 48;
		}
		for (int i = 0;i < size2;i++) {
			n = (*(Num4 + i) - 48) + (*(Num2 + i) - 48);
			if (n >= 10) {
				n -= 10;
				*(ptr + (i - 1)) += 1;
			}
			*(ptr + i) = n + 48;
		}
		for (int i = 0;i < 255;i++) {
			if (*(ptr + i) == '\0') {
				size3 = i;
				i = 255;
			}
		}

		return ptr;
	}
	if (size1 == size2) {
		for (int i = 0;i < size1;i++) {
			n = (*(Num1 + i) - 48) + (*(Num2 + i) - 48);
			if (n >= 10) {
				n -= 10;
				*(ptr + (i - 1)) += 1;
			}
			*(ptr + i) = n + 48;
		}
		for (int i = 0;i < 255;i++) {
			if (*(ptr + i) == '\0') {
				size3 = i;
				i = 255;
			}
		}
		return ptr;
	}
}

char* subtractionOfBigInteger(char* Num1, char* Num2) {
	char* ptr = new char[255];
	for (int i = 0;i < 255;i++) {
		(*(ptr + i) = '\0');
	}
	char* ptrs = new char[255];
	for (int i = 0;i < 255;i++) {
		(*(ptrs + i) = '\0');
	}
	*(ptrs) = '-';
	int size1, size2, size3, n, size4, k;
	bool iswitch = true;
	for (int i = 0;i < 255;i++) {
		if (*(Num1 + i) == '\0') {
			size1 = i;
			i = 255;
		}
	}
	for (int i = 0;i < 255;i++) {
		if (*(Num2 + i) == '\0') {
			size2 = i;
			i = 255;
		}
	}
	char* Num3 = new char[size1];
	if (size2 < size1) {
		size4 = size1 - size2;
		for (int i = 0;i <= size4;i++) {
			*(Num3 + i) = '0';
		}
		for (int i = size4;i <= size1;i++) {
			k = (*(Num2 + (i - size4)) - 48);
			*(Num3 + i) = k + 48;
		}
		for (int i = 0;i < size1;i++) {
			n = (*(Num1 + i) - 48) - (*(Num3 + i) - 48);
			if (n <= 0) {
				n += 10;
				*(ptr + (i - 1)) -= 1;
			}
			if (i + 1 == size1) {
				if (n >= 10) {
					n -= 10;
					*(ptr + (i - 1)) += 1;
					iswitch = false;
				}
			}
			*(ptr + i) = n + 48;
		}
		for (int i = 0;i < 255;i++) {
			if (*(ptr + i) == '\0') {
				size3 = i;
				i = 255;
			}
		}
		if (iswitch == 0) {
			size3 -= 1;
		}
		for (int i = 0;i < size3;i++) {
			cout << *(ptr + i);
		}
		return ptr;
	}
	char* Num4 = new char[size2];
	if (size1 < size2) {
		size4 = size2 - size1;
		for (int i = 0;i <= size4;i++) {
			*(Num4 + i) = '0';
		}
		for (int i = size4;i <= size2;i++) {
			k = (*(Num1 + (i - size4)) - 48);
			*(Num4 + i) = k + 48;
		}
		for (int i = 0;i < size1;i++) {
			n = (*(Num4 + i) - 48) - (*(Num2 + i) - 48);
			if (n <= 0) {
				n += 10;
				*(ptr + (i - 1)) -= 1;
			}
			if (i + 1 == size1) {
				if (n >= 10) {
					n -= 10;
					*(ptr + (i - 1)) += 1;
					iswitch = false;
				}
			}
			*(ptr + i) = n + 48;
		}
		for (int i = 0;i < 255;i++) {
			if (*(ptr + i) == '\0') {
				size3 = i;
				i = 255;
			}
		}
		if (iswitch == 0) {
			size3 -= 1;
		}
		for (int i = 0;i < size3;i++) {
			cout << *(ptr + i);
		}
		return ptr;
	}

	if (size1 == size2) {
		if (*(Num1) > *(Num2)) {
			for (int i = 0;i < size1;i++) {
				n = (*(Num1 + i) - 48) - (*(Num2 + i) - 48);
				if (n <= 0) {
					n += 10;
					*(ptr + (i - 1)) -= 1;
				}
				if (i + 1 == size1) {
					if (n >= 10) {
						n -= 10;
						*(ptr + (i - 1)) += 1;
						iswitch = false;
					}
				}
				*(ptr + i) = n + 48;
			}
			for (int i = 0;i < 255;i++) {
				if (*(ptr + i) == '\0') {
					size3 = i;
					i = 255;
				}
			}
			if (iswitch == 0) {
				size3 -= 1;
			}
			for (int i = 0;i < size3;i++) {
				cout << *(ptr + i);
			}
			return ptr;
		}



		if (*(Num2) > *(Num1)) {
			for (int i = 0;i < size1;i++) {
				n = (*(Num2 + i) - 48) - (*(Num1 + i) - 48);
				if (n <= 0) {
					n += 10;
					*(ptr + (i - 1)) -= 1;
				}
				if (i + 1 == size1) {
					if (n >= 10) {
						n -= 10;
						*(ptr + (i - 1)) += 1;
					}
				}
				*(ptr + i) = n + 48;
			}
			for (int i = 0;i < 255;i++) {
				if (*(ptr + i) == '\0') {
					size3 = i;
					i = 255;
				}
			}
		}
		for (int i = 0;i < size3;i++) {
			*(ptrs + (i + 1)) = (*(ptr + i));
			cout << *(ptrs + i);
		}
		return ptrs;
	}
}

char* multiplicationOfBigInteger(char* Num1, char* Num2) {
	return 0;
}

void removePunctuation(char* str) {
	int x = 0;
	int size;
	bool iswitch = true;
	char punc[22] = { '.',',','"',';',':','{','}','\\','_','-','*','\\@','#','!','\?','&','~','`','(',')' };
	for (int i = 0;i < 255;i++) {
		if (*(str + i) == '\0') {
			size = i;
			i = 255;
		}
	}

	for (int i = 0;i < size;i++) {
		for (int j = 0;j < 23;j++) {
			if (*(str + i) == punc[j]) {
				for (int l = i;l < size;l++) {
					*(str + l) = *(str + (l + 1));
					iswitch = false;
				}
			}
		}
		if (iswitch == false) {
			for (int i = 0;i < size;i++) {
				for (int j = 0;j < 23;j++) {
					if (*(str + i) == punc[j]) {
						for (int l = i;l < size;l++) {
							*(str + l) = *(str + (l + 1));
							iswitch = false;
						}
					}
				}
			}
			iswitch = true;
		}
	}





	for (int i = 0;i < size;i++) {
		if (*(str + i) == 32) {
			if (*(str + (i + 1)) == 32) {
				for (int l = i;l < size;l++) {
					*(str + l) = *(str + (l + 1));
					iswitch = false;
				}
			}
		}
		if (iswitch == false) {
			for (int i = 0;i < size;i++) {
				if (*(str + i) == 32) {
					if (*(str + (i + 1)) == 32) {
						for (int l = i;l < size;l++) {
							*(str + l) = *(str + (l + 1));
							iswitch = false;
						}
					}
				}
			}
			iswitch = true;
		}
	}
	for (int i = 0;i < size;i++) {
		std::cout << *(str + i);
	}
}

void countLetters(char* str, int*& array, int& size) {
	int size1;
	for (int i = 0;i < 255;i++) {
		if (*(str + i) == '\0') {
			size1 = i;
			i = 255;
		}
	}
	size = size1;
	int* array1 = new int[size1];
	array = array1;
	for (int i = 0;i < size1;i++) {
		array1[i] = 1;
	}
	for (int i = 0;i < size1;i++) {
		for (int j = 0;j < size1;j++) {

			if (i != j) {
				if (*(str + i) != '0') {
					if (*(str + i) == *(str + j)) {
						*(str + j) = '0';
						size--;
						array1[i] += 1;
					}
				}
			}
		}
	}
}

bool isprimeNumber(int n, int i) {
	if (n == 0 || n == 1)
	{
		return 0;
	}
	if (n == 2) {
		return 1;
	}
	if (n % i == 0)
	{
		return 0;
	}
	if (i > n / 2)
	{
		return 1;
	}
	return isprimeNumber(n, i + 1);
}

char findUppercase(char* str) {
	if (str[0] >= 'A' && str[0] <= 'Z')
	{
		return str[0];
	}
	return findUppercase(str + 1);
}

int sum(int** array, int row, int column, int& evenSum, int& oddSum) {
	return 0;
}

void PrintPattern1(int start, int end) {
	onehalf(start, end);
	secondhalf(start + 1, end - 1);
}
void onehalf(int start, int end) {
	if (end > start) {
		onehalf(start + 1, end - 1);
		PrintPatternSpc(start, end);
		cout << "*";
		cout << endl;
	}
}
void secondhalf(int start, int end) {
	if (end > start) {
		PrintPatternSpc(start, end);
		cout << "*";
		cout << endl;
		secondhalf(start + 1, end - 1);
	}
}
void PrintPatternSpc(int x, int y) {
	if (x < y) {
		cout << " ";
		PrintPatternSpc(x + 1, y);
	}
}

void PrintPattern2(int n1, int n2, int n3) {
	if (n3 > 0) {
		spaces(n1 - 1);
		stars(n2);
		cout << endl;
		PrintPattern2(n1 - 1, n2 + 2, n3 - 1);
		spaces(n1);
		stars(n2 - 2);
		cout << endl;
	}
}
void stars(int y) {
	if (y > 0) {
		cout << "*";
		stars(y - 1);
	}
}
void spaces(int x) {
	if (x > 0) {
		cout << " ";
		spaces(x - 1);
	}
}

void PrintPattern3(int n1, int n2, int n3) {

}