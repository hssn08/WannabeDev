#include<iostream>
using namespace std;
#include"Doctorattributes.h"
class Register {
protected:
	Doctorattributes doc;
	string usertype;
	string cnic;
	string email;
	string password;
	string username;
	int balance = 0;
};
