#pragma once

#include"Appointment.h"
#include"Doctorattributes.h"

#include"Doctor.h"
#include"Patient.h"
#include"Database.h"
class Validation {
public:
	bool verifyvalidcnic(string cnic) {
		int x = 0;
		if (cnic.length() == 13) {
			for (int i = 0;i < 13;i++) {
				if (cnic[i] >= 48 && cnic[i] <= 57) {
					x++;
				}
			}
			if (x == 13) {
				return true;
			}
		}
		else {
			return false;
		}
	}
	bool verifypassword(string password) {
		char c;
		int x = 0;
		bool uppercase = false;
		bool lowercase = false;
		bool spl = false;
		bool numeric = false;
		for (int i = 0;i < password.length();i++) {
			c = password[i];
			if (c >= 'A' && c < 'Z') {
				uppercase = true;
			}
			else if (c >= 'a' && c <= 'z') {
				lowercase = true;
			}
			else if (c >= '0' && c <= '9') {
				numeric = true;
			}
			else {
				spl = true;
			}

		}
		if (password.length() >= 8) {
			x += 1;
		}
		if (password.length() < 8) {
			cout << "Password must be greater than 8 digits!" << endl;
		}
		if (uppercase == true && lowercase == true) {
			x += 1;
		}
		if (uppercase == false) {
			cout << "At least 1 uppercase letter should exist!" << endl;
		}

		if (lowercase == false) {
			cout << "At least 1 lowercase letter should exist!" << endl;
		}
		if (spl == true && numeric == true) {
			x += 1;
		}
		if (spl == false) {
			cout << "At least 1 special letter should exist!" << endl;
		}
		if (numeric == false) {
			cout << "At least 1 number should exist!" << endl;
		}
		if (x == 3) {
			return true;
		}
		else {
			return false;
		}
	}

	bool verifyrepeatedcnic(Database database1, string cnic, int choice1) {
		int x = 0;
		if (choice1 == 1) {
			for (int i = 0;i < database1.getsizedoc();i++) {
				if (cnic == database1.getcnicddb(i)) {
					return false;
				}
			}
			return true;
		}
		if (choice1 == 2) {
			for (int i = 0;i < database1.getsizepat();i++) {
				if (cnic == database1.getcnicpdb(i)) {
					return false;
				}
			}
			return true;
		}
	}
	bool verifyrepeatedemail(Database database1, string email, int choice1) {
		int x = 0;
		if (choice1 == 1) {
			for (int i = 0;i < database1.getsizedoc();i++) {
				if (email == database1.getemailddb(i)) {
					return false;
				}
			}
			return true;
		}
		if (choice1 == 2) {
			for (int i = 0;i < database1.getsizepat();i++) {
				if (email == database1.getemailpdb(i)) {
					return false;
				}
			}
			return true;
		}
	}

	void verifyrepeatedslots(Database database1, string appointment, string name) {
		bool someslot = false;
		cout << "The booked slots are: ";
		for (int i = 0;i < database1.getsizeapp() - 1;i++) {
			if (name == database1.getdocnameadb(i)) {
				someslot = true;
				cout << database1.getapptimeadb(i) << ", ";
			}
		}
		if (someslot == false) {
			cout << " None" << endl;
		}
	}

	int showappointments(Database database1, string name) {
		int x = 1;
		int array[50];
		bool someslot = false;
		cout << "Your appointments are: \n";
		for (int i = 0;i < database1.getsizeapp() - 1;i++) {
			if (name == database1.getpatnameadb(i)) {
				someslot = true;
				cout << database1.getapptimeadb(i) << " with DR." << database1.getdocnameadb(i) << " (" << database1.getstatusadb(i) << ") " << endl;
				cout << "Press " << x << " to cancel this appointment" << endl;
				array[x] = i;
				x++;
			}
		}
		if (someslot == true) {
			cout << endl << endl;
			cout << "Press 0 to exit" << endl;
			int choice = 0;
			cout << "Enter your choice: ";
			cin >> choice;
			if (choice == 0) {
				return 0;
			}
			else {
				database1.cancelappointment(array[choice]);
			}
			return 0;
		}
		if (someslot == false) {
			cout << " None" << endl;
		}
		return 0;
	}



	int showfeedback(Database database1, string name) {
		int x = 1;
		int array[50];
		bool someslot = false;
		cout << "Your appointments are: \n";
		for (int i = 0;i < database1.getsizeapp() - 1;i++) {
			if (name == database1.getpatnameadb(i)) {
				someslot = true;
				cout << database1.getapptimeadb(i) << " with DR." << database1.getdocnameadb(i) << " (" << database1.getstatusadb(i) << ") " << endl;
				cout << "Press " << x << " to give feedback to this doctor" << endl;
				array[x] = i;
				x++;
			}
		}
		if (someslot == true) {
			cout << endl << endl;
			cout << "Press 0 to exit" << endl;
			int choice = 0;
			cout << "Enter your choice: ";
			cin >> choice;
			if (choice == 0) {
				return 0;
			}
			else {
				for (int i = 0;i < database1.getsizedoc();i++) {
					if (database1.getdocnameadb(array[choice]) == database1.getusernameddb(i)) {
						cout << "Enter stars to give your doctor out of five" << endl;
						int stars;
						cin >> stars;
						cout << "OK" << endl;
					}
				}
			}
			return 0;
		}
		if (someslot == false) {
			cout << " None" << endl;
		}
		return 0;
	}









	int rejectappointments(Database database1, string name) {
		int x = 1;
		int array[50];
		bool someslot = false;
		cout << "Your appointments are: \n";
		for (int i = 0;i < database1.getsizeapp() - 1;i++) {
			if (name == database1.getdocnameadb(i)) {
				someslot = true;
				cout << database1.getapptimeadb(i) << " with Patient." << database1.getpatnameadb(i) << " (" << database1.getstatusadb(i) << ") " << endl;
				cout << "Press " << x << " to reject this appointment" << endl;
				array[x] = i;
				x++;
			}
		}
		if (someslot == true) {
			cout << endl << endl;
			cout << "Press 0 to exit" << endl;
			int choice = 0;
			cout << "Enter your choice: ";
			cin >> choice;
			if (choice == 0) {
				return 0;
			}
			else {
				database1.cancelappointment(array[choice]);
			}
			return 0;
		}
		if (someslot == false) {
			cout << " None" << endl;
		}
		return 0;
	}





	int approveappointments(Database database1, string name) {
		int x = 1;
		int array[50];
		bool someslot = false;
		cout << "Your appointments are: \n";
		for (int i = 0;i < database1.getsizeapp() - 1;i++) {
			if (name == database1.getdocnameadb(i)) {
				someslot = true;
				cout << database1.getapptimeadb(i) << " with Patient." << database1.getpatnameadb(i) << " (" << database1.getstatusadb(i) << ") " << endl;
				cout << "Press " << x << " to approve this appointment" << endl;
				array[x] = i;
				x++;
			}
		}
		if (someslot == true) {
			cout << endl << endl;
			cout << "Press 0 to exit" << endl;
			int choice = 0;
			cout << "Enter your choice: ";
			cin >> choice;
			if (choice == 0) {
				return 0;
			}
			else {
				database1.approveappointment(array[choice]);
			}
			return 0;
		}
		if (someslot == false) {
			cout << " None" << endl;
		}
		return 0;
	}









	int showappointmentsdoc(Database database1, string name) {

		bool someslot = false;
		cout << "Your appointments are: \n";
		for (int i = 0;i < database1.getsizeapp() - 1;i++) {
			if (name == database1.getdocnameadb(i)) {
				someslot = true;
				cout << database1.getapptimeadb(i) << " with Patient." << database1.getpatnameadb(i) << " (" << database1.getstatusadb(i) << ") " << endl;
			}
		}
		if (someslot == true) {
			cout << endl << endl;
			cout << "Press 0 to exit" << endl;
			int choice = 0;
			cout << "Enter your choice: ";
			cin >> choice;
			if (choice == 0) {
				return 0;
			}
		}
		if (someslot == false) {
			cout << " None" << endl;
		}
		return 0;
	}









	bool verifyrepeatedapp(Database database1, string appointment, string name) {
		for (int i = 0;i < database1.getsizeapp() - 1;i++) {
			if (name == database1.getdocnameadb(i)) {
				if (appointment == database1.getapptimeadb(i)) {
					return false;
				}
			}
		}
		return true;
	}


};