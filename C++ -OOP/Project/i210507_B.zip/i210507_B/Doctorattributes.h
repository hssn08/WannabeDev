#pragma once
#include<iostream>
using namespace std;
class Doctorattributes {
public:
	Appointment x;
	string specialization;
	string experiencetime;
	string hospitalname;
	string city;
	string avlhours;
	int charges;
	Doctorattributes();
	Doctorattributes(string , string , string , string , string , int );
};