#include<iostream>
#include<string>
#include<fstream>
#include<stdlib.h>
using namespace std;
#include"Appointment.h"
#include"Doctorattributes.h"
#include"Register.h"
#include"Doctor.h"
#include"Patient.h"
#include"Database.h"
#include"Validation.h"

	Appointment::Appointment() {
		appno = 0;
		appointmentstatus = 0;
		status = '\0';
		docid = '\0';
		docname = '\0';
		patid = '\0';
		patname = '\0';
		appmode = '\0';
		apptime = '\0';
	}
	Appointment::Appointment(string status1, string docid1, string docname1, string patid1, string patname1, string appmode1, string apptime1) {
		appno = 0;
		appointmentstatus = 0;
		status = status1;
		docid = docid1;
		docname = docname1;
		patid = patid1;
		patname = patname1;
		appmode = appmode1;
		apptime = apptime1;
	}
	void Appointment::setappointment(string appointment) {
		apptime = appointment;
	}
	void Appointment::rejectappointment(string appointment) {
		cout << "Appointment for " << appointment << " Rejected" << endl;
	}
	void Appointment::filehandlingapp(string status,string docid,string docname, string patid, string patname, string appmode,string apptime) {
		ofstream appwrite;
		appwrite.open("app.txt", ios::app);
		appwrite << status << endl;
		appwrite << docid << endl;
		appwrite << docname << endl;
		appwrite << patid << endl;
		appwrite << patname << endl;
		appwrite << appmode << endl;
		appwrite << apptime << endl;
		appwrite.close();
	}


	Doctorattributes::	Doctorattributes() {
		specialization = "\0";
		experiencetime = "\0";
		hospitalname = "\0";
		city = "\0";
		avlhours = "\0";
		charges = 0;
	}
	Doctorattributes::	Doctorattributes(string specialization1, string experiencetime1, string city1, string hospitalname1, string avlhours1, int charges1) {
		specialization = specialization1;
		experiencetime = experiencetime1;
		hospitalname = hospitalname1;
		city = city1;
		avlhours = avlhours1;
		charges = charges1;
	}




Doctor::Doctor() {
		cnic = '\0';
		email = '\0';
		password = '\0';
		balance = 0;
		username = '\0';
	}
Doctor::Doctor(string usertype1, string cnic1, string email1, string username1, string password1, int balance1, Doctorattributes doc1) {
		usertype = usertype1;
		cnic = cnic1;
		email = email1;
		password = password1;
		doc = doc1;
		username = username1;
		balance = balance1;
	}

void Doctor::filehandlingdoc() {
		ofstream doctorwrite;
		doctorwrite.open("doc.txt", ios::app);
		doctorwrite << usertype << endl;
		doctorwrite << cnic << endl;
		doctorwrite << email << endl;
		doctorwrite << password << endl;
		doctorwrite << username << endl;
		doctorwrite << doc.specialization << endl;
		doctorwrite << doc.experiencetime << endl;
		doctorwrite << doc.hospitalname << endl;
		doctorwrite << doc.city << endl;
		doctorwrite << doc.avlhours << endl;
		doctorwrite << doc.charges << endl;
		doctorwrite << balance << endl;
		doctorwrite.close();
	}
	string Doctor::getcnic() const {
		return cnic;
	}
	string Doctor::getemail() const {
		return email;
	}

	Appointment Doctor::getappointment() {
		return doc.x;
	}
	string Doctor::getusername() const {
		return username;
	}
	string Doctor::getusertype() const {
		return usertype;
	}
	string Doctor::getpassword() const {
		return password;
	}
	void Doctor::setcnic(string cnic1) {
		cnic = cnic1;
	}
	void Doctor::setemail(string cnic1) {
		email = cnic1;
	}
	void Doctor::setusername(string cnic1) {
		username = cnic1;
	}
	void Doctor::setpassword(string cnic1) {
		password = cnic1;
	}
	void Doctor::addbalance(int x) {
		balance = balance + x;
	}
	void Doctor::takebalance(int x) {
		balance = balance - x;
	}
	string Doctor::getspecialization() const {
		return doc.specialization;
	}
	string Doctor::getexp() const {
		return doc.experiencetime;
	}
	string Doctor::getcity() const {
		return doc.city;
	}
	int Doctor::getbalance() const {
		return balance;
	}
	void Doctor::setavlhours(string n) {
		doc.avlhours = n;
	}
	void Doctor::setcharges(int n) {
		doc.charges = n;
	}
	void Doctor::setcity(string n) {
		doc.city = n;
	}
	string Doctor::gethours() const {
		return doc.avlhours;
	}
	string Doctor::gethospital() const {
		return doc.hospitalname;
	}
	int Doctor::getcharges() const {
		return doc.charges;
	}
	void Doctor::setbalance(int x) {
		balance = x;
	}
	

	Patient::Patient() {
		cnic = '\0';
		email = '\0';
		password = '\0';
		balance = 0;
		username = '\0';
	}
	Patient::Patient(string usertype1, string cnic1, string email1, string username1, string password1, int balance1) {
		usertype = usertype1;
		cnic = cnic1;
		email = email1;
		password = password1;
		username = username1;
		balance = balance1;
	}

	void Patient::filehandlingpat() {
		ofstream doctorwrite;
		doctorwrite.open("pat.txt", ios::app);
		doctorwrite << usertype << endl;
		doctorwrite << cnic << endl;
		doctorwrite << email << endl;
		doctorwrite << password << endl;
		doctorwrite << username << endl;
		doctorwrite << balance << endl;
		doctorwrite.close();
	}
	string Patient::getcnic() const {
		return cnic;
	}
	string Patient::getemail() const {
		return email;
	}

	string Patient::getusername() const {
		return username;
	}
	string Patient::getusertype() const {
		return usertype;
	}
	string Patient::getpassword() const {
		return password;
	}
	void Patient::setcnic(string cnic1) {
		cnic = cnic1;
	}
	void Patient::setemail(string cnic1) {
		email = cnic1;
	}
	void Patient::setusername(string cnic1) {
		username = cnic1;
	}
	void Patient::setpassword(string cnic1) {
		password = cnic1;
	}
	void Patient::addbalance(int x) {
		balance = balance + x;
	}
	void Patient::takebalance(int x) {
		balance = balance - x;
	}
	int Patient::getbalance() const {
		return balance;
	}
	void Patient::setbalance(int x) {
		balance = x;
	}



class Login {
	Database credentials;
	int choice;
public:
	Login(Database D, int choice1) {
		credentials = D;
		choice = choice1;
	}
	int loginverification(string username, string password, int choice) {
		int x = 0;
		if (choice == 1) {
			for (int i = 0;i < credentials.getsizedoc();i++) {
				if (username == credentials.getusernameddb(i) && password == credentials.getpasswordddb(i)) {
					return i;
				}
			}
			return -1;
		}
		if (choice == 2) {
			for (int i = 0;i < credentials.getsizepat();i++) {
				if (username == credentials.getusernamepdb(i) && password == credentials.getpasswordpdb(i)) {
					return i;
				}
			}
			return -1;
		}
	}
};





int main() {
	Validation t;
	Database DB;

	ifstream checkfile;
	checkfile.open("doc.txt");

	if (!checkfile)
		cout << "No Existing Doctor Record Found! Register First!" << endl << endl;
	else {
		DB.databasestoredoc();
	}
	checkfile.close();
	
	
	ifstream checkfile1;

	checkfile1.open("pat.txt");

	if (!checkfile1)
		cout << "No Existing Patient Record Found! Register First!" << endl << endl;
	else {
		DB.databasestorepat();
	}
	checkfile1.close();
	

	ifstream checkfile2;

	checkfile2.open("app.txt");

	if (!checkfile2)
		cout << "No Existing Appointment Record Found! Make Some First!" << endl << endl;
	else {
		DB.databasestoreapp();
	}
	checkfile2.close();

	
	int x = 1;
	while (x <= 999) {
		cout << "Welcome to Main Menu" << endl;
		cout << "Press 1 to Login\nPress 2 to Register" << endl;
		int opt0 = 0;
		cin >> opt0;
		if (opt0 == 1) {
			system("CLS");
			cout << "Press 1 to Login as a Doctor" << endl;
			cout << "Press 2 to Login as a Patient" << endl;
			cout << "Press 3 to login as ADMIN" << endl;
			int choice1;
			cout << "Enter your choice: ";
			cin >> choice1;
			string username1, password1;
			cout << "Enter Username: ";
			cin >> username1;
			cout << "Enter Password: ";
			cin >> password1;
			system("CLS");
			if (choice1 == 3) {
				if (username1 == "admin" && password1 == "admin") {
					int k = 0;
					while (k == 0) {
						cout << endl << endl;
						cout << "Logged in as SUPERUSER" << endl;
						cout << endl << endl << "Press 1 to view all Doctor data\nPress 2 to view all patients data\nPress 3 to change doctor availability\nPress 4 to view all appointment data\nPress 5 to logout" << endl;
						int choice4;
						cin >> choice4;
						if (choice4 == 1) {
							for (int i = 0;i < DB.getsizedoc() - 1;i++) {

								cout << "The system has found DR. " << DB.getusernameddb(i) << " (" << DB.getspecdb(i) << ")" << endl;
								cout << "City: " << DB.getcitydb(i) << endl;
								cout << "Years of Experience: " << DB.getexperiencedb(i) << endl;
								cout << "Hospital: " << DB.gethospitaldb(i) << endl;
								cout << "CNIC: " << DB.getcnicddb(i) << endl;
								cout << "Email: " << DB.getemailddb(i) << endl;
								cout << "Password: " << DB.getpasswordddb(i) << endl;
								cout << endl;
								cout << "Avialabilty Hours: " << DB.gethoursdb(i) << endl;
								cout << "Consultation charges: " << DB.getchargesdb(i) << endl;
								cout << endl;

							}
						}
						else if (choice4 == 2) {
							for (int i = 0;i < DB.getsizepat() - 1;i++) {
								if (DB.gettypepdb(i) == "Patient") {
									cout << "The system has found Patient. " << DB.getusernamepdb(i) << endl;
									cout << "CNIC: " << DB.getcnicpdb(i) << endl;
									cout << "Email: " << DB.getemailpdb(i) << endl;
									cout << "Password: " << DB.getpasswordpdb(i) << endl;
									cout << endl;
								}
							}
						}

						else if (choice4 == 3) {
							int x = 0;
							int array[50];
							for (int i = 0;i < DB.getsizedoc() - 1;i++) {

								cout << "The system has found DR. " << DB.getusernameddb(i) << " (" << DB.getspecdb(i) << ")" << endl;
								cout << "City: " << DB.getcitydb(i) << endl;
								cout << "Years of Experience: " << DB.getexperiencedb(i) << endl;
								cout << "Hospital: " << DB.gethospitaldb(i) << endl;
								cout << "CNIC: " << DB.getcnicddb(i) << endl;
								cout << "Email: " << DB.getemailddb(i) << endl;
								cout << "Password: " << DB.getpasswordddb(i) << endl;
								cout << endl;
								cout << "Avialabilty Hours: " << DB.gethoursdb(i) << endl;
								cout << "Consultation charges: " << DB.getchargesdb(i) << endl;
								cout << endl;
								cout << "Press " << x << " to change Doctor availability hours" << endl;
								array[x] = i;
								x++;
							}
							int choice9;
							cout << "Enter a choice: ";
							cin >> choice9;
							cout << "Enter new avl hours (AM-PM): ";
							string newavlhours;
							cin >> newavlhours;
							string username = DB.getusernameddb(array[choice9]);
							string cnic = DB.getemailddb(array[choice9]);
							string email = DB.getemailddb(array[choice9]);
							string avlhours = newavlhours;
							string city = DB.getcitydb(array[choice9]);
							int charges = DB.getchargesdb(array[choice9]);

							DB.setnewstuffddb(array[choice9], cnic, email, username, avlhours, city, charges);
							DB.databasestoredoc();
						}

						else if (choice4 == 4) {
							for (int i = 0;i < DB.getsizeapp() - 1;i++) {
								cout << "Appointment mode: " << DB.getappmodeadb(i) << endl;
								cout << "Appointment time: " << DB.getapptimeadb(i) << endl;
								cout << "Doctor CNIC: " << DB.getdocidadb(i) << endl;
								cout << "Doctor name: " << DB.getdocnameadb(i) << endl;
								cout << "Patient name: " << DB.getpatnameadb(i) << endl;
							}
						}
						else if (choice4 == 5) {
							DB.databasestoredoc();
							DB.databasestorepat();
							DB.databasestoreapp();

							system("CLS");
							k = 1;
						}

					}






















				}
			}
			else {

				Login logintoken(DB, choice1);
				bool checklogin = false;
				if (logintoken.loginverification(username1, password1, choice1) >= 0) {
					cout << "Login Successful as a ";
					if (choice1 == 1) {
						cout << "Doctor !" << endl << endl;
					}
					else if (choice1 == 2) {
						cout << "Patient !" << endl << endl;
					}
					checklogin = true;
				}
				else {
					cout << "Login Failed" << endl;
				}
				if (checklogin == true) {
					int k = 0;
					while (k == 0) {

						if (choice1 == 1) {
							int choice = 0;
							DB.databasestoredoc();
							DB.databasestorepat();
							DB.databasestoreapp();
						

							cout << "YOUR BALANCE= " << DB.getbalanceddb(DB.getbalanceprofiledoc(username1)) << endl << endl;
							cout << "Welcome to the Doctor Menu!" << endl << endl;
							cout << "Press 1 to edit your details" << endl;
							cout << "Press 2 to check your scheduled appointments" << endl;
							cout << "Press 3 to approve or reject appointments" << endl;
							cout << "\n\n\nPress 4 to Logout" << endl;
							cout << endl << endl << endl;
							cout << "Enter your choice: ";
							cin >> choice;



							if (choice == 1) {
								system("CLS");
								string cnic;
								string email;
								string username;
								string avlhours;
								string city;
								int charges;
								cout << "Enter new CNIC: ";
								cin >> cnic;
								
								if (t.verifyvalidcnic(cnic) == 0) {
									while (t.verifyvalidcnic(cnic) == 0) {
										cnic = '\0';
										cout << "Enter Valid CNIC (13 digit)" << endl;
										cin >> cnic;
									}
								}
								if (t.verifyrepeatedcnic(DB, cnic, choice1) == 0) {
									while (t.verifyrepeatedcnic(DB, cnic, choice1) == 0) {
										cnic = '\0';
										cout << "Enter non Repeated CNIC" << endl;
										cin >> cnic;
									}
								}
								cout << "Enter new E-mail: ";
								cin >> email;
								if (t.verifyrepeatedemail(DB, email, choice1) == 0) {
									while (t.verifyrepeatedemail(DB, email, choice1) == 0) {
										email = '\0';
										cout << "Enter non Repeated email" << endl;
										cin >> email;
									}
								}
								cout << "Enter a new username: ";
								cin >> username;
								cout << "Enter new Availability Hours: ";
								cin >> avlhours;
								cout << "Enter a new city: ";
								cin >> city;
								cout << "Enter new charges: ";
								cin >> charges;
								DB.setnewstuffddb(logintoken.loginverification(username1, password1, choice1), cnic, email, username, avlhours,city,charges);
								DB.databasestoredoc();
							}
							else if (choice == 2) {
								t.showappointmentsdoc(DB, username1);
							}
							else if (choice == 3) {
								cout << "Press 1 to approve appointments\nPress 2 to reject appointments" << endl;
								int choiceapp;
								cin >> choiceapp;
								if (choiceapp == 1) {
									t.approveappointments(DB, username1);
								}
								else if (choiceapp == 2) {
									t.rejectappointments(DB, username1);
								}
							}
							else if (choice == 4) {
								DB.databasestoredoc();
								DB.databasestorepat();
								DB.databasestoreapp();

								system("CLS");
								k = 1;
							}
						}
























				
						if (choice1 == 2) {
							int choice = 0;
							DB.databasestoredoc();
							DB.databasestorepat();
							DB.databasestoreapp();

							cout << "YOUR BALANCE= " << DB.getbalancepdb(DB.getbalanceprofile(username1)) << endl << endl;
							cout << "Welcome to the Patient Menu!" << endl << endl;
							cout << "Press 1 to reset your password" << endl;
							cout << "Press 2 to search for doctors" << endl;
							cout << "Press 3 to change your Profile details" << endl;
							cout << "Press 4 to recharge your account" << endl;
							cout << "Press 5 to check your scheduled appointments\nPress 6 to give FEEDBACK" << endl;
							cout << "\n\n\nPress 7 to Logout" << endl;
							cout << endl << endl << endl;
							cout << "Enter your choice: ";
							cin >> choice;

							if (choice == 1)

							{
								system("CLS");
								string newpassword;
								cout << "Enter your new password" << endl;
								cin >> newpassword;
								while (t.verifypassword(newpassword) == 0) {
									newpassword = '\0';
									cout << "Enter Valid password: ";
									cin >> newpassword;
								}
								DB.setpassworddb(logintoken.loginverification(username1, password1, choice1), newpassword);
								DB.databasestorepat();
							}

							else if (choice == 2)
							{
								system("CLS");
								cout << "Search for doctors using: " << endl;
								cout << "1. Speciality" << endl;
								cout << "2. City" << endl;
								cout << "3. Hospital Name" << endl;
								int search = 0;
								cin >> search;
								if (search == 1) {
									string specialization1;
									int choice = 0;
									system("CLS");
									cout << "Choose Your Specialization for Doctor" << endl;
									cout << "1. Gynecologist\n2. Dermatologist\n3. Oncologist\n4. Orthopedic" << endl;
									cout << "Enter your choice: ";
									cin >> choice;

									if (choice == 1) {
										specialization1 = "Gynecologist";
									}
									else if (choice == 2) {
										specialization1 = "Dermatologist";
									}
									else if (choice == 3) {
										specialization1 = "Oncologist";
									}
									else if (choice == 4) {
										specialization1 = "Orthopedic";
									}
									else if (choice > 4) {
										cout << "Enter a Valid choice" << endl << endl;
									}

									bool search1 = false;
									int x = 0;
									int array[50];

									for (int i = 0;i < DB.getsizedoc() - 1;i++) {

										if (specialization1 == DB.getspecdb(i)) {
											search1 = true;
											cout << "The system has found DR. " << DB.getusernameddb(i) << " (" << DB.getspecdb(i) << ")" << endl;
											cout << "City: " << DB.getcitydb(i) << endl;
											cout << "Years of Experience: " << DB.getexperiencedb(i) << endl;
											cout << "Hospital: " << DB.gethospitaldb(i) << endl;
											cout << endl;
											cout << "Avialabilty Hours: " << DB.gethoursdb(i) << endl;
											cout << "Consultation charges: " << DB.getchargesdb(i) << endl;
											cout << endl;

											x++;
											array[x] = i;
											cout << "Press " << x << " to book an Appointment with DR. " << DB.getusernameddb(i) << endl << endl;
										}
									}
									if (search1 == true) {
										int choice3;
										cin >> choice3;
										if (choice3 > x || choice3 < 0) {
											cout << "Invalid choice!" << endl;
										}
										else {
											cout << "Appointment booking info for DR. " << DB.getusernameddb(array[choice3]) << " :-" << endl;
											string appointment;
											string a = DB.gethoursdb(array[choice3]);
											int am1 = a[0] - 48;
											int pm1 = a[2] - 48;

											cout << "DR." << DB.getusernameddb(array[choice3]) << " is available from " << am1 << " A.M to " << pm1 << " P.M" << endl;
											t.verifyrepeatedslots(DB, appointment, DB.getusernameddb(array[choice3]));
											cout << "\nEnter hour for appointment: ";
											int hour;
											cin >> hour;
											cout << "1. a.m.\n2. p.m.";
											int ampm;
											cin >> ampm;
											if (ampm == 1) {
												if (hour < am1) {
													cout << "Doctor is not available at this hour" << endl;
												}
												else {
													if (hour == 1) {
														appointment = "1am";
													}
													if (hour == 2) {
														appointment = "2am";
													}
													if (hour == 3) {
														appointment = "3am";
													}
													if (hour == 4) {
														appointment = "4am";
													}
													if (hour == 5) {
														appointment = "5am";
													}
													if (hour == 6) {
														appointment = "6am";
													}
													if (hour == 7) {
														appointment = "7am";
													}
													if (hour == 8) {
														appointment = "8am";
													}
													if (hour == 9) {
														appointment = "9am";
													}
													if (hour == 10) {
														appointment = "10am";
													}
													if (hour == 11) {
														appointment = "11am";
													}
													if (hour == 12) {
														appointment = "12pm";
													}
													if (t.verifyrepeatedapp(DB, appointment, DB.getusernameddb(array[choice3])) == true) {
														cout << "Enter mode for appointment: \n1. Online Rs." << DB.getchargesdb(array[choice3]) - (0.30) * DB.getchargesdb(array[choice3]) << "\n2.Physical Rs." << DB.getchargesdb(array[choice3]) << "\n Enter input : ";
														int choice = 0;
														cin >> choice;
														string appmode;
														if (choice == 1) {
															appmode = "Online";
															DB.takebalancepdb(DB.getbalanceprofile(username1), DB.getchargesdb(array[choice3]) - (0.30) * DB.getchargesdb(array[choice3]));
															DB.setnewbalancepat(DB.getbalanceprofile(username1), DB.getbalancepdb(DB.getbalanceprofile(username1)));
															DB.addbalanceddb(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getchargesdb(array[choice3]) - (0.30) * DB.getchargesdb(array[choice3]));
															DB.setnewbalancedoc(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getbalanceddb(DB.getbalanceprofile(DB.getusernameddb(array[choice3]))));
														}
														if (choice == 2) {
															appmode = "Physical";
															DB.takebalancepdb(DB.getbalanceprofile(username1), DB.getchargesdb(array[choice3]));
															DB.setnewbalancepat(DB.getbalanceprofile(username1), DB.getbalancepdb(DB.getbalanceprofile(username1)));
															DB.addbalanceddb(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getchargesdb(array[choice3]) );
															DB.setnewbalancedoc(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getbalanceddb(DB.getbalanceprofile(DB.getusernameddb(array[choice3]))));
														}
														DB.getappointmentdb(array[choice3]).filehandlingapp("pending", DB.getcnicddb(array[choice3]), DB.getusernameddb(array[choice3]), DB.searchcnic(username1), username1, appmode, appointment);
														cout << "Appointment requested for " << appointment << endl;

													}
													else {
														cout << "Doctor already has an appointment at that time" << endl;
													}
												}
											}
											if (ampm == 2) {
												if (hour > pm1) {
													cout << "Doctor is not available at this hour" << endl;
												}
												else {
													if (hour == 1) {
														appointment = "1pm";
													}
													if (hour == 2) {
														appointment = "2pm";
													}
													if (hour == 3) {
														appointment = "3pm";
													}
													if (hour == 4) {
														appointment = "4pm";
													}
													if (hour == 5) {
														appointment = "5pm";
													}
													if (hour == 6) {
														appointment = "6pm";
													}
													if (hour == 7) {
														appointment = "7pm";
													}
													if (hour == 8) {
														appointment = "8pm";
													}
													if (hour == 9) {
														appointment = "9pm";
													}
													if (hour == 10) {
														appointment = "10pm";
													}
													if (hour == 11) {
														appointment = "11pm";
													}
													if (hour == 12) {
														appointment = "12am";
													}
													if (t.verifyrepeatedapp(DB, appointment, DB.getusernameddb(array[choice3])) == true) {
														cout << "Enter mode for appointment: \n1. Online Rs." << DB.getchargesdb(array[choice3]) - (0.30) * DB.getchargesdb(array[choice3]) << "\n2.Physical Rs." << DB.getchargesdb(array[choice3]) << "\n Enter input : ";
														int choice = 0;
														cin >> choice;
														string appmode;
														if (choice == 1) {
															appmode = "Online";
															DB.takebalancepdb(DB.getbalanceprofile(username1), DB.getchargesdb(array[choice3]) - (0.30) * DB.getchargesdb(array[choice3]));
															DB.setnewbalancepat(DB.getbalanceprofile(username1), DB.getbalancepdb(DB.getbalanceprofile(username1)));
															DB.addbalanceddb(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getchargesdb(array[choice3]) - (0.30) * DB.getchargesdb(array[choice3]));
															DB.setnewbalancedoc(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getbalanceddb(DB.getbalanceprofile(DB.getusernameddb(array[choice3]))));
														}
														if (choice == 2) {
															appmode = "Physical";
															DB.takebalancepdb(DB.getbalanceprofile(username1), DB.getchargesdb(array[choice3]));
															DB.setnewbalancepat(DB.getbalanceprofile(username1), DB.getbalancepdb(DB.getbalanceprofile(username1)));
															DB.addbalanceddb(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getchargesdb(array[choice3]));
															DB.setnewbalancedoc(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getbalanceddb(DB.getbalanceprofile(DB.getusernameddb(array[choice3]))));
														}
														DB.getappointmentdb(array[choice3]).filehandlingapp("pending", DB.getcnicddb(array[choice3]), DB.getusernameddb(array[choice3]), DB.searchcnic(username1), username1, appmode, appointment);
														cout << "Appointment requested for " << appointment << endl;

													}
													else {
														cout << "Doctor already has an appointment at that time" << endl;
													}
												}
											}
										}
									}
									else if (search1 == false) {
										cout << "The system failed to find a Doctor meeting your requirments." << endl;
									}
								}

								if (search == 2) {
									cout << "Enter the city name: ";
									string city;
									cin >> city;
									bool search1 = false;
									int x = 0;
									int array[50];
									for (int i = 0;i < DB.getsizedoc() - 1;i++) {

										if (city == DB.getcitydb(i)) {
											search1 = true;
											cout << "The system has found DR. " << DB.getusernameddb(i) << " (" << DB.getspecdb(i) << ")" << endl;
											cout << "Specialization: " << DB.getspecdb(i) << endl;
											cout << "Years of Experience: " << DB.getexperiencedb(i) << endl;
											cout << "Hospital: " << DB.gethospitaldb(i) << endl;
											cout << endl;
											cout << "Avialabilty Hours: " << DB.gethoursdb(i) << endl;
											cout << "Consultation charges: " << DB.getchargesdb(i) << endl;
											cout << endl;
											x++;
											array[x] = i;
											cout << "Press " << x << " to book an Appointment with DR. " << DB.getusernameddb(i) << endl << endl;
										}
									}
									if (search1 == true) {


										int choice3;
										cin >> choice3;
										if (choice3 > x || choice3 < 0) {
											cout << "Invalid choice!" << endl;
										}
										else {
											cout << "Appointment booking info for DR. " << DB.getusernameddb(array[choice3]) << " :-" << endl;
											string appointment;
											string a = DB.gethoursdb(array[choice3]);
											int am1 = a[0] - 48;
											int pm1 = a[2] - 48;

											cout << "DR." << DB.getusernameddb(array[choice3]) << " is available from " << am1 << " A.M to " << pm1 << " P.M" << endl;
											t.verifyrepeatedslots(DB, appointment, DB.getusernameddb(array[choice3]));
											cout << "\nEnter hour for appointment: ";
											int hour;
											cin >> hour;
											cout << "1. a.m.\n2. p.m.";
											int ampm;
											cin >> ampm;
											if (ampm == 1) {
												if (hour < am1) {
													cout << "Doctor is not available at this hour" << endl;
												}
												else {
													if (hour == 1) {
														appointment = "1am";
													}
													if (hour == 2) {
														appointment = "2am";
													}
													if (hour == 3) {
														appointment = "3am";
													}
													if (hour == 4) {
														appointment = "4am";
													}
													if (hour == 5) {
														appointment = "5am";
													}
													if (hour == 6) {
														appointment = "6am";
													}
													if (hour == 7) {
														appointment = "7am";
													}
													if (hour == 8) {
														appointment = "8am";
													}
													if (hour == 9) {
														appointment = "9am";
													}
													if (hour == 10) {
														appointment = "10am";
													}
													if (hour == 11) {
														appointment = "11am";
													}
													if (hour == 12) {
														appointment = "12pm";
													}
													if (t.verifyrepeatedapp(DB, appointment, DB.getusernameddb(array[choice3])) == true) {
														cout << "Enter mode for appointment: \n1. Online Rs." << DB.getchargesdb(array[choice3]) - (0.30) * DB.getchargesdb(array[choice3]) << "\n2.Physical Rs." << DB.getchargesdb(array[choice3]) << "\n Enter input : ";
														int choice = 0;
														cin >> choice;
														string appmode;
														if (choice == 1) {
															appmode = "Online";
															DB.takebalancepdb(DB.getbalanceprofile(username1), DB.getchargesdb(array[choice3]) - (0.30) * DB.getchargesdb(array[choice3]));
															DB.setnewbalancepat(DB.getbalanceprofile(username1), DB.getbalancepdb(DB.getbalanceprofile(username1)));
															DB.addbalanceddb(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getchargesdb(array[choice3]) - (0.30) * DB.getchargesdb(array[choice3]));
															DB.setnewbalancedoc(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getbalanceddb(DB.getbalanceprofile(DB.getusernameddb(array[choice3]))));
														}
														if (choice == 2) {
															appmode = "Physical";
															DB.takebalancepdb(DB.getbalanceprofile(username1), DB.getchargesdb(array[choice3]));
															DB.setnewbalancepat(DB.getbalanceprofile(username1), DB.getbalancepdb(DB.getbalanceprofile(username1)));
															DB.addbalanceddb(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getchargesdb(array[choice3]));
															DB.setnewbalancedoc(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getbalanceddb(DB.getbalanceprofile(DB.getusernameddb(array[choice3]))));
														}
														DB.getappointmentdb(array[choice3]).filehandlingapp("pending", DB.getcnicddb(array[choice3]), DB.getusernameddb(array[choice3]), DB.searchcnic(username1), username1, appmode, appointment);
														cout << "Appointment requested for " << appointment << endl;

													}
													else {
														cout << "Doctor already has an appointment at that time" << endl;
													}
												}
											}
											if (ampm == 2) {
												if (hour > pm1) {
													cout << "Doctor is not available at this hour" << endl;
												}
												else {
													if (hour == 1) {
														appointment = "1pm";
													}
													if (hour == 2) {
														appointment = "2pm";
													}
													if (hour == 3) {
														appointment = "3pm";
													}
													if (hour == 4) {
														appointment = "4pm";
													}
													if (hour == 5) {
														appointment = "5pm";
													}
													if (hour == 6) {
														appointment = "6pm";
													}
													if (hour == 7) {
														appointment = "7pm";
													}
													if (hour == 8) {
														appointment = "8pm";
													}
													if (hour == 9) {
														appointment = "9pm";
													}
													if (hour == 10) {
														appointment = "10pm";
													}
													if (hour == 11) {
														appointment = "11pm";
													}
													if (hour == 12) {
														appointment = "12am";
													}
													if (t.verifyrepeatedapp(DB, appointment, DB.getusernameddb(array[choice3])) == true) {
														cout << "Enter mode for appointment: \n1. Online Rs." << DB.getchargesdb(array[choice3]) - (0.30) * DB.getchargesdb(array[choice3]) << "\n2.Physical Rs." << DB.getchargesdb(array[choice3]) << "\n Enter input : ";
														int choice = 0;
														cin >> choice;
														string appmode;
														if (choice == 1) {
															appmode = "Online";
															DB.takebalancepdb(DB.getbalanceprofile(username1), DB.getchargesdb(array[choice3]) - (0.30) * DB.getchargesdb(array[choice3]));
															DB.setnewbalancepat(DB.getbalanceprofile(username1), DB.getbalancepdb(DB.getbalanceprofile(username1)));
															DB.addbalanceddb(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getchargesdb(array[choice3]) - (0.30) * DB.getchargesdb(array[choice3]));
															DB.setnewbalancedoc(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getbalanceddb(DB.getbalanceprofile(DB.getusernameddb(array[choice3]))));
														}
														if (choice == 2) {
															appmode = "Physical";
															DB.takebalancepdb(DB.getbalanceprofile(username1), DB.getchargesdb(array[choice3]));
															DB.setnewbalancepat(DB.getbalanceprofile(username1), DB.getbalancepdb(DB.getbalanceprofile(username1)));
															DB.addbalanceddb(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getchargesdb(array[choice3]));
															DB.setnewbalancedoc(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getbalanceddb(DB.getbalanceprofile(DB.getusernameddb(array[choice3]))));
														}
														DB.getappointmentdb(array[choice3]).filehandlingapp("pending", DB.getcnicddb(array[choice3]), DB.getusernameddb(array[choice3]), DB.searchcnic(username1), username1, appmode, appointment);
														cout << "Appointment requested for " << appointment << endl;

													}
													else {
														cout << "Doctor already has an appointment at that time" << endl;
													}
												}
											}
										}
									}
									else if (search1 == false) {
										cout << "The system failed to find a Doctor meeting your requirments." << endl;
									}
								}
								if (search == 3) {
									cout << "Enter the Hospital name: ";
									string city;
									cin >> city;
									bool search1 = false;
									int x = 0;
									int array[50];
									for (int i = 0;i < DB.getsizedoc() - 1;i++) {

										if (city == DB.gethospitaldb(i)) {
											search1 = true;
											cout << "The system has found DR. " << DB.getusernameddb(i) << " (" << DB.getspecdb(i) << ")" << endl;
											cout << "Years of Experience: " << DB.getexperiencedb(i) << endl;
											cout << "Hospital: " << DB.gethospitaldb(i) << endl;
											cout << endl;
											cout << "Avialabilty Hours: " << DB.gethoursdb(i) << endl;
											cout << "Consultation charges: " << DB.getchargesdb(i) << endl;
											cout << endl;

											x++;
											array[x] = i;
											cout << "Press " << x << " to book an Appointment with DR. " << DB.getusernameddb(i) << endl << endl;
										}
									}
									if (search1 == true) {
										int choice3;
										cin >> choice3;
										if (choice3 > x || choice3 < 0) {
											cout << "Invalid choice!" << endl;
										}
										else {
											cout << "Appointment booking info for DR. " << DB.getusernameddb(array[choice3]) << " :-" << endl;
											string appointment;
											string a = DB.gethoursdb(array[choice3]);
											int am1 = a[0] - 48;
											int pm1 = a[2] - 48;

											cout << "DR." << DB.getusernameddb(array[choice3]) << " is available from " << am1 << " A.M to " << pm1 << " P.M" << endl;
											t.verifyrepeatedslots(DB, appointment, DB.getusernameddb(array[choice3]));
											cout << "\nEnter hour for appointment: ";
											int hour;
											cin >> hour;
											cout << "1. a.m.\n2. p.m.";
											int ampm;
											cin >> ampm;
											if (ampm == 1) {
												if (hour < am1) {
													cout << "Doctor is not available at this hour" << endl;
												}
												else {
													if (hour == 1) {
														appointment = "1am";
													}
													if (hour == 2) {
														appointment = "2am";
													}
													if (hour == 3) {
														appointment = "3am";
													}
													if (hour == 4) {
														appointment = "4am";
													}
													if (hour == 5) {
														appointment = "5am";
													}
													if (hour == 6) {
														appointment = "6am";
													}
													if (hour == 7) {
														appointment = "7am";
													}
													if (hour == 8) {
														appointment = "8am";
													}
													if (hour == 9) {
														appointment = "9am";
													}
													if (hour == 10) {
														appointment = "10am";
													}
													if (hour == 11) {
														appointment = "11am";
													}
													if (hour == 12) {
														appointment = "12pm";
													}
													if (t.verifyrepeatedapp(DB, appointment, DB.getusernameddb(array[choice3])) == true) {
														cout << "Enter mode for appointment: \n1. Online Rs." << DB.getchargesdb(array[choice3]) - (0.30) * DB.getchargesdb(array[choice3]) << "\n2.Physical Rs." << DB.getchargesdb(array[choice3]) << "\n Enter input : ";
														int choice = 0;
														cin >> choice;
														string appmode;
														if (choice == 1) {
															appmode = "Online";
															DB.takebalancepdb(DB.getbalanceprofile(username1), DB.getchargesdb(array[choice3]) - (0.30) * DB.getchargesdb(array[choice3]));
															DB.setnewbalancepat(DB.getbalanceprofile(username1), DB.getbalancepdb(DB.getbalanceprofile(username1)));
															DB.addbalanceddb(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getchargesdb(array[choice3]) - (0.30) * DB.getchargesdb(array[choice3]));
															DB.setnewbalancedoc(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getbalanceddb(DB.getbalanceprofile(DB.getusernameddb(array[choice3]))));
														}
														if (choice == 2) {
															appmode = "Physical";
															DB.takebalancepdb(DB.getbalanceprofile(username1), DB.getchargesdb(array[choice3]));
															DB.setnewbalancepat(DB.getbalanceprofile(username1), DB.getbalancepdb(DB.getbalanceprofile(username1)));
															DB.addbalanceddb(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getchargesdb(array[choice3]));
															DB.setnewbalancedoc(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getbalanceddb(DB.getbalanceprofile(DB.getusernameddb(array[choice3]))));
														}
														DB.getappointmentdb(array[choice3]).filehandlingapp("pending", DB.getcnicddb(array[choice3]), DB.getusernameddb(array[choice3]), DB.searchcnic(username1), username1, appmode, appointment);
														cout << "Appointment requested for " << appointment << endl;

													}
													else {
														cout << "Doctor already has an appointment at that time" << endl;
													}
												}
											}
											if (ampm == 2) {
												if (hour > pm1) {
													cout << "Doctor is not available at this hour" << endl;
												}
												else {
													if (hour == 1) {
														appointment = "1pm";
													}
													if (hour == 2) {
														appointment = "2pm";
													}
													if (hour == 3) {
														appointment = "3pm";
													}
													if (hour == 4) {
														appointment = "4pm";
													}
													if (hour == 5) {
														appointment = "5pm";
													}
													if (hour == 6) {
														appointment = "6pm";
													}
													if (hour == 7) {
														appointment = "7pm";
													}
													if (hour == 8) {
														appointment = "8pm";
													}
													if (hour == 9) {
														appointment = "9pm";
													}
													if (hour == 10) {
														appointment = "10pm";
													}
													if (hour == 11) {
														appointment = "11pm";
													}
													if (hour == 12) {
														appointment = "12am";
													}
													if (t.verifyrepeatedapp(DB, appointment, DB.getusernameddb(array[choice3])) == true) {
														cout << "Enter mode for appointment: \n1. Online Rs." << DB.getchargesdb(array[choice3]) - (0.30) * DB.getchargesdb(array[choice3]) << "\n2.Physical Rs." << DB.getchargesdb(array[choice3]) << "\n Enter input : ";
														int choice = 0;
														cin >> choice;
														string appmode;
														if (choice == 1) {
															appmode = "Online";
															DB.takebalancepdb(DB.getbalanceprofile(username1), DB.getchargesdb(array[choice3]) - (0.30) * DB.getchargesdb(array[choice3]));
															DB.setnewbalancepat(DB.getbalanceprofile(username1), DB.getbalancepdb(DB.getbalanceprofile(username1)));
															DB.addbalanceddb(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getchargesdb(array[choice3]) - (0.30) * DB.getchargesdb(array[choice3]));
															DB.setnewbalancedoc(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getbalanceddb(DB.getbalanceprofile(DB.getusernameddb(array[choice3]))));
														}
														if (choice == 2) {
															appmode = "Physical";
															DB.takebalancepdb(DB.getbalanceprofile(username1), DB.getchargesdb(array[choice3]));
															DB.setnewbalancepat(DB.getbalanceprofile(username1), DB.getbalancepdb(DB.getbalanceprofile(username1)));
															DB.addbalanceddb(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getchargesdb(array[choice3]));
															DB.setnewbalancedoc(DB.getbalanceprofiledoc(DB.getusernameddb(array[choice3])), DB.getbalanceddb(DB.getbalanceprofile(DB.getusernameddb(array[choice3]))));
														}
														DB.getappointmentdb(array[choice3]).filehandlingapp("pending", DB.getcnicddb(array[choice3]), DB.getusernameddb(array[choice3]), DB.searchcnic(username1), username1, appmode, appointment);
														cout << "Appointment requested for " << appointment << endl;

													}
													else {
														cout << "Doctor already has an appointment at that time" << endl;
													}
												}
											}




										}
									}
									else if (search1 == false) {
										cout << "The system failed to find a Doctor meeting your requirments." << endl;
									}
								}

							}
							else if (choice == 3) {
								system("CLS");
								string cnic;
								string email;
								string username;
								cout << "Enter new CNIC: ";
								cin >> cnic;
								if (t.verifyvalidcnic(cnic) == 0) {
									while (t.verifyvalidcnic(cnic) == 0) {
										cnic = '\0';
										cout << "Enter Valid CNIC (13 digit)" << endl;
										cin >> cnic;
									}
								}
								if (t.verifyrepeatedcnic(DB, cnic, choice1) == 0) {
									while (t.verifyrepeatedcnic(DB, cnic, choice1) == 0) {
										cnic = '\0';
										cout << "Enter non Repeated CNIC" << endl;
										cin >> cnic;
									}
								}
								cout << "Enter new E-mail: ";
								cin >> email;
								if (t.verifyrepeatedemail(DB, email, choice1) == 0) {
									while (t.verifyrepeatedemail(DB, email, choice1) == 0) {
										email = '\0';
										cout << "Enter non Repeated email" << endl;
										cin >> email;
									}
								}
								cout << "Enter a new username: ";
								cin >> username;
								DB.setnewstuffdb(logintoken.loginverification(username1, password1, choice1), cnic, email, username);
								DB.databasestorepat();
							}
							else if (choice == 5) {
								t.showappointments(DB, username1);
							}
							else if (choice == 6) {
								t.showfeedback(DB, username1);
							}
						
							else if (choice == 4) {
								cout << "Choose a payment method for recharging account: 1. Easypaisa\n2. Jazzcash\n3. Paypak\n4. Unionpay\5. Bank Transfer";
								cout << "\nEnter a choice: ";
								int paychoice = 0;
								cin >> paychoice;
								if (paychoice > 0 && paychoice < 3) {
									cout << "0323111111128 is our phone number for Jazzcash and Easypaisa\nPlease tell us how much money you're despositing for verification: ";
									int amount = 0;
									cin >> amount;
									DB.addbalancepdb(DB.getbalanceprofile(username1), amount);
									DB.setnewbalancepat(DB.getbalanceprofile(username1), DB.getbalancepdb(DB.getbalanceprofile(username1)));
								}
								else if (paychoice == 5) {
									cout << "111 128 128 is out BAN for Bank Transfer\nPlease tell us how much money you're despositing for verification: ";
									int amount = 0;
									cin >> amount;
									DB.addbalancepdb(DB.getbalanceprofile(username1), amount);
									DB.setnewbalancepat(DB.getbalanceprofile(username1), DB.getbalancepdb(DB.getbalanceprofile(username1)));
								}
								else if (paychoice == 4 || paychoice == 3) {
									cout << "111 128 128 is out ID for Unionpay and Paypak\nPlease tell us how much money you're despositing for verification: ";
									int amount = 0;
									cin >> amount;
									DB.addbalancepdb(DB.getbalanceprofile(username1), amount);
									DB.setnewbalancepat(DB.getbalanceprofile(username1), DB.getbalancepdb(DB.getbalanceprofile(username1)));
								}
							}
							else if (choice == 7) {
							DB.databasestoredoc();
							DB.databasestorepat();
							DB.databasestoreapp();

							system("CLS");
							k = 1;
}
						}
					}
				}
			}
		}




















		else if (opt0 == 2) {
			string cnic;
			string email;
			string password;
			string username;
			cout << "Register as a: \n1.Doctor\n2.Patient" << endl;
			int choice1 = 0;
			cin >> choice1;
			cout << "Enter CNIC for registration: ";
			cin >> cnic;
			if (t.verifyvalidcnic(cnic) == 0) {
				while (t.verifyvalidcnic(cnic) == 0) {
					cnic = '\0';
					cout << "Enter Valid CNIC (13 digit)" << endl;
					cin >> cnic;
				}
			}
			if (t.verifyrepeatedcnic(DB, cnic, choice1) == 0) {
				while (t.verifyrepeatedcnic(DB, cnic, choice1) == 0) {
					cnic = '\0';
					cout << "Enter non Repeated CNIC" << endl;
					cin >> cnic;
				}
			}
			cout << "Enter E-mail for registration: ";
			cin >> email;
			if (t.verifyrepeatedemail(DB, email, choice1) == 0) {
				while (t.verifyrepeatedemail(DB, email, choice1) == 0) {
					email = '\0';
					cout << "Enter non Repeated email" << endl;
					cin >> email;
				}
			}
			cout << "Enter password for registration: ";
			cin >> password;

			while (t.verifypassword(password) == 0) {
				password = '\0';
				cout << "Enter Valid password: ";
				cin >> password;
			}
			cout << "Enter a username: ";
			cin >> username;
			if (choice1 == 1) {
				string specialization;
				string experiencetime;
				string hospitalname;
				string city;
				string avlhours;
				int charges;
				int opt2 = 0;
				cout << "Choose Your Specialization" << endl;
				cout << "1. Gynecologist\n2. Dermatologist\n3. Oncologist\n4. Orthopedic" << endl;
				cin >> opt2;
				if (opt2 == 1) {
					specialization = "Gynecologist";
				}
				else if (opt2 == 2) {
					specialization = "Dermatologist";
				}
				else if (opt2 == 3) {
					specialization = "Oncologist";
				}
				else if (opt2 == 4) {
					specialization = "Orthopedic";
				}
				else if (opt2 > 4) {
					cout << "Enter a valid choice!" << endl;
				}
				cout << "Please enter your years of experience: ";
				cin >> experiencetime;
				cout << "Please enter your city: ";
				cin >> city;
				cout << "Please enter your Hospital: ";
				cin >> hospitalname;
				cout << "Please enter your availability hours (Format: Number-Number): ";
				cin >> avlhours;
				cout << "Enter your charges: ";
					cin >> charges;
				Doctorattributes doc(specialization, experiencetime, city, hospitalname, avlhours, charges);
				string usertype = "Doctor";
				Doctor user(usertype, cnic, email, username, password,0, doc);
				user.filehandlingdoc();
				DB.databasestoredoc();
				cout << endl << "---------------------" << endl;

			}
			else if (choice1 == 2) {
				string usertype = "Patient";
				Patient user(usertype, cnic, email, username, password,3500);
				user.filehandlingpat();

				DB.databasestorepat();
				cout << endl << "---------------------" << endl;
			}
		}
		else if (opt0 > 2) {
		cout << "Enter a valid choice" << endl<<endl;
}
	}
return 0;
}