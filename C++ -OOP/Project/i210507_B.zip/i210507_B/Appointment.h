#pragma once
#include<iostream>
using namespace std;
class Appointment {
public:
	string status, docid, docname, patid, patname, appmode, apptime;
	int appointmentstatus;
	int appno;
	Appointment();
	Appointment(string, string, string, string, string, string, string);
	void setappointment(string);
	void rejectappointment(string);
	void filehandlingapp(string , string , string , string , string , string , string );
};