#pragma once
#include<iostream>
using namespace std;
class Patient :public Register {
public:
	Patient();
	Patient(string usertype1, string cnic1, string email1, string username1, string password1, int balance1);

	void filehandlingpat();
	string getcnic() const;
	string getemail() const;
	string getusername() const;
	string getusertype() const;
	string getpassword() const;
	void setcnic(string cnic1);
	void setemail(string cnic1);
	void setusername(string cnic1);
	void setpassword(string cnic1);
	void addbalance(int x);
	void takebalance(int x);
	int getbalance() const;
	void setbalance(int x);
};
