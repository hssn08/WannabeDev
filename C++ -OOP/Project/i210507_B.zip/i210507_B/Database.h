#pragma once
#include<iostream>
#include"Appointment.h"
#include"Doctor.h"
#include"Patient.h"
#include<fstream>
class Database {
	Doctor* databasedoc;
	Patient* databasepat;
	Appointment* databaseapp;
	int sizeapp;
	int sizedoc;
	int sizepat;
public:
	Database() {
		databasedoc = new Doctor[200];
		databasepat = new Patient[200];
		databaseapp = new Appointment[200];
		sizedoc = 0;
		sizepat = 0;
		sizeapp = 0;
	}
	void databasestoreapp() {
		ifstream appread;
		appread.open("app.txt");
		string status, docid, docname, patid, patname, appmode, apptime;
		int i = 0;
		while (appread) {
			appread >> status;

			appread >> docid;

			appread >> docname;

			appread >> patid;

			appread >> patname;

			appread >> appmode;

			appread >> apptime;

			Appointment x(status, docid, docname, patid, patname, appmode, apptime);
			databaseapp[i] = x;
			i++;
			sizeapp = i;
		}
		appread.close();
	}
	string getstatusadb(int index) const {
		return databaseapp[index].status;
	}
	string getdocidadb(int index) const {
		return databaseapp[index].docid;
	}
	string getdocnameadb(int index) const {
		return databaseapp[index].docname;
	}
	string getpatidadb(int index) const {
		return databaseapp[index].patid;
	}
	string getpatnameadb(int index) const {
		return databaseapp[index].patname;
	}
	string getappmodeadb(int index) const {
		return databaseapp[index].appmode;
	}
	string getapptimeadb(int index) const {
		return databaseapp[index].apptime;
	}
	void databasestorepat() {
		ifstream doctorread;
		doctorread.open("pat.txt");
		string usertype;
		string cnic;
		string email;
		string password;
		string username;
		int balance;
		int i = 0;
		while (!doctorread.eof()) {
			doctorread >> usertype;

			doctorread >> cnic;
			doctorread >> email;
			doctorread >> password;
			doctorread >> username;
			doctorread >> balance;

			Patient x(usertype, cnic, email, username, password, balance);
			databasepat[i] = x;
			i++;
			sizepat = i;
		}
	}
	void databasestoredoc() {
		ifstream doctorread;
		doctorread.open("doc.txt");
		string usertype;
		string cnic;
		string email;
		string password;
		string username;
		string specialization;
		string experiencetime;
		string hospitalname;
		string city;
		string avlhours;
		int balance;
		int charges;
		int i = 0;
		while (doctorread) {
			doctorread >> usertype;
			doctorread >> cnic;
			doctorread >> email;
			doctorread >> password;
			doctorread >> username;
			doctorread >> specialization;
			doctorread >> experiencetime;
			doctorread >> hospitalname;
			doctorread >> city;
			doctorread >> avlhours;
			doctorread >> charges;
			doctorread >> balance;

			Doctorattributes doc(specialization, experiencetime, city, hospitalname, avlhours, charges);
			Doctor x(usertype, cnic, email, username, password, balance, doc);
			databasedoc[i] = x;
			i++;
			sizedoc = i;
		}
		doctorread.close();
	}
	void setpassworddb(int index, string newpass1) {
		databasepat[index].setpassword(newpass1);
		ofstream doctorwrite;
		doctorwrite.open("pat.txt");
		for (int i = 0;i < index;i++) {
			doctorwrite << databasepat[i].getusertype() << endl;
			doctorwrite << databasepat[i].getcnic() << endl;
			doctorwrite << databasepat[i].getemail() << endl;
			doctorwrite << databasepat[i].getpassword() << endl;
			doctorwrite << databasepat[i].getusername() << endl;
			doctorwrite << databasepat[i].getbalance() << endl;
		}
		doctorwrite << databasepat[index].getusertype() << endl;
		doctorwrite << databasepat[index].getcnic() << endl;
		doctorwrite << databasepat[index].getemail() << endl;
		doctorwrite << databasepat[index].getpassword() << endl;
		doctorwrite << databasepat[index].getusername() << endl;
		doctorwrite << databasepat[index].getbalance() << endl;

		for (int i = index + 1;i < sizepat - 1;i++) {
			doctorwrite << databasepat[i].getusertype() << endl;
			doctorwrite << databasepat[i].getcnic() << endl;
			doctorwrite << databasepat[i].getemail() << endl;
			doctorwrite << databasepat[i].getpassword() << endl;
			doctorwrite << databasepat[i].getusername() << endl;
			doctorwrite << databasepat[i].getbalance() << endl;
		}
		doctorwrite.close();
	}


	void setnewbalancepat(int index, int balance) {
		databasepat[index].setbalance(balance);
		ofstream doctorwrite;
		doctorwrite.open("pat.txt");
		for (int i = 0;i < index;i++) {
			doctorwrite << databasepat[i].getusertype() << endl;
			doctorwrite << databasepat[i].getcnic() << endl;
			doctorwrite << databasepat[i].getemail() << endl;
			doctorwrite << databasepat[i].getpassword() << endl;
			doctorwrite << databasepat[i].getusername() << endl;
			doctorwrite << databasepat[i].getbalance() << endl;
		}
		doctorwrite << databasepat[index].getusertype() << endl;
		doctorwrite << databasepat[index].getcnic() << endl;
		doctorwrite << databasepat[index].getemail() << endl;
		doctorwrite << databasepat[index].getpassword() << endl;
		doctorwrite << databasepat[index].getusername() << endl;
		doctorwrite << databasepat[index].getbalance() << endl;

		for (int i = index + 1;i < sizepat - 1;i++) {
			doctorwrite << databasepat[i].getusertype() << endl;
			doctorwrite << databasepat[i].getcnic() << endl;
			doctorwrite << databasepat[i].getemail() << endl;
			doctorwrite << databasepat[i].getpassword() << endl;
			doctorwrite << databasepat[i].getusername() << endl;
			doctorwrite << databasepat[i].getbalance() << endl;
		}
		doctorwrite.close();
	}





	void setnewbalancedoc(int index, int balance) {
		databasepat[index].setbalance(balance);
		ofstream doctorwrite;
		doctorwrite.open("doc.txt");
		for (int i = 0;i < index;i++) {
			doctorwrite << databasedoc[i].getusertype() << endl;
			doctorwrite << databasedoc[i].getcnic() << endl;
			doctorwrite << databasedoc[i].getemail() << endl;
			doctorwrite << databasedoc[i].getpassword() << endl;
			doctorwrite << databasedoc[i].getusername() << endl;
			doctorwrite << databasedoc[i].getspecialization() << endl;
			doctorwrite << databasedoc[i].getexp() << endl;
			doctorwrite << databasedoc[i].gethospital() << endl;
			doctorwrite << databasedoc[i].getcity() << endl;
			doctorwrite << databasedoc[i].gethours() << endl;
			doctorwrite << databasedoc[i].getcharges() << endl;
			doctorwrite << databasedoc[i].getbalance() << endl;
		}
		doctorwrite << databasedoc[index].getusertype() << endl;
		doctorwrite << databasedoc[index].getcnic() << endl;
		doctorwrite << databasedoc[index].getemail() << endl;
		doctorwrite << databasedoc[index].getpassword() << endl;
		doctorwrite << databasedoc[index].getusername() << endl;
		doctorwrite << databasedoc[index].getspecialization() << endl;
		doctorwrite << databasedoc[index].getexp() << endl;
		doctorwrite << databasedoc[index].gethospital() << endl;
		doctorwrite << databasedoc[index].getcity() << endl;
		doctorwrite << databasedoc[index].gethours() << endl;
		doctorwrite << databasedoc[index].getcharges() << endl;
		doctorwrite << databasedoc[index].getbalance() << endl;
		for (int i = index + 1;i < sizedoc - 1;i++) {
			doctorwrite << databasedoc[i].getusertype() << endl;
			doctorwrite << databasedoc[i].getcnic() << endl;
			doctorwrite << databasedoc[i].getemail() << endl;
			doctorwrite << databasedoc[i].getpassword() << endl;
			doctorwrite << databasedoc[i].getusername() << endl;
			doctorwrite << databasedoc[i].getspecialization() << endl;
			doctorwrite << databasedoc[i].getexp() << endl;
			doctorwrite << databasedoc[i].gethospital() << endl;
			doctorwrite << databasedoc[i].getcity() << endl;
			doctorwrite << databasedoc[i].gethours() << endl;
			doctorwrite << databasedoc[i].getcharges() << endl;
			doctorwrite << databasedoc[i].getbalance() << endl;
		}
		doctorwrite.close();
	}









	void cancelappointment(int index) {
		int p = 0;
		if (databaseapp[index].appmode == "Physical") {
			for (int i = 0;i < sizedoc;i++) {
				if (databaseapp[index].docname == databasedoc[i].getusername()) {
					databasedoc[i].takebalance(databasedoc[i].getcharges());
					setnewbalancedoc(i, databasedoc[i].getbalance());
					p = i;
					i = sizedoc;
				}
			}
			for (int i = 0;i < sizepat;i++) {
				if (databaseapp[index].patname == databasepat[i].getusername()) {
					databasepat[i].addbalance(databasedoc[p].getcharges());
					setnewbalancepat(i, databasepat[i].getbalance());
					i = sizedoc;
				}
			}
		}
		if (databaseapp[index].appmode == "Online") {
			for (int i = 0;i < sizedoc;i++) {
				if (databaseapp[index].docname == databasedoc[i].getusername()) {
					databasedoc[i].takebalance(0.70 * (databasedoc[i].getcharges()));
					setnewbalancedoc(i, databasedoc[i].getbalance());
					p = i;
					i = sizedoc;
				}
			}
			for (int i = 0;i < sizepat;i++) {
				if (databaseapp[index].patname == databasepat[i].getusername()) {
					databasepat[i].addbalance(0.70 * (databasedoc[p].getcharges()));
					setnewbalancepat(i, databasepat[i].getbalance());
					i = sizedoc;
				}
			}
		}


		databaseapp[index].status = '\0';
		databaseapp[index].docid = '\0';
		databaseapp[index].docname = '\0';
		databaseapp[index].patid = '\0';
		databaseapp[index].patname = '\0';
		databaseapp[index].appmode = '\0';
		databaseapp[index].apptime = '\0';
		ofstream appwrite;
		appwrite.open("app.txt");
		for (int i = 0;i < index;i++) {
			appwrite << databaseapp[i].status << endl;
			appwrite << databaseapp[i].docid << endl;
			appwrite << databaseapp[i].docname << endl;
			appwrite << databaseapp[i].patid << endl;
			appwrite << databaseapp[i].patname << endl;
			appwrite << databaseapp[i].appmode << endl;
			appwrite << databaseapp[i].apptime << endl;
		}
		for (int i = index + 1;i < sizeapp - 1;i++) {
			appwrite << databaseapp[i].status << endl;
			appwrite << databaseapp[i].docid << endl;
			appwrite << databaseapp[i].docname << endl;
			appwrite << databaseapp[i].patid << endl;
			appwrite << databaseapp[i].patname << endl;
			appwrite << databaseapp[i].appmode << endl;
			appwrite << databaseapp[i].apptime << endl;
		}
		sizeapp -= 1;
		appwrite.close();
	}
	void approveappointment(int index) {
		databaseapp[index].status = "approved";
		ofstream appwrite;
		appwrite.open("app.txt");
		for (int i = 0;i < index;i++) {
			appwrite << databaseapp[i].status << endl;
			appwrite << databaseapp[i].docid << endl;
			appwrite << databaseapp[i].docname << endl;
			appwrite << databaseapp[i].patid << endl;
			appwrite << databaseapp[i].patname << endl;
			appwrite << databaseapp[i].appmode << endl;
			appwrite << databaseapp[i].apptime << endl;
		}
		appwrite << databaseapp[index].status << endl;
		appwrite << databaseapp[index].docid << endl;
		appwrite << databaseapp[index].docname << endl;
		appwrite << databaseapp[index].patid << endl;
		appwrite << databaseapp[index].patname << endl;
		appwrite << databaseapp[index].appmode << endl;
		appwrite << databaseapp[index].apptime << endl;
		for (int i = index + 1;i < sizeapp - 1;i++) {
			appwrite << databaseapp[i].status << endl;
			appwrite << databaseapp[i].docid << endl;
			appwrite << databaseapp[i].docname << endl;
			appwrite << databaseapp[i].patid << endl;
			appwrite << databaseapp[i].patname << endl;
			appwrite << databaseapp[i].appmode << endl;
			appwrite << databaseapp[i].apptime << endl;
		}
		sizeapp -= 1;
		appwrite.close();
	}






	void setnewstuffdb(int index, string newcnic, string newemail, string newusername) {
		databasepat[index].setcnic(newcnic);
		databasepat[index].setemail(newemail);
		databasepat[index].setusername(newusername);
		ofstream doctorwrite;
		doctorwrite.open("pat.txt");
		for (int i = 0;i < index;i++) {
			doctorwrite << databasepat[i].getusertype() << endl;
			doctorwrite << databasepat[i].getcnic() << endl;
			doctorwrite << databasepat[i].getemail() << endl;
			doctorwrite << databasepat[i].getpassword() << endl;
			doctorwrite << databasepat[i].getusername() << endl;
			doctorwrite << databasepat[i].getbalance() << endl;
		}
		doctorwrite << databasepat[index].getusertype() << endl;
		doctorwrite << databasepat[index].getcnic() << endl;
		doctorwrite << databasepat[index].getemail() << endl;
		doctorwrite << databasepat[index].getpassword() << endl;
		doctorwrite << databasepat[index].getusername() << endl;
		doctorwrite << databasepat[index].getbalance() << endl;

		for (int i = index + 1;i < sizepat - 1;i++) {
			doctorwrite << databasepat[i].getusertype() << endl;
			doctorwrite << databasepat[i].getcnic() << endl;
			doctorwrite << databasepat[i].getemail() << endl;
			doctorwrite << databasepat[i].getpassword() << endl;
			doctorwrite << databasepat[i].getusername() << endl;
			doctorwrite << databasepat[i].getbalance() << endl;
		}
		doctorwrite.close();
	}









	void setnewstuffddb(int index, string newcnic, string newemail, string newusername, string newavlhours, string newcity, int newcharges) {
		databasedoc[index].setcnic(newcnic);
		databasedoc[index].setemail(newemail);
		databasedoc[index].setusername(newusername);
		databasedoc[index].setavlhours(newavlhours);
		databasedoc[index].setcity(newcity);
		databasedoc[index].setcharges(newcharges);
		ofstream doctorwrite;
		doctorwrite.open("doc.txt");
		for (int i = 0;i < index;i++) {
			doctorwrite << databasedoc[i].getusertype() << endl;
			doctorwrite << databasedoc[i].getcnic() << endl;
			doctorwrite << databasedoc[i].getemail() << endl;
			doctorwrite << databasedoc[i].getpassword() << endl;
			doctorwrite << databasedoc[i].getusername() << endl;
			doctorwrite << databasedoc[i].getspecialization() << endl;
			doctorwrite << databasedoc[i].getexp() << endl;
			doctorwrite << databasedoc[i].gethospital() << endl;
			doctorwrite << databasedoc[i].getcity() << endl;
			doctorwrite << databasedoc[i].gethours() << endl;
			doctorwrite << databasedoc[i].getcharges() << endl;
			doctorwrite << databasedoc[i].getbalance() << endl;
		}
		doctorwrite << databasedoc[index].getusertype() << endl;
		doctorwrite << databasedoc[index].getcnic() << endl;
		doctorwrite << databasedoc[index].getemail() << endl;
		doctorwrite << databasedoc[index].getpassword() << endl;
		doctorwrite << databasedoc[index].getusername() << endl;
		doctorwrite << databasedoc[index].getspecialization() << endl;
		doctorwrite << databasedoc[index].getexp() << endl;
		doctorwrite << databasedoc[index].gethospital() << endl;
		doctorwrite << databasedoc[index].getcity() << endl;
		doctorwrite << databasedoc[index].gethours() << endl;
		doctorwrite << databasedoc[index].getcharges() << endl;
		doctorwrite << databasedoc[index].getbalance() << endl;
		for (int i = index + 1;i < sizedoc - 1;i++) {
			doctorwrite << databasedoc[i].getusertype() << endl;
			doctorwrite << databasedoc[i].getcnic() << endl;
			doctorwrite << databasedoc[i].getemail() << endl;
			doctorwrite << databasedoc[i].getpassword() << endl;
			doctorwrite << databasedoc[i].getusername() << endl;
			doctorwrite << databasedoc[i].getspecialization() << endl;
			doctorwrite << databasedoc[i].getexp() << endl;
			doctorwrite << databasedoc[i].gethospital() << endl;
			doctorwrite << databasedoc[i].getcity() << endl;
			doctorwrite << databasedoc[i].gethours() << endl;
			doctorwrite << databasedoc[i].getcharges() << endl;
			doctorwrite << databasedoc[i].getbalance() << endl;
		}
		doctorwrite.close();
	}





	string getcnicpdb(int index) const {
		return databasepat[index].getcnic();
	}
	string getusernamepdb(int index) const {
		return databasepat[index].getusername();
	}
	string getpasswordpdb(int index) const {
		return databasepat[index].getpassword();
	}
	string getemailpdb(int index) const {
		return databasepat[index].getemail();
	}
	string gettypepdb(int index) const {
		return databasepat[index].getusertype();
	}
	string searchcnic(string username) {
		for (int i = 0;i < sizepat;i++) {
			if (username == databasepat[i].getusername()) {
				return databasepat[i].getcnic();
			}
		}
	}
	int getbalanceprofile(string username) {
		for (int i = 0;i < sizepat;i++) {
			if (username == databasepat[i].getusername()) {
				return i;
			}
		}
	}
	int getbalanceprofiledoc(string username) {
		for (int i = 0;i < sizedoc;i++) {
			if (username == databasedoc[i].getusername()) {
				return i;
			}
		}
	}



	string getcnicddb(int index) const {
		return databasedoc[index].getcnic();
	}
	string getusernameddb(int index) const {
		return databasedoc[index].getusername();
	}
	string getpasswordddb(int index) const {
		return databasedoc[index].getpassword();
	}
	string getemailddb(int index) const {
		return databasedoc[index].getemail();
	}
	string gettypeddb(int index) const {
		return databasedoc[index].getusertype();
	}
	int getsizedoc() const {
		return sizedoc;
	}
	int getsizepat() const {
		return sizepat;
	}
	int getsizeapp() const {
		return sizeapp;
	}
	string getspecdb(int index) const {
		return databasedoc[index].getspecialization();
	}
	string gethospitaldb(int index) const {
		return databasedoc[index].gethospital();
	}
	string gethoursdb(int index) const {
		return databasedoc[index].gethours();
	}
	string getcitydb(int index) const {
		return databasedoc[index].getcity();
	}
	string getexperiencedb(int index) const {
		return databasedoc[index].getexp();
	}
	int getchargesdb(int index) const {
		return databasedoc[index].getcharges();
	}
	int getbalancepdb(int index) const {
		return databasepat[index].getbalance();
	}
	int getbalanceddb(int index) const {
		return databasedoc[index].getbalance();
	}
	void takebalancepdb(int index, int amount)const {
		databasepat[index].takebalance(amount);
	}
	void takebalanceddb(int index, int amount)const {
		databasedoc[index].takebalance(amount);
	}
	void addbalancepdb(int index, int amount)const {
		databasepat[index].addbalance(amount);
	}
	void addbalanceddb(int index, int amount)const {
		databasedoc[index].addbalance(amount);
	}
	Appointment getappointmentdb(int index) const {
		return databasedoc[index].getappointment();
	}

};