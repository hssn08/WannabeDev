#pragma once
#include<iostream>
using namespace std;
class Doctor :public Register {
public:
	Doctor();
	Doctor(string , string , string , string , string , int , Doctorattributes );

	void filehandlingdoc();
	string getcnic() const;
	string getemail() const;

	Appointment getappointment();
	string getusername() const;
	string getusertype() const;
	string getpassword() const;
	void setcnic(string);
	void setemail(string );
	void setusername(string);
	void setpassword(string );
	void addbalance(int );
	void takebalance(int);
	string getspecialization() const;
	string getexp() const;
	string getcity() const;
	int getbalance() const;
	void setavlhours(string n);
	void setcharges(int n);
	void setcity(string n);
	string gethours() const;
	string gethospital() const;
	int getcharges() const;
	float getfeedback() const;
	void setfeedback(int);
	void setbalance(int );
};