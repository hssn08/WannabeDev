//Hassan Abbas 21I-0507 Assignment 3


#include"String.h"
String::String() {
	s = NULL;
	size = 0;
}
String::String(const char* str) {
	int x = 0;
	for (int i = 0;i < 255;i++) {
		if (*(str + i) == '\0') {
			i = 255;

		}
		else if (*(str + i) != '\0') {
			x++;
		}

	}
	size = x;
	s = new char[size + 1];
	for (int i = 0;i < size;i++) {
		s[i] = *(str + i);
	}
	s[size] = '\0';

}

String::String(const String& obj) {
	size = obj.size;
	s = new char[size + 1];
	for (int i = 0;i < size;i++) {
		s[i] = *(obj.s + i);
	}
	s[size] = '\0';
}
String::String(int x) {
	s = new char[x + 1];
	size = x;
	for (int i = 0;i < size;i++) {
		s[i] = 0;
	}
	s[size] = '\0';
}
String::String(const string& obj) {
	int x = 0;
	for (int i = 0;i < 255;i++) {
		if (obj[i] == '\0') {
			i = 255;
		}
		else if (obj[i] != '\0') {
			x++;
		}
	}
	size = x;
	s = new char[size + 1];
	for (int i = 0;i < size;i++) {
		s[i] = obj[i];
	}
	s[size] = '\0';
}
char& String::operator[](int i) {

	if (i >= 0 && i < size) {
		return s[i];
	}

}
const char String::operator[](int i) const {

	if (i >= 0 && i < size) {
		return s[i];
	}

}
String String::operator+(const String& str) {
	size += str.size;
	String N(size);
	for (int i = 0;i < size - str.size;i++) {
		N.s[i] = s[i];
	}
	for (int i = 0;i < size;i++) {
		N.s[i + size - str.size] = str.s[i];
	}
	return N;
}
String String::operator+(const char& str) {
	char* array = new char[size + 1];
	for (int i = 0;i < size;i++) {
		array[i] = s[i];
	}
	array[size] = str;
	String N(array);
	return N;
}
String String::operator+(char*& str) {
	int x = 0;
	for (int i = 0;i < 255;i++) {
		if (*(str + i) == '\0') {
			i = 255;
		}
		else if (*(str + i) != '\0') {
			x++;
		}
	}
	String N(size + x);
	for (int i = 0;i < N.size - x;i++) {
		N.s[i] = s[i];
	}
	for (int i = 0;i < x;i++) {
		N.s[i + size] = str[i];
	}
	return N;
}
String String::operator-(const String& substr) {
	String S(s);
	int z = 0;
	for (int i = 0;i < size;i++) {
		for (int j = 0;j < substr.size;j++) {
			if (S.s[i] == substr.s[j]) {
				for (int x = 0;x < substr.size;x++) {
					if (S.s[i + x] == substr.s[x]) {
						z++;
					}
				}
				if (z == substr.size) {
					for (int k = i;k < i + substr.size;k++) {
						S.s[k] = S.s[k + substr.size];
					}
				}
				if (z != substr.size) {
					z = 0;
				}
			}
		}
	}
	return S;
}
String String::operator-(const string& substr) {
	String S(s);
	int z = 0;
	int x = 0;
	for (int i = 0;i < 255;i++) {

		if (substr[i] == '\0') {
			i = 255;
		}
		else if (substr[i] != '\0') {
			x++;
		}
	}
	int substrsize = x;
	for (int i = 0;i < size;i++) {
		for (int j = 0;j < substrsize;j++) {
			if (S.s[i] == substr[j]) {
				for (int x = 0;x < substrsize;x++) {
					if (S.s[i + x] == substr[x]) {
						z++;
					}
				}
				if (z == substrsize) {
					for (int k = i;k < i + substrsize;k++) {
						S.s[k] = S.s[k + substrsize];
					}
				}
				if (z != substrsize) {
					z = 0;
				}
			}
		}
	}
	return S;
}
String String::operator=(const String& B) {
	size = B.size;
	delete[]s;
	s = new char[size + 1];
	for (int i = 0;i < size;i++) {
		this->s[i] = B[i];
	}
	s[size] = '\0';
	return *this;
}
String String::operator=(char* B) {
	int x = 0;
	for (int i = 0;i < 255;i++) {
		if (B[i] == '\0') {
			i = 255;
		}
		else if (B[i] != '\0') {
			x++;
		}
	}
	this->size = x;
	this->s = B;
	return *this;
}
String String::operator=(const string& B) {
	int x = 0;
	for (int i = 0;i < 255;i++) {
		if (B[i] == '\0') {
			i = 255;
		}
		else if (B[i] != '\0') {
			x++;
		}
	}
	this->size = x;
	for (int i = 0;i < size;i++) {
		this->s[i] = B[i];
	}
	return *this;
}
bool String::operator==(const String& B) const {
	int x = 0;
	if (size == B.size) {
		for (int i = 0;i < size;i++) {
			if (s[i] == B.s[i]) {
				x++;
			}
		}
	}
	if (x == size) {
		return true;
	}
	return false;
}
bool String::operator==(const string& B) const {
	int z = 0;
	int x = 0;
	for (int i = 0;i < 255;i++) {
		if (B[i] == '\0') {
			i = 255;
		}
		else if (B[i] != '\0') {
			x++;
		}
	}
	int Bsize = x;
	if (size == Bsize) {
		for (int i = 0;i < size;i++) {
			if (s[i] == B[i]) {
				z++;
			}
		}
	}
	if (z == size) {
		return true;
	}
	return false;
}
bool String::operator==(char* B) const {
	int z = 0;
	int x = 0;
	for (int i = 0;i < 255;i++) {

		if (B[i] == '\0') {
			i = 255;
		}
		else if (B[i] != '\0') {
			x++;
		}
	}
	int Bsize = x;
	if (size == Bsize) {
		for (int i = 0;i < size;i++) {
			if (s[i] == B[i]) {
				z++;
			}
		}
	}
	if (z == size) {
		return true;
	}
	return false;
}
bool String::operator!() {
	if (size == 0 && s == NULL) {
		return true;
	}
	return false;
}
int String::operator()(char B) const {
	for (int i = 0;i < size;i++) {
		if (s[i] == B) {
			return i;
		}
	}
}
int String::operator()(const String& B) const {

	int z = 0;
	int x = 0;
	for (int i = 0;i < 255;i++) {
		if (B.s[i] == '\0') {
			i = 255;
		}
		else if (B.s[i] != '\0') {
			x++;
		}
	}
	int substrsize = x;
	for (int i = 0;i < size;i++) {
		for (int j = 0;j < substrsize;j++) {
			if (s[i] == B[j]) {
				for (int x = 0;x < substrsize;x++) {
					if (s[i + x] == B[x]) {
						z++;
					}
				}
				if (z == substrsize) {
					return i;
				}
			}
			if (z != substrsize) {
				z = 0;
			}
		}
	}
}
int String::operator()(const string& B) const {

	int z = 0;
	int x = 0;
	for (int i = 0;i < 255;i++) {

		if (B[i] == '\0') {
			i = 255;
		}
		else if (B[i] != '\0') {
			x++;
		}
	}
	int substrsize = x;
	for (int i = 0;i < size;i++) {
		for (int j = 0;j < substrsize;j++) {
			if (s[i] == B[j]) {
				for (int x = 0;x < substrsize;x++) {
					if (s[i + x] == B[x]) {
						z++;
					}
				}
				if (z == substrsize) {
					return i;
				}
			}
			if (z != substrsize) {
				z = 0;
			}
		}
	}
}
int String::operator()(char* B) const {

	int z = 0;
	int x = 0;
	for (int i = 0;i < 255;i++) {

		if (B[i] == '\0') {
			i = 255;
		}
		else if (B[i] != '\0') {
			x++;
		}
	}
	int substrsize = x;
	for (int i = 0;i < size;i++) {
		for (int j = 0;j < substrsize;j++) {
			if (s[i] == B[j]) {
				for (int x = 0;x < substrsize;x++) {
					if (s[i + x] == B[x]) {
						z++;
					}
				}
				if (z == substrsize) {
					return i;
				}
			}
			if (z != substrsize) {
				z = 0;
			}
		}
	}
}
String::operator int() const {
	return size;
}
String::~String() {
	delete[]s;
}
// Operator Overloading as Non-Member Functions
// Stream Insertion and Extraction Operators
istream& operator>>(istream& input, String& S)
{
	int z = 0;
	for (int i = 0;S.s[i] = '\0';i++) {
		input >> S[i];
	}
	return input;
}

ostream& operator<<(ostream& output, const String& S)
{
	for (int i = 0; i < S.size; i++)
	{
		output << S.s[i];
	}
	return output;
}