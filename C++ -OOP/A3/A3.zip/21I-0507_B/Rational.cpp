//Hassan Abbas 21I-0507 Assignment 3

#include"Rational.h"

Rational::Rational(int n1, int d1) {
	d = d1;
	n = n1;
	int c;
	if (d < n) {
		c = d;
	}
	else {
		c = n;
	}
	for (int i = c;i >= 1;i--) {
		if (d % i == 0 && n % i == 0) {
			d = d / i;
			n = n / i;
		}
	}
}
Rational::Rational(const Rational& copy) {
	d = copy.d;
	n = copy.n;
}
Rational Rational::operator = (const Rational& x) {
	d = x.d;
	n = x.n;
	return *this;
}
Rational Rational::operator+(const Rational& x) const {
	Rational K(0, 0);
	if (x.d == 0 || x.n == 0) {
		K.d = d;
		K.n = n;
	}
	else if (d == 0 || n == 0) {
		K.d = x.d;
		K.n = x.n;
	}
	else {
		if (d == x.d) {
			K.d = d;
			K.n = n + x.n;
		}
		else {
			K.n = (n * x.d) + (x.n * d);
			K.d = x.d * d;
		}
	}
	return K;
}
Rational Rational::operator-(const Rational& x) const {
	Rational K(0, 0);
	if (x.d == 0 || x.n == 0) {
		K.d = d;
		K.n = n;
	}
	else if (d == 0 || n == 0) {
		K.d = x.d;
		K.n = -x.n;
	}
	else {
		if (d == x.d) {
			K.d = d;
			K.n = n - x.n;
		}
		else {
			K.n = (n * x.d) - (x.n * d);
			K.d = x.d * d;
		}
	}

	return K;
}
Rational Rational::operator*(const Rational& x) const {
	Rational K(0, 0);
	K.d = d * x.d;
	K.n = n * x.n;
	return K;
}
Rational Rational::operator/(const Rational& x) const {
	Rational K(0, 0);
	K.d = d * x.n;
	K.n = n * x.d;
	return K;
}
Rational Rational::operator += (const Rational& x) {
	if (x.d == 0 || x.n == 0) {
		d = d;
		n = n;
	}
	else if (d == 0 || n == 0) {
		d = x.d;
		n = x.n;
	}
	else {
		if (d == x.d) {
			d = d;
			n = n + x.n;
		}
		else {
			n = (n * x.d) + (x.n * d);
			d = x.d * d;
		}
	}
	return *this;
}
Rational Rational::operator -= (const Rational& x) {
	if (x.d == 0 || x.n == 0) {
		d = d;
		n = n;
	}
	else if (d == 0 || n == 0) {
		d = x.d;
		n = -x.n;
	}
	else {
		if (d == x.d) {
			d = d;
			n = n - x.n;
		}
		else {
			n = (n * x.d) - (x.n * d);
			d = x.d * d;
		}
	}
	return *this;
}
Rational Rational::operator *= (const Rational& x) {
	d *= x.d;
	n *= x.n;
	return *this;
}
Rational Rational::operator /= (const Rational& x) {
	d = d * x.n;
	n = n * x.d;
	return *this;
}
bool Rational::operator == (const Rational& other) const {
	float one = (float)n / (float)d;
	float two = (float)other.n / (float)other.d;
	if (one == two) {
		return true;
	}
	return false;
}
bool Rational::operator < (const Rational& other) const {
	float one = (float)n / (float)d;
	float two = (float)other.n / (float)other.d;
	if (one < two) {
		return true;
	}
	return false;
}
bool Rational::operator > (const Rational& other) const {
	float one = (float)n / (float)d;
	float two = (float)other.n / (float)other.d;
	if (one > two) {
		return true;
	}
	return false;
}
bool Rational::operator >= (const Rational& other) const {
	float one = (float)n / (float)d;
	float two = (float)other.n / (float)other.d;
	if (one >= two) {
		return true;
	}
	return false;
}
bool Rational::operator <= (const Rational& other) const {
	float one = (float)n / (float)d;
	float two = (float)other.n / (float)other.d;

	if (one <= two) {
		return true;
	}
	return false;
}
Rational::operator string() const {

	int x = n;
	int y = d;
	int c;
	if (y < n) {
		c = y;
	}
	else {
		c = x;
	}
	for (int i = c;i >= 1;i--) {
		if (y % i == 0 && x % i == 0) {
			y = y / i;
			x = x / i;
		}
	}
	int z = 0;
	int l = 0;
	char* array = new char;
	if (x < 9) {
		array = new char[5];
		if (x > 0 || x < 0) {
			if (x < 0) {
				array = new char[6];
				x = -x;
				array[0] = '-';
				array[1] = x + 48;
				if (y > 1) {
					array[2] = '/';
					array[3] = y + 48;
					array[4] = '\0';

					if (y > 9) {
						while (y > 9) {
							y -= 10;
							l += 1;
						}
						array[3] = l + 48;
						array[4] = y + 48;
						array[5] = '\0';
					}
				}
			}
			else {
				array[0] = x + 48;
				if (y > 1) {
					array[1] = '/';
					array[2] = y + 48;
					array[3] = '\0';

					if (y > 9) {
						while (y > 9) {
							y -= 10;
							l += 1;
						}
						array[2] = l + 48;
						array[3] = y + 48;
						array[4] = '\0';
					}
				}

				else {
					array[1] = '\0';
				}
			}
		}
		else {
			array[0] = 0 + 48;
			array[1] = '\0';
		}
	}
	if (x > 9) {
		array = new char[6];
		while (x > 9) {
			x -= 10;
			z += 1;
		}
		array[0] = z + 48;
		array[1] = x + 48;

		if (y > 9) {
			while (y > 9) {
				y -= 10;
				l += 1;
			}
			array[2] = '/';
			array[3] = l + 48;
			array[4] = y + 48;
			array[5] = '\0';
		}
		else {
			if (y > 1) {
				array[2] = '/';
				array[3] = y + 48;
				array[4] = '\0';
			}
			else {
				array[2] = '\0';
			}

		}
	}
	return array;
}
Rational::~Rational() {
}
// Operator Overloading as Non-Member Functions
// Stream Insertion and Extraction Operators
istream& operator>>(istream& input, Rational& R)
{
	cout << "numerator: ";
	input >> R.n;
	cout << "denominator: ";
	input >> R.d;
	int z = 0;
	int k = R.n * R.d;
	int g = k;
	while (g >= 1) {
		if (R.n % g == 0) {
			if (R.d % g == 0) {
				z = g;
				R.d = R.d / z;
				R.n = R.n / z;
				
			}
		}
		g--;
	}

	return input;
}

ostream& operator<<(ostream& output, const Rational& R)
{
	output << R.n << "/" << R.d << endl;

	return output;
}
