//Hassan Abbas 21I-0507 Assignment 3

#include"Array.h"
Array::Array() {
    array = NULL;
    size1 = 0;
}
Array::Array(int size) {
    size1 = size;
    array = new int[size1];
    for (int i = 0;i < size;i++) {
        *(array + i) = 0;
    }
}
Array::Array(int* arr, int size) {
    size1 = size;
    array = new int[size1];
    for (int i = 0;i < size;i++) {
        *(array + i) = *(arr + i);
    }
}
Array::Array(const Array& arra) {
    size1 = arra.size1;
    array = new int[size1];
    for (int i = 0;i < size1;i++) {
        *(array + i) = *(arra.array + i);
    }
}
int& Array::operator[](int i) {
    if (i >= 0 && i < size1) {
        return *(this->array + i);
    }
}
int& Array::operator[](int i) const {
    if (i >= 0 && i < size1) {
        return *(this->array + i);
    }
}
const Array& Array::operator=(const Array& arra) {
    size1 = arra.size1;
    array = new int[size1];
    for (int i = 0;i < arra.size1;i++) {
        *(array + i) = *(arra.array + i);
    }
    return *this;
}
Array Array::operator+(const Array& arr) {
    Array b(this->size1);
    for (int i = 0;i < size1;i++) {
        *(b.array + i) = *(arr.array + i) + *(this->array + i);
    }
    return b;
}
Array Array::operator-(const Array& arr) {
    Array b(this->size1);
    for (int i = 0;i < size1;i++) {
        *(b.array + i) = *(this->array + i) - *(arr.array + i);
    }
    return b;
}
Array Array::operator++() {
    for (int i = 0;i < size1;i++) {
        *(array + i) += 1;
    }
    return *this;
}
Array Array::operator++(int) {
    for (int i = 0;i < size1;i++) {
        *(array + i) += 1;
    }
    return *this;
}
Array& Array::operator--(int) {
    for (int i = 0;i < size1;i++) {
        *(array + i) -= 1;
    }
    return *this;
}
bool Array::operator==(const Array& arr)const {
    int x = 0;
    for (int i = 0;i < size1;i++) {
        if (*(array + i) == *(arr.array + i)) {
            x++;
        }
    }
    if (x == size1) {
        return true;
    }
    return false;
}
bool Array::operator!() {
    if (array == NULL) {
        return true;
    }
    else {
        return false;
    }
}
void Array::operator+=(const Array& arr) {
    for (int i = 0;i < arr.size1;i++) {
        *(this->array + i) += *(arr.array + i);
    }

}
void Array::operator-=(const Array& arr) {
    for (int i = 0;i < arr.size1;i++) {
        *(this->array + i) -= *(arr.array + i);
    }

}
int Array::operator()(int idx, int val) {
    if (*(array + idx) == val) {
        for (int i = idx;i < size1;i++) {
            *(array + i) = *(array + (i + 1));
        }
        size1 -= 1;
        return 1;
    }
    else {
        return -1;
    }
}
Array::~Array() {
    delete[]array;
}

// Operator Overloading as Non-Member Functions
// Stream Insertion and Extraction Operators
istream& operator>>(istream& input, Array& A)
{
    input >> A.size1;
    A.array = new int[A.size1];

    for (int i = 0; i < A.size1; i++)
    {
        input >> A.array[i];
    }

    return input;
}

ostream& operator<<(ostream& output, const Array& A)
{

    for (int i = 0; i < A.size1; i++)
    {
        output << A.array[i] << endl;
    }

    return output;
}

