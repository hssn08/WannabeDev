#include <iostream>
using namespace std;

class BankAccount
{
protected:
	int accountID;
	int balance;
public:
	void balanceIncquiry()
	{
		cout << "Account ID: " << accountID;
		cout << "Balance: " << balance;
	}
	int amountDeposit(int amount)
	{
		return amount;
	}
};

class CurrentAccount : public BankAccount
{
public:
	CurrentAccount(int accountID1, int balance1)
	{
		accountID = accountID1;
		balance = balance1;
	}
	int AmountWithdrawn(int amount)
	{
		if (balance >= 5000)
		{
			return amount;
		}
		else
			cout << "less money!\n";
	}
};

class SavingsAccount : public BankAccount
{
public:
	SavingsAccount(int accountID1, int balance1)
	{
		accountID = accountID1;
		balance = balance1;
	}
	int AmountWithdrawn(int amount)
	{
		if (balance >= 10000)
		{
			return amount;
		}
		else
        {
            cout << "less money\n ";
            return 0;
        }
	}
};

int main()
{
	CurrentAccount CA(1234, 15000);
	SavingsAccount SA(9876, 3000);
	cout << "Amount Withdrawn from Current Account: " << CA.AmountWithdrawn(5000)<<endl;
	cout << "Amount Withdrawn from Savings Account: " << SA.AmountWithdrawn(5000) << endl;
	cout << "Amount Deposited in Current Account: " << CA.amountDeposit(5000) << endl;
	cout << "Amount Deposited in Savings Account: " << SA.amountDeposit(5000) << endl;
}