#include <iostream>
using namespace std;

class Employee
{
protected:
	string name;
	int empID;
	int hourlyIncome;
};

class HourlyEmployee : public Employee
{
public:
	HourlyEmployee(string name1, int empID1, int hourlyIncome1)
	{
		name = name1;
		empID = empID1;
		hourlyIncome = hourlyIncome1;
	}
	int calculate_the_hourly_income(int hours)
	{
		return hourlyIncome * hours;
	}
};
class PermanentEmployee : public Employee
{
public:
	PermanentEmployee(string name1, int empID1, int hourlyIncome1)
	{
		name = name1;
		empID = empID1;
		hourlyIncome = hourlyIncome1;
	}
	int calculate_the_income()
	{
		return 240 * hourlyIncome;
	}
};

int main()
{
	HourlyEmployee HE("Hassan", 1234, 150);
	int HE_income = HE.calculate_the_hourly_income(120);
	PermanentEmployee PE("Abbas", 700, 150);
	int PE_income = PE.calculate_the_income();
	cout << "Total salary of Hourly Employee 1 = " << HE_income<<"\n";
	cout << "Total salary of Permanent Employee 1 = " << PE_income;
}