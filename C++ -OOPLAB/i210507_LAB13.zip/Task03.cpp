#include <iostream>
using namespace std;

class person
{
public:
	string name;
	int year_of_birth;
	person() {};
	person(string name1, int year_of_birth1)
	{
		name = name1;
		year_of_birth = year_of_birth1;
	}
};

class employee : public person
{
public:
	int employeeID;
	int joiningYear;
	string jobTitle;
	int courseID;
	string courseTitle;
};

class student : public person
{
public:
	int studentID;
	int enrolledSemester;
	student(string name1, int year_of_birth1, int studentID1, int enrolledSemester1)
	{
		name = name1;
		year_of_birth = year_of_birth1;
		studentID = studentID1;
		enrolledSemester = enrolledSemester1;
	}
};

class administration : public employee
{
public:
	administration(int employeeID1, int joiningYear1, string jobTitle1, int courseID1, string courseTitle1)
	{
		employeeID = employeeID1;
		joiningYear = joiningYear1;
		jobTitle = jobTitle1;
		courseID = courseID1;
		courseTitle = courseTitle1;
	}
};

class academic : public employee
{
public:
	academic(int employeeID1, int joiningYear1, string jobTitle1, int courseID1, string courseTitle1)
	{
		employeeID = employeeID1;
		joiningYear = joiningYear1;
		jobTitle = jobTitle1;
		courseID = courseID1;
		courseTitle = courseTitle1;
	}
	void setCourseID(int courseID1) { courseID = courseID1; }
	void setCourseTitle(int courseTitle1) { courseTitle = courseTitle1; }
};

int main()
{
	student s1("Hasan", 2002, 0736, 2);
	administration ad1(0643, 2020, "Professor", 1, "0");
	academic ac1(1, 1, "0", 007, "OOP");
	cout << "STUDENT INFORMATION \n\n";
	cout << "Name: " << s1.name << endl;
	cout << "Birth Year: " << s1.year_of_birth << endl;
	cout << "ID: " << s1.studentID<<endl;
	cout << "Enrolled Semester: " << s1.enrolledSemester << endl;
	cout << "EMPLOYEE INFORMATION \n\n";
	cout << "Employee ID: " << ad1.employeeID << endl;
	cout << "Joining Year: " << ad1.joiningYear << endl;
	cout << "Job Title: " << ad1.jobTitle << endl;
	cout << "Course ID: " << ac1.courseID << endl;
	cout << "Course Title: " << ac1.courseTitle << endl;
}
