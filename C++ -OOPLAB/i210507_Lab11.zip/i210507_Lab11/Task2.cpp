#include <iostream>
using namespace std;

class point
{
private:
	int x;
	int y;
public:
	void setx(int x1)
	{
		x1 = x;
	}
	void sety(int y1) {
		y1 = y;
	}
	int getx() {
		return x;
	}
	int gety() { 
		return y; 
	}
	point()
	{
		x = 0;
		y = 0;
	}
	void insertPoint(int xz, int yz)
	{
		x = xz;
		y = yz;
	}
	void displayPoint(int n)
	{
		cout <<"Coordinates of point " << n << " are " << "( " << x << " , " << y << " )"<<endl;
	}
};

class triangle
{
private:
	point a;
	point b;
	point c;
public:
	triangle() {}
	triangle(point a1, point b1, point c1)
	{
		a = a1;
		b = b1;
		c = c1;
	}
	triangle(int x1, int y1, int x2, int y2, int x3, int y3)
	{
		a.setx(x1);
		a.sety(y1);
		b.setx(x2);
		b.sety(y2);
		c.setx(x3);
		c.sety(y3);
	}
	void displayData()
	{
		a.displayPoint(1);
		b.displayPoint(2);
		c.displayPoint(3);
	}
};

void main()
{
	point a1;
	point b1;
	point c1;
	a1.insertPoint(0, 0);
	b1.insertPoint(10, 10);
	c1.insertPoint(20, 0);
	triangle one(a1, b1, c1);
	cout << "---Triangle#1---\n";
	one.displayData();
	point a2;
	point b2;
	point c2;
	a2.insertPoint(0, 0);
	b2.insertPoint(10, 50);
	c2.insertPoint(20, 0);
	triangle two(a2, b2, c2);
	cout << "---Triangle#2---\n";
	two.displayData();
}