#include<iostream>
#include<string>
using namespace std;
class Instructor {
	string fn;
	string ln;
	string pn;
public:
	Instructor() {
		fn = "";
		ln = "";
		pn = "";
	}
	Instructor(string fstn,string lstn,string phn) {
		fn = fstn;
		ln = lstn;
		pn = phn;
	}
	void setfirstname(string fstn) {
		fn = fstn;
	}
	void setlastname(string lstn) {
		ln = lstn;
	}
	void setphone(string phn) {
		pn = phn;
	}
	void print() {
		cout << "First Name: " << fn << endl;
		cout << "Last Name: " << ln << endl;
		cout << "Phone: " << pn << endl;
	}
};
class Textbook {
	string title;
	string author;
	string publisher;
public:
	Textbook() {
		title = "";
		author = "";
		publisher = "";
	}
	Textbook(string fstn, string lstn, string phn) {
		title = fstn;
		author = lstn;
		publisher = phn;
	}
	void settitle(string fstn) {
		title = fstn;
	}
	void setauthor(string lstn) {
		author = lstn;
	}
	void setpublisher(string phn) {
		publisher = phn;
	}
	void print() {
		cout << "title: " << title << endl;
		cout << "author: " << author << endl;
		cout << "publisher: " << publisher << endl;
	}
};
class Course {
	string cname;
	Instructor x;
	Textbook y;
public:
	Course(string a, string b, string c, string d, string e, string f) {
		x.setfirstname(a);
		x.setlastname(b);
		x.setphone(c);
		y.setauthor(e);
		y.settitle(d);
		y.setpublisher(f);
	}
	void display() {
		cout << "Course name: " << cname << endl;
		x.print();
		y.print();
	}
};
int main() {
	Course x("Hassan", "Abbas", "03234444618","Good Book", "Good author", "GoodPublishers");
	x.display();
}