#include<iostream>
using namespace std;
class Car {
public:
class Engine {
public:
	void start() {
		cout << "Car start" << endl;
	}
	void stop() {
		cout << "Car stop" << endl;
	}
};
class Wheel {
public:
	void inflate() {
		cout << "Car inflate" << endl;
	}
	
};
	class Window {
	public:
		void rollup() {
			cout << "left window rollup" << endl;
		}
		void rolldown() {
			cout << " left window rolldown" << endl;
		}
	};
class Door {
public:

	Window window;

	void open() {
		cout << "door oper" << endl;
	}
	void close() {
		cout << "door close" << endl;
	}

};
Engine engine;
Door left;
Wheel wheel;

};
int main() {
	Car car;
	car.engine.stop();
	car.left.window.rollup();
	car.engine.stop();
}