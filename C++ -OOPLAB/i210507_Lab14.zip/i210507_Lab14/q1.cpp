#include <iostream>
using namespace std;

class shape
{
protected:
	string type;
	float A2;
public:
	virtual void a2() = 0;
	virtual void print() = 0;
};

class rectangle: public shape
{
private:
	float height;
	float width;
public:
	void a2()
	{
		A2 = width * height;
	}
	rectangle(string t1, float w1, float h1)
	{
		type = t1;
		width = w1;
		height = h1;
	}
	void print()
	{

		cout << "-----------------------------" << "\n";
		cout << "Type is "<<type << "\n";
		cout << "Width is " << width<< "\n";
		cout << "Height is " << height<< "\n";
		cout << "Area is " << A2<< "\n";

		cout << "-----------------------------" << "\n";
	}
};

class triangle: public shape
{
private:
	float base;
	float height;
public:
	void a2()
	{
		A2 = (1.0 / 2.0) * (base * height);
	}
	triangle(string t1, float b1, float h1)
	{
		type = t1;
		base = b1;
		height = h1;
	}
	void print()
	{
		cout << "-----------------------------" << "\n";
		cout << "Type is "<<type << "\n";
		cout << "Base is " << base<< "\n";
		cout << "Height is " << height<< "\n";
		cout << "Area is  " << A2<< "\n";

		cout << "-----------------------------" << "\n";
	}
};

class circle: public shape
{
private:
	float r;
public:
	void a2()
	{
		A2 = 3.14 * r * r;
	}
	circle(string type1, float r1)
	{
		type = type1;
		r = r1;
	}
	void print()
	{
		cout << "-----------------------------" << "\n";
		cout << "Type is " << type << "\n";
		cout << "Radius is " << r<< "\n";
		cout << "Area is " << A2<<"\n";

		cout << "-----------------------------" << "\n";
	}
};

int main()
{
	shape* rectangles = new rectangle("RECTANGLE", 12, 13);
	rectangles->a2();
	rectangles->print();
	shape* triangles = new triangle("TRIANGLE", 12, 13);
	triangles->a2();
	triangles->print();
	shape* circles = new circle("CIRCLE",5);
	circles->a2();
	circles->print();
}