#include <iostream>
using namespace std;

class person
{
protected:
	string name;
	string address;
public:
	person() {};
	person(string n1, string a1)
	{
		name = n1;
		address = a1;
	}
};
class employee : virtual public person
{
protected:
	int Emp_no;
	float gross_pay;
	float house_rent;
	float medical_allow;
	float net_pay;
public:
	employee() {};
	employee(int e1, float g1, float h1, float m1)
	{
		house_rent = h1;
		medical_allow = m1;
		Emp_no = e1;
		gross_pay = g1;
		
	}
	virtual void calculateSalary()
	{
		net_pay = gross_pay - ((45.0 / 100.0) * gross_pay - (5.0 / 100.0) * gross_pay);
	}
	virtual void display()
	{
		cout << "Employee Number is " << Emp_no << "\n";
		cout << "Gross Pay is " << gross_pay << "\n";
		cout << "House Rent is " << house_rent << "\n";
		cout << "Medical Allowance is " << medical_allow << "\n";
		cout << "Net Pay is " << net_pay << "\n";
	}
};

class faculty : public employee
{
protected:
	string designation;
	string department;
public:
	faculty() {};
	faculty(string name, string address, string designation1, string department1, int Emp_no1, float gross_pay1, float house_rent1, float medical_allow1) :employee(Emp_no1, gross_pay1, house_rent1, medical_allow1), person(name, address)
	{
		designation = designation1;
		department = department1;
	}
	virtual void calculateSalary()
	{
		net_pay = gross_pay - ((45.0 / 100.0) * gross_pay - (5.0 / 100.0) * gross_pay);
	}
	virtual void display()
	{
		cout << "Employee Number is " << Emp_no << "\n";
		cout << "Designation is " << designation << "\n";
		cout << "Department is" << department << "\n";
		cout << "Gross Pay is" << gross_pay << "\n";
		cout << "House Rent is " << house_rent << "\n";
		cout << "Medical Allowance is " << medical_allow << "\n";
		cout << "Net Pay is " << net_pay <<"\n";
	}
};


int main()
{
	employee* employee = new faculty("Hassan", "lincoln street", "Teacher", "Comp sci", 700, 50000, 70000, 15000);
	employee->calculateSalary();
	employee->display();
}