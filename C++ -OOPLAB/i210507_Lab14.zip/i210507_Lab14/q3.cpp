#pragma once
//Hassan Abbas
#include <iostream>
using namespace std;

class Person {

protected:
	string name;
	string DOB;

public:
	Person(string name = "", string DOB = "") : name(name), DOB(DOB) {}

};

class Student : public Person {

protected:
	string Roll_number;
	string enrolledSemester;

public:
	Student(string name = "", string DOB = "", string Roll_Number = "", string enrolledSemester = "") : Person(name, DOB), Roll_number(Roll_Number), enrolledSemester(enrolledSemester) {}
	void Display()
	{

		cout << "Name: " << name << endl;
		cout << "Date of Birth: " << DOB << endl;
		cout << "Roll Number: " << Roll_number << endl;
		cout << "Enrolled Semester: " << enrolledSemester << endl;

	}

};

class Employee : public Person {

protected:
	string employeeID;
	int joiningYear;
	string jobTitle;
	string courseID;
	string courseTitle;

public:
	Employee(string name = "", string DOB = "", string employeeID = "", int joiningYear = 0, string jobTitle = "", string courseID = "", string courseTitle = "") : Person(name, DOB), employeeID(employeeID), joiningYear(joiningYear), jobTitle(jobTitle), courseID(courseID), courseTitle(courseTitle) {}

};

class Administration :virtual public Employee {

public:
	Administration(string name = "", string DOB = "", string employeeID = "", int joiningYear = 0, string jobTitle = "") : Employee(name, DOB, employeeID, joiningYear, jobTitle, "", "") {}
	void setjobTitle(string jobTitle)
	{

		this->jobTitle = jobTitle;

	}

	string getjobTitle()
	{

		return jobTitle;

	}

};

class Academic :virtual public Employee {

public:
	Academic(string name = "", string DOB = "", string courseID = "", string courseTitle = "") : Employee(name, DOB, "", 0, "", courseID, courseTitle) {}
	void setCourseID(string courseId)
	{

		this->courseID = courseID;

	}

	void setCourseTitle(string courseTitle)
	{

		this->courseTitle = courseTitle;

	}

};

class DeanHOD : public Academic, public Administration {

public:
	DeanHOD(string name = "", string DOB = "", string employeeID = "", int joiningYear = 0, string jobTitle = "") : Employee(name, DOB, employeeID, joiningYear, jobTitle, "", "") {}

	void setemployeeID(string employeeID)
	{

		this->employeeID = employeeID;

	}

	void setDesignation(string designation)
	{

		this->jobTitle = jobTitle;

	}

	void setID(string ID)
	{

		this->courseID = ID;

	}

	void setCourseTitle(string courseTitle)
	{

		this->courseTitle = courseTitle;

	}

};