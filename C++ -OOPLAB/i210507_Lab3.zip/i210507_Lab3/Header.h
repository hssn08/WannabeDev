#pragma once
#include<iostream>
using namespace std;
char ** words_to_sentence(int word,int alpha) {
	char** sentence = new char* [word];
	for (int i = 0; i < word; i++) {
		sentence[i] = new char[alpha];
		cout << "Enter word no" << endl;
		cin >> *(sentence + i);
	}
	return sentence;
}