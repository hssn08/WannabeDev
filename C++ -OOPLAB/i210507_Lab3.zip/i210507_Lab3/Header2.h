#pragma once
#include<iostream>
using namespace std;
int x_std = 0;
int x_scaled = 0;
int** Min_Max_Scaling(int row, int col) {
	int** array = new int[row];
	for (int i = 0; i < row; i++) {
		array[i] = new int[col];
	}
	*(array + 0) = { 100,90,95,90,98,93};
	*(array + 1) = { 10,20,6,40,30,30};
	*(array + 2) = { 90,60,80,60,60,100};
	*(array + 3) = { 10,5,10,5,10,6};
	*(array + 4) = { 100,100,100,90,90,90 };
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++) {
			x_std = (*(*(array + i) + j) - 5.0) / (100 - 5);
			x_scaled = x_std * (80 - 50) + 50;
			(*(*(array + i) + j)) = x_scaled;
		}
	}
}
