#pragma once
#include<iostream>
using namespace std;
class Date {
private:
	int day;
	int month;
	int year;
public:
	Date(int day1, int month1, int year1) {
		day = day1;
		month = month1;
		year = year1;
	}
	bool operator >(const Date& b) {
		if (year > b.year) {
			if (month > b.month) {
				if (day > b.day) {
					return false;
				}
			}
		}
		return true;
	}
	bool operator <(const Date& b) {
		if (year < b.year) {
			if (month < b.month) {
				if (day < b.day) {
					return false;
				}
			}
		}
		return true;
	}
	bool operator ==(const Date& b) {
		if (year == b.year) {
			if (month == b.month) {
				if (day == b.day) {
					return true;
				}
			}
		}
		return false;
	}
};