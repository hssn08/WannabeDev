#pragma once
#include<iostream>
using namespace std;
class Distance {
private:
	int feet;
	int inches;
public:
	Distance() {
		feet = 0;
		inches = 0;
	}
	Distance(int feet1,int inches1) {
		feet = feet1;
		inches = inches1;
		if (inches >= 12) {
			inches -= 12;
			feet += 1;
		}
	}
	void setFeet(int f) {
		feet = f;
	}
	void setInches(int i) {
		inches = i;
		if (inches >= 12) {
			inches -= 12;
			feet += 1;
		}
	}
	int getFeets()const {
		return feet;
	}
	int getInches()const {
		return inches;
	}
	Distance operator +(const Distance& d) {
		Distance f;
		f.feet=this->feet + d.feet;
		f.inches=this->inches + d.inches;
		if (inches >= 12) {
			inches -= 12;
			feet += 1;
		}
		return f;
	}
	Distance operator -(const Distance& d) {
		Distance f;
		f.feet = this->feet - d.feet;
		f.inches = this->inches - d.inches;
		if (inches >= 12) {
			inches -= 12;
			feet += 1;
		}
		return f;
	}
	bool operator ==(const Distance& d) {
		if (feet == d.feet) {
			if (inches == d.inches) {
				return true;
			}
		}
		return false;
	}
};