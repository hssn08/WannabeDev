#pragma once
#include<iostream>
using namespace std;
class Matrix {
private:
	int** matrix;
public:
	Matrix(int a) {
		matrix = new int* [3];
		for (int i = 0;i < 3;i++) {
			matrix[i] = new int[3];
		}
		for (int i = 0;i < 3;i++) {
			for (int j = 0;j < 3;j++) {
				matrix[i][j] = a;
			}
		}
	}
	Matrix() {
		matrix = new int* [3];
		for (int i = 0;i < 3;i++) {
			matrix[i] = new int[3];
		}
		for (int i = 0;i < 3;i++) {
			for (int j = 0;j < 3;j++) {
				matrix[i][j] = 0;
			}
		}
	}
	void setMatrixValues(int matrixArray[3][3]) {
		for (int i = 0;i < 3;i++) {
			for (int j = 0;j < 3;j++) {
				matrix[i][j] = matrixArray[i][j];
			}
		}
	}
	int getSpecificIndexValue(int x, int y) {
		return matrix[x][y];
	}
	void displayMatrix() {
		for (int i = 0;i < 3;i++) {
			for (int j = 0;j < 3;j++) {
				cout << matrix[i][j] << " ";
			}
			cout << endl;
		}
	}
	Matrix operator +(const Matrix& d) {
		Matrix f;
		for (int i = 0;i < 3;i++) {
			for (int j = 0;j < 3;j++) {
				f.matrix[i][j] = this->matrix[i][j] + d.matrix[i][j];
			}
		}
		return f;
	}
	Matrix operator -(const Matrix& d) {
		Matrix f;
		for (int i = 0;i < 3;i++) {
			for (int j = 0;j < 3;j++) {
				f.matrix[i][j] = this->matrix[i][j] - d.matrix[i][j];
			}
		}
		return f;
	}
	bool operator ==(const Matrix& d) {
		int x=0;
		for (int i = 0;i < 3;i++) {
			for (int j = 0;j < 3;j++) {
				if (matrix[i][j] == d.matrix[i][j]) {
					x++;
				}
			}
		}
		if (x == 9) {
			return true;
		}
		return false;
	}
};