#pragma once
#include<iostream>
using namespace std;
struct book {
	int number;
	string title;
	string author;
	bool availibility;
};
void book_insert(book b[3]) {
	for (int i = 0;i < 3;i++) {
		cin >> b[i].number;
		cin >> b[i].title;
		cin >> b[i].author;
		cin >> b[i].availibility;
	}
}
int available_books(book b[3]) {
	int x=0;
	for (int i = 0;i < 3;i++) {
		if (b[i].availibility == true) {
			x++;
		}
	}
	return x;
}
