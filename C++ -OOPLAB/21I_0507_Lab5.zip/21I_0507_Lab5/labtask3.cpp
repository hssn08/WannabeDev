#include<iostream>
using namespace std;
class dayType
{
private:
    int i;
    string Weekdays[7];
    string day;
    string NextDay;
    string AddDays;

public:
    void setweekdays() {
        Weekdays[0] = "Mon";
        Weekdays[1] = "Tues";
        Weekdays[2] = "Wednes";
        Weekdays[3] = "Thurs";
        Weekdays[4] = "Fri";
        Weekdays[5] = "Satur";
        Weekdays[6] = "Sun";
    }
    string setday(string d)
    {
        if (day == Weekdays[0])
        {
            i = 0;
        }
        else if (day == Weekdays[1])
        {
            i = 1;
        }
        else if (day == Weekdays[2])
        {
            i = 2;
        }
        else if (day == Weekdays[3])
        {
            i = 3;
        }
        else if (day == Weekdays[4])
        {
            i = 4;
        }
        else if (day == Weekdays[5])
        {
            i = 5;
        }
        else if (day == Weekdays[6])
            i = 6;
        return day;
    }
    void Nextday()
    {
        if (i == 6)
            NextDay = Weekdays[0];
        else
            NextDay = Weekdays[i + 1];

    }
    string add(int n)
    {
        n = n + i;
        while (n >= 7)
        {
            n -= 7;
        }
        return AddDays = Weekdays[n];
    }
    void output()
    {
        cout << "Day=" << day << "day" << endl;
        cout << "Next day :" << NextDay << "day" << endl;
        cout << "After Adding Days :" << AddDays << "day" << endl;
    }
};
int main()
{
    int n;
    string d;
    cout << "Enter 'Sun' for 'Sunday'" << endl;
    cout << "Enter 'Mon' for 'Monday'" << endl;
    cout << "Enter 'Tues' for 'Tuesday'" << endl;
    cout << "Enter 'Wednes' for 'Wednesday'" << endl;
    cout << "Enter 'Thurs' for 'Thursday'" << endl;
    cout << "Enter 'Fri' for 'Friday'" << endl;
    cout << "Enter 'Satur' for 'Saturday'" << endl;
    cin >> d;
    dayType Dayy;
    Dayy.setweekdays();

    Dayy.setday(d);
    Dayy.Nextday();
    cout << "Enter the No. of days to add :";
    cin >> n;
    Dayy.add(n);
    Dayy.output();
    return 0;
}

