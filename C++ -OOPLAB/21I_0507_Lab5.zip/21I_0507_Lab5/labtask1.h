#include<iostream>
using namespace std;
struct partsType {
    int partNum;
    double price;
    int quantitiesInStock;
};

void parttype_insert(partsType p[3]) {
    for (int i = 0;i < 3;i++) {
        cin >> p[i].partNum;
        cin >> p[i].price;
        cin >> p[i].quantitiesInStock;
    }
}