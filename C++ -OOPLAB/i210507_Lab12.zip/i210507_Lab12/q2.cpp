#include<iostream>
using namespace std;
class Professor {
public:
	string name;
	int employeeid;
	string designation;
	Professor() {
		name = '\0';
		employeeid = 0;
		designation = '\0';
	}
	Professor(string a, int b, string c) {
		name = a;
		employeeid = b;
		designation = c;
	}
	void setname(string c) {
		name = c;
	}
	string getname() {
		return name;
	}
	void setemployeeid(int c) {
		employeeid = c;
	}
	int getemployeeid() {
		return employeeid;
	}
	void setdesignation(string c) {
		designation = c;
	}
	string getdesignation() {
		return designation;
	}
	
};
class Department {
public:
	string depname;
	int depid;
	Professor* array;
	int numofpro;
	Department() {
		depname = '\0';
		depid = 0;
		numofpro = 0;
	}
	Department(string c, int b, int a, Professor* p) {
		depname = c;
		depid = b;
		numofpro = a;
		array = new Professor[numofpro];
		for (int i = 0;i < numofpro;i++) {
			array[i].setname(p[i].getname());
			array[i].setemployeeid(p[i].getemployeeid());
			array[i].setdesignation(p[i].getdesignation());
		}
	}
	void setdepname(string c) {
		depname = c;
	}
	string getdepname() {
		return depname;
	}
	void setdepid(int c) {
		depid = c;
	}
	int getdepid() {
		return depid;
	}
	bool addProfessor(Professor p) {
		int newnumofpro = numofpro += 1;
		Professor* array3 = new Professor[numofpro];
		for (int i = 0;i < numofpro;i++) {
			array3[i].setname(array[i].getname());
			array3[i].setemployeeid(array[i].getemployeeid());
			array3[i].setdesignation(array[i].getdesignation());
		}
		array = new Professor[newnumofpro];
		for (int i = 0;i < numofpro;i++) {
			array[i].setname(array3[i].getname());
			array[i].setemployeeid(array3[i].getemployeeid());
			array[i].setdesignation(array3[i].getdesignation());
		}
		array[newnumofpro].setname(p.getname());
		array[newnumofpro].setemployeeid(p.getemployeeid());
		array[newnumofpro].setdesignation(p.getdesignation());
		return true;
	}
	bool deleteProfessor(int id) {
		bool flag = false;
		for (int i = 0;i < numofpro;i++) {
			if (array[i].getemployeeid() == id) {
				flag = true;
			}
			if (flag == true) {
				array[i] = array[i + 1];
			}
		}
		return true;
	}
	bool updateProfessor(int id, string newDesignation) {
		for (int i = 0;i < numofpro;i++) {
			if (array[i].getemployeeid() == id) {
				array[i].setdesignation(newDesignation);
			}
		}
		return true;
	}
	void Display() {
		cout << "Dep Name : " << depname << endl;
		cout << "Dep Id : " << depid << endl;
		cout << "Number of Professors: " << numofpro << endl;
		for (int i = 0;i < numofpro;i++) {
			cout << endl;
			cout << "Professor # " << i+1 << " Name: " << array[i].getname() << endl;
			cout << "Professor # " << i+1 << " id: " << array[i].getemployeeid() << endl;
			cout << "Professor # " << i+1 << " Designation: " << array[i].getdesignation() << endl;
			cout << endl;
		}
	}
};
class University {
public:
	string uniname;
	Department* array1;
	int numofdep;
	void setuniname(string c) {
		uniname = c;
	}
	string getuniname() {
		return uniname;
	}
	bool addDepartment(Department D) {
		int newnumofdep =numofdep+1;
		Department* array2 = new Department[numofdep];
		for (int i = 0;i < numofdep;i++) {
			array2[i].setdepname(array1[i].getdepname());
			array2[i].setdepid(array1[i].getdepid());
		}
		array1 = new Department[newnumofdep];
		for (int i = 0;i < numofdep;i++) {
			array1[i].setdepname(array2[i].getdepname());
			array1[i].setdepid(array2[i].getdepid());
		}
		array1[newnumofdep].setdepname(D.getdepname());
		array1[newnumofdep].setdepid(D.getdepid());
		return true;
	}
	bool deleteDepartment(string name) {
		bool flag = false;
		for (int i = 0;i < numofdep;i++) {
			if (array1[i].getdepname() == name) {
				flag = true;
			}
			if (flag == true) {
				array1[i] = array1[i + 1];
			}
		}
		return true;
	}
	bool updateDepartment(int id, string name) {
		for (int i = 0;i < numofdep;i++) {
			if (array1[i].getdepid() == id) {
				array1[i].setdepname(name);
			}
		}
		return true;
	}
	void Display() {
		cout << "UNI Name : " << uniname << endl;
		cout << "Number of Departments" << numofdep << endl;
		for (int i = 0;i < numofdep;i++) {
			cout << endl;
			cout << "Department # " << i << " Name" << array1[i].getdepname() << endl;
			cout << "Department # " << i << " id" << array1[i].getdepid() << endl;
			cout << endl;
		}
	}
};
int main() {
	Professor a("Hassan", 1, "Teacher");
	Professor b("abbas", 2, "Head");
	Professor* array;
	array = new Professor[2];
	array[0] = a;
	array[1] = b;
	Department c("Computer", 100, 2, array);
	c.Display();
	Professor* array2;
	array2 = new Professor[2];
	array2[1] = a;
	array2[0] = b;
	Department d("Science", 101, 2, array2);
	d.Display();
	
}
