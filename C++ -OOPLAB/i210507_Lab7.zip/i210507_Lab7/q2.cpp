#include<iostream>
using namespace std;
class Diablo {
public:
	char* color;
	int cubic;
	int seats;
	int year;
	int engine;
	int frame;
	string owner;

	Diablo(char* color1, int cubic1, int seats1, int year1, int engine1, int frame1, string owner1) {
		color = new char[15];
		color = color1;
		cubic = cubic1;
		seats = seats1;
		year = year1;
		engine = engine1;
		frame = frame1;
		owner = owner1;
	}
	Diablo(Diablo& d) {
		color = new char[15];
		color = d.color;
		cubic = d.cubic;
		seats = d.seats;
	}
};
int main() {
	char color[] = "Hotred";
	Diablo d1(color, 3, 2, 1995, 2222, 2333, "Hassan");
	Diablo d2(d1);
	d2.year = 1996;
	d2.engine = 2223;
	d2.frame = 2334;
	d2.owner = "Abbas";
	cout << "------1st------" << endl;
	cout << d1.color << endl;
	cout << d1.cubic << endl;
	cout << d1.seats << endl;
	cout << d1.year << endl;
	cout << d1.engine << endl;
	cout << d1.frame << endl;
	cout << d1.owner << endl;
	cout << "------2nd------" << endl;
	cout << d2.color << endl;
	cout << d2.cubic << endl;
	cout << d2.seats << endl;
	cout << d2.year << endl;
	cout << d2.engine << endl;
	cout << d2.frame << endl;
	cout << d2.owner << endl;
	return 0;
}