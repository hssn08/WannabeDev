#pragma once
#include<iostream>
using namespace std;
class Product {
	string name;
	int price;
	int quantity;
public: 
	static int totalProducts;
	void getData();
	static void counter();
	static int countProduct();
	Product() {
		countProduct();
	}
	Product(string name,int price,int quantity) {
		countProduct();
	}
};
int Product::totalProducts = 0;
void  Product::getData() {
	
}
void Product::counter() {
	totalProducts += 1;
}
int Product::countProduct() {
	counter();
	return totalProducts;
}
