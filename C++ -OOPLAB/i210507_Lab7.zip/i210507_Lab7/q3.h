#pragma once

#include <iostream>
using namespace std;
class Fraction
{
    int numer;
    int denom;

    int gcd(int n, int m) {
        if (m == 0)
        {
            return n;
        }
        return gcd(m, n % m);
    }
    void normalize() {
        if (denom == 0) {
            numer = 0;
            denom = 1;
        }
        if (denom < 0) {
            numer = -(numer);
            denom = -(denom);
        }

        int divisor = gcd(numer, denom);
        numer = numer / divisor;
        denom = denom / divisor;
    }

public:
    Fraction(int num, int den) {
        numer = num;
        denom = den;
        normalize();
    }
    Fraction() {
        numer = 0;
        denom = 1;
    }
    Fraction(const Fraction& fract) {
        numer = fract.getNumer();
        denom = fract.getDenom();
    }
    ~Fraction() {
    }

    int getNumer() const {
        return numer;
    }
    int getDenom() const
    {
        return denom;
    }

    void setNumer(int num)
    {
        numer = num;
        normalize();
    }
    void setDenom(int num)
    {
        denom = num;
        normalize();
    }
    void print() const
    {
       cout << numer << " / " << denom;
    }

};