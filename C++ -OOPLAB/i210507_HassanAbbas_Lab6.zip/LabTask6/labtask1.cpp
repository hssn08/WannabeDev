#include<iostream>
using namespace std;
class VISION {
private:
	float price = 65;
	float cost;
	float area;
	float length;
	float width;
public:
	VISION(int length1, int width1) {
		length = (float)length1;
		width =  (float)width1;
		calcArea(length, width);
	}
	VISION(float length1, float width1) {
		length = length1;
		width = width1;
		calcArea(length, width);
	}
	VISION(float length2) {
		length = length2;
		width = 4;
		calcArea(length, width);
	}
	void calcArea(float length, float width) {
		area = length * width;
		calcPrice(area);
	}
	void calcPrice(int n) {
	    cost = n * price;
		display();
	}
	void display() {
		cout << "The length of tv is: " << length << endl;
		cout << "The width of tv is: " << width << endl;
		cout << "The area of tv is: " << area << endl;
		cout << "The price of tv is: " << cost << endl;
		cout << endl << endl;
	}
};
int main() {
	VISION obj(3,2);
	VISION obj1(3);
	VISION obj2(3.2f, 3.3f);
}