#include<iostream>
using namespace std;
class complex
{
private:
	double real, img;
public:
	complex() {

	}
	complex(double r,double i)
	{
		setReal(r);
		setImaginary(i);
	}
	void setReal(double r) {
		real = r;
	}
	void setImaginary(double i) {
		img = i;
	}
	double getReal() {
		return real;
	}
	double getImaginary() {
		return img;
	}
	complex addComplex(double r)
	{
		complex ans;
		ans.real = real + r;
		ans.img = img;
		return ans;
	}
	complex addComplex(complex& obj)
	{
		complex ans;
		ans.real = real + obj.real;
		ans.img = img + obj.img;
		return ans;
	}
	complex subComplex(double r)
	{
		complex ans;
		ans.real = real - r;
		ans.img = img;
		return ans;
	}
	complex subComplex(complex& obj)
	{
		complex ans;
		ans.real = real - obj.real;
		ans.img = img - obj.img;
		return ans;
	}
	complex mulComplex(double r)
	{
		complex ans;
		ans.real = real * r;
		ans.img = img;
		return ans;
	}
	complex mulComplex(complex& obj)
	{
		complex ans;
		ans.real = real * obj.real;
		ans.img = img * obj.img;
		return ans;

	}

	void display()
	{
		if (img > 0) {
				cout << real << "+" << img << "i" << endl;
			}
	if (img < 0) {
			cout << real << img << "i" << endl;
		}
	}

};
int main()
{
	double x = 9;
	complex c1(3, 4), c2(2, 6);
    complex sum=c1.subComplex(c2);
	sum.display();
}