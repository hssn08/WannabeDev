#include<iostream>
using namespace std;
class Distance {
public:
	int feet;
	int inches;
	void operator++() {
		if (inches < 11) {
			inches += 1;
		}
		if (inches == 11) {
			inches = 0;
			feet += 1;
		}
	}
	void operator++(int) {
		if (inches < 11) {
			inches += 1;
		}
		if (inches == 11) {
			inches = 0;
			feet += 1;
		}
	}
	void operator--() {
		if (inches > 0) {
			inches -= 1;
		}
		if (inches == 0) {
			feet-= 1;
			inches=11;
		}

	}
	void operator--(int) {
		if (inches > 0) {
			inches -= 1;
		}
		if (inches == 0) {
			feet -= 1;
			inches = 11;
		}

	}
};
int main() {
	Distance m;
	m.inches = 0;
	m.feet = 6;
	--m;
	cout <<m.feet<<" foot "<< m.inches<<" inches" << endl;
}
