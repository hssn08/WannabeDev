#include<iostream>
using namespace std;
class Str {
public:
	string x;
	void operator+=(Str obj) {
		this->x += obj.x;
	}
	string operator+(Str obj) {
		string y;
		y = this->x + obj.x;
		return y;
	}
	bool operator==(const Str& obj) {
		if (this->x == obj.x) {
			return true;
		}
		return false;
	}
	bool operator!=(const Str& obj) {
		if (this->x == obj.x) {
			return false;
		}
		return true;
	}
	bool operator<=(const Str& obj) {
		int len = x.length();
		int len2 = obj.x.length();
		if (len >= len2) {
			return false;
		}
		return true;
	}
	bool operator>=(const Str& obj) {
		int len = x.length();
		int len2 = obj.x.length();
		if (len >= len2) {
			return true;
		}
		return false;
	}
	char operator[](int index) {
		return x[index];
	}
	void operator=(const Str& obj) {
		this->x = obj.x;
	}
};
int main() {
	Str obj1;
	Str obj2;
	obj1.x = "Hassan";
	obj2.x = "Abbas";
	if (obj1 == obj2) {
		cout << obj1.x << " is equal to " << obj2.x << endl;
	}
	else {
		cout << obj1.x << " is not equal to " << obj2.x << endl;
	}
	if (obj1 != obj2) {
		cout << obj1.x << " is not equal to " << obj2.x << endl;
	}
	else {
		cout << obj1.x << " is equal to " << obj2.x << endl;
	}
	if (obj1 <= obj2) {
		cout << obj1.x << " is less than equal to " << obj2.x << endl;
	}
	else {
		cout << obj1.x << " is greater than equal to " << obj2.x << endl;
	}
	if (obj1 >= obj2) {
		cout << obj1.x << " is greater than equal to " << obj2.x << endl;
	}
	else {
		cout << obj1.x << " is less than equal to " << obj2.x << endl;
	}
	cout << "This should be 'a': " << obj1.x[1] << endl;
	obj1.x[3] = 'a';
	cout << "Now it should type Hasaan: " << obj1.x<<endl;
	cout << "+ operator output: " << obj1 + obj2 << endl;
	obj1 += obj2;
	cout << "+= operator output: " << obj1.x << endl;
	obj1.x = obj2.x;
	cout << "Assignment operator output: " << obj1.x << endl;
}