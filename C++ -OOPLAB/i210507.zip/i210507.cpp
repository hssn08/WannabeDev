#include<iostream>
#include<ctime>
#include<cstdlib>
using namespace std;
class Pixel {
	int* pixel;
	int size=0;
public:
	Pixel() {

	}
	Pixel(int choice) {
		if (choice == 1) {
			size = 9;
			pixel = new int[size];
			srand((unsigned)time(0));
			for (int i = 0; i < size; i++) {
				pixel[i] = rand()%255;
			}
		}
		else if (choice == 2) {
			size = 4096;
			pixel = new int[size];
			srand((unsigned)time(0));
			for (int i = 0; i < size; i++) {
				pixel[i] = rand() % 255;
			}
		}
		else if (choice == 3) {
			size = 65025;
			pixel = new int[size];
			srand((unsigned)time(0));
			for (int i = 0; i < size; i++) {
				pixel[i] = rand() % 255;
			}
		}
	}
	void display() {
		for (int i = 0; i < size; i++) {
			cout << pixel[i] << " ";
		}
	}
	int getsize() {
		return size;
	}
	int getindex(int index) {
		if (index == 0) {
			return pixel[0];
		}
		else
		return pixel[index];
	}
	~Pixel() {
	
	}
};
class Matrix {
	int choice=0;
	int** array;
	int row, col;
	
public:
	Pixel h;
	Matrix() {

	}
	Matrix(int choice) {
		if (choice == 1) {
			int k=0;
			row = 3;
			col = 3;
			Pixel x(choice);
			h = x;
			array = new int* [row];
			for (int i = 0; i < row; ++i)
				array[i] = new int[col];
			
			for (int i = 0; i < row; i++) {
				for (int j = 0; j < col; j++) {
						array[i][j] = h.getindex(k);
						k++;
					}
				}
		}
		else if (choice == 2) {
			row = 64;
			int k = 0;
			col = 64;
			Pixel x(choice);
			h = x;
			array = new int* [row];
			for (int i = 0; i < row; ++i)
				array[i] = new int[col];
			for (int i = 0; i < row; i++) {
				for (int j = 0; j < col; j++) {
						array[i][j] = h.getindex(k);
						k++;
				}
			}
		}
		else if (choice == 3) {
			row = 255;
			col = 255;
			int k = 0;
			Pixel x(choice);
			h = x;
			array = new int* [row];
			for (int i = 0; i < row; ++i)
				array[i] = new int[col];
			for (int i = 0; i < row; i++) {
				for (int j = 0; j < col; j++) {
					
						array[i][j] = h.getindex(k);
						k++;
				}
			}
		}
	}
	void display() {
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				cout << array[i][j];
			}
			cout << endl;
		}
	}
	Pixel getpixel() {
		return h;
	}
	~Matrix() {

	}
};
class Image {
	Matrix h;
public:

	Image() {
		int choice;
		srand((unsigned)time(0));
		choice = rand() % 3 + 1;
		Matrix i(choice);
		h = i;
	}
	float normalization(int index) {
		int min = 50;
		int max = 255;
		int size;
		size = h.h.getsize();
		int xmax;
		int xmin;
		int* arr = new int[size];
		for (int i = 0; i < size; i++) {
			arr[i] = h.h.getindex(i);
		}
		xmax = arr[0];
		for (int i = 0; i < size; i++)
		{
			if (xmax < arr[i])
				xmax = arr[i];
		}
		xmin = arr[0];
		for (int i = 0; i < size; i++)
		{
			if (xmin > arr[i])
				xmin = arr[i];
		}
		float xstd = 0;
		float xscaled = 0;
		float* array = new float[size];
		for (int i = 0; i < size; i++) {
			xstd = static_cast<float>(arr[i] - xmin) / static_cast<float>(xmax - xmin); array[0] = 0.12;
			xscaled = xstd * static_cast<float>(max - min) + (float)min;
			array[i] = xscaled;

		}
		return array[index];
	}
	void meanstd() {
		int size = h.h.getsize();
		float sum = 0;
		for (int i = 0; i < size; i++) {
			sum += normalization(i);
		}
		float mean = sum / float(size);
		cout << "MEAN is: " << mean << endl;
		float stdev = 0;
		float sigma = 0;
		for (int i = 0; i < size; i++) {
			sigma += normalization(i) - mean;
		}
		stdev = sqrt(sigma / float(size));
		cout << "The standard deviation is: " << stdev << endl;

	}

};
int main() {
	Image array[20];
	for (int i = 0; i < 20; i++) {
		Image x;
		array[i] = x;
	}
	array[1].meanstd();
}