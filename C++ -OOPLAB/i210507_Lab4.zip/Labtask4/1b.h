#include<iostream>
using namespace std;
void printpattern(int);
void printpatterncol(int);
int main() {
	int x;
	cin >> x;
	printpatterncol(x);
	
}
void printpattern(int x) {
	if (x > 0) {
		cout << "*";
		printpattern(x - 1);
	}
}
void printpatterncol(int x) {
	if(x>0){
	printpattern(x);
	cout << endl;
	printpatterncol(x - 1);
	if(x==1){
		printpattern(5);
		cout<<endl;
	}
		printpattern(x);
		cout<<endl;
}

}
