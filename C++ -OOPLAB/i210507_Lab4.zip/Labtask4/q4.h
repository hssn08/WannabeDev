#pragma once
#include<iostream>
using namespace std;
int getCharCount(const char* ptr, char c)
{
	if(*(ptr)=='\0')
	{
		return 0;
	}
	else
	{
		if(*(ptr)==c)
		{
			return 1 + getCharCount(ptr + 1, c);
		}
		else{
			return getCharCount(ptr + 1, c);
		}
	}
}
