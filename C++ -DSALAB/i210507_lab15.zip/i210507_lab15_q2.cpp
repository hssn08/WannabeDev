#include <iostream>
#include "queue"
using namespace std;


template <class T>
class QueueNode
{
public:
	T data;
	QueueNode<T>* next;

};

template <class T>
class Queue {

public:

	QueueNode<T>* front;
	QueueNode<T>* rear;


	Queue() {
		front = NULL;
		rear = NULL;
	}




	bool isempty() {
		return front == NULL;
	}

	void enqueue(T d)
	{

		QueueNode<T>* n = new QueueNode<T>;
		n->data = d;
		n->next = NULL;
		if (isempty()) {
			front = n;
			rear = n;
		}

		else {
			rear->next = n;
			rear = n;
		}

	}




	T dequeue() {
		T temp = front->data;

		if (front != NULL) {
			front = front->next;
		}
		return temp;
	}



};



template <class T>
class nodee {
public:
	int data;
	nodee* next;
};

template <class T>
class AdjList {

public:

	nodee<T>* head = NULL;


	void insert(T d)
	{
		int currindex = 1;
		nodee<T>* currnode = new nodee<T>();
		nodee<T>* newnode = new nodee<T>();
		nodee<T>* prenode = new nodee<T>();
		newnode->data = d;
		currnode = head;
		if (head == NULL)
		{
			head = newnode;
			head->next = NULL;
		}
		else
		{
			while (currnode)
			{
				prenode = currnode;
				currnode = currnode->next;
				currindex++;
			}

			if (currnode == NULL)
			{
				prenode->next = newnode;
				currnode = newnode;
				currnode->next = NULL;
			}
		}
	}


	void insertAtHead(T d)
	{
		nodee<T>* newnode = new nodee<T>();
		newnode->data = d;
		newnode->next = head;
		head = newnode;


	}

	int InsertAtIndex(T d, int i)
	{

		int currindex = 1;
		nodee<T>* currnode = new nodee<T>();
		nodee<T>* newnode = new nodee<T>();
		newnode->data = d;
		currnode = head;

		while (currnode && i > currindex)
		{
			currnode = currnode->next;
			currindex++;
		}
		if (currnode == NULL && i > currindex)
		{
			return 0;
		}
		if (i == 1)
		{
			newnode->next = head;
			head = newnode;
			return 1;
		}
		else
		{
			newnode->next = currnode->next;
			currnode->next = newnode;
			return 1;

		}
	}
	int search(T d)
	{
		int currindex = 0;
		nodee<T>* currnode = new nodee<T>();
		currnode = head;

		while (currnode)
		{
			if (currnode->data == d)
			{
				break;
			}
			currnode = currnode->next;
			currindex++;

		}
		if (currnode == NULL)
		{
			return -1;
		}
		else
		{
			return currindex;
		}
	}
	int update(int i, T d)
	{
		int currindex = 0;
		nodee<T>* currnode = new nodee<T>();
		currnode = head;

		while (currnode)
		{
			if (currindex == i)
			{
				currnode->data = d;
				break;
			}
			currnode = currnode->next;
			currindex++;

		}
		if (currnode == NULL)
		{
			return -1;
		}
		else
		{
			return 1;
		}


	}

	void remove(T d)
	{
		int currindex = 0;
		nodee<T>* currnode = new nodee<T>();
		nodee<T>* prenode = new nodee<T>();
		currnode = head;

		while (currnode) {

			if (currnode->data == d)
			{
				nodee<T>* Temp = currnode;
				prenode->next = currnode->next;
				delete Temp;
				break;
			}
			prenode = currnode;
			currnode = currnode->next;
			currindex++;

		}

		if (currnode == NULL) {
			return;
		}


	}

	void print()
	{
		nodee<T>* currnode = new nodee<T>();
		currnode = head;
		int currindex = 1;
		while (currnode)
		{
			cout << currnode->data << "->";
			currnode = currnode->next;
			currindex++;
		}
		cout << -1 << endl;
	}


};

template <class T>
class graph {
	int max;
	int num;
public:
	AdjList<T>* list = NULL;

	graph(int total, T val) {
		list = new AdjList<int>[total];
		max = total;
		num = 0;
	}

	void addEdge(T src, T j) {
		list[src - 1].insert(j);
	}

	void addvertex(T val) {
		if (num == max)
			return;
		list[num].insertAtHead(num + 1);
		num++;
	}

	void showGraph() {
		cout << "SHOW GRAPH\n";
		for (int i = 0; i < num; i++) {
			list[i].print();
		}
	}

	void bsf(int ver) {

		Queue<AdjList<T>> q;
		int* check = new int[num];
		int ind = 0;
		q.enqueue(list[ver - 1]);

		cout << "BSF For " << ver << " Vertix\n";

		while (!q.isempty()) {

			AdjList<T> curr = q.dequeue();
			nodee<T>* curr_node;

			bool flag1 = true;
			for (int i = 0; i < ind; i++) {
				if (curr.head->data == check[i])
					flag1 = false;
			}

			if (flag1) {
				cout << curr.head->data << "->";
				check[ind] = curr.head->data;
				ind++;
			}

			else
				continue;

			curr_node = curr.head->next;

			while (curr_node) {

				bool flag = true;

				for (int i = 0; i < ind; i++) {
					if (curr_node->data == check[i])
						flag = false;
				}

				if (flag) {
					q.enqueue(list[curr_node->data - 1]);
				}

				curr_node = curr_node->next;
			}

		}

		cout << "-1\n";
		return;

	}

};