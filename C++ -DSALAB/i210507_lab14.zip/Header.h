#pragma once
#include<iostream>
#include<conio.h>

using namespace std;


template <class T>
class node {
public:
	T val;
	node* next;
};
template <class T>
class stack {
public:
	node<T>* top;
	int size;

	stack() {
		size = 0;
		top = NULL;
	}

	bool isEmpty() {
		return (top == NULL);
	}

	bool push(T data) {
		if (isEmpty()) {
			top = new node<T>;
			top->val = data;
			top->next = NULL;
			size++;
			return 1;
		}

		node<T>* new_node = new node <T>;
		new_node->val = data;
		new_node->next = top;
		top = new_node;
		size++;
		return 1;
	}

	node<T>* Peek() {
		if (isEmpty()) {
			return NULL;
		}

		return top;
	}

	node<T>* pop() {
		if (isEmpty())
			return NULL;
		node<T>* prev_top = top;
		top = top->next;
		T value = prev_top->val;
		size--;
		return prev_top;
	}

	int sizeofstack() {
		return size;
	}

	void print() {
		node<T>* ptr = top;
		while (ptr) {
			cout << ptr->val << " ";
			ptr = ptr->next;
		}
	}
};

template <class T>
class Node
{
public:
	T data;
	Node<T>* left;
	Node<T>* right;
	int height;

	Node()
	{
		left = NULL;
		right = NULL;
		height = 0;
	}

};

template <class T>
class Node2
{
public:
	Node<T>* data;
	Node2<T>* next;

	Node2()
	{
		data = 0;
		next = NULL;


	}
};

template <class T>
class Queue {

public:

	Node2<T>* front;
	Node2<T>* rear;


	Queue() {
		front = NULL;
		rear = NULL;
	}




	bool isempty()
	{
		bool ch = false;
		if (front == NULL || rear == NULL)
		{
			ch = true;
		}
		else {
			ch = false;
		}

		return ch;
	}

	void enqueue(Node<T>* d)
	{

		Node2<T>* n = new Node2<T>;
		n->data = d;
		n->next = NULL;
		if (isempty())
		{
			front = n;
			rear = n;

		}
		else
		{
			rear->next = n;
			rear = n;

		}
	}




	Node<T>* dequeue()
	{

		Node<T>* temp = front->data;


		if (front != NULL)
		{
			front = front->next;
		}
		return temp;

	}



};



template <class T>
class BSTree {

public:

	Node<T>* root;


	BSTree()
	{
		root = NULL;

	}

	int height(Node<T> *curr) {
		if (curr == NULL)
			return -1;
		else
			return curr->height;
	}

	int Max(int lval, int rval) {
		if (lval > rval)
			return lval;
		else
			return rval;
	}

	Node<T>* RRRotation(Node<T>* &old_root) {  //Right Rotation
		Node<T>* new_root = old_root->left;
		old_root->left = new_root->right;
		new_root->right = old_root;
		old_root->height = Max(height(old_root->left), height(old_root->right)) + 1;
		new_root->height = Max(height(new_root->left), height(new_root->right)) + 1;
		return new_root;
		
	}

	Node<T> *LLRotation(Node<T>*& old_root) {  //Left Rotation
		Node<T>* new_root = old_root->right;
		old_root->right = new_root->left;
		new_root->left = old_root;
		old_root->height = Max(height(old_root->left), height(old_root->right)) + 1;
		new_root->height = Max(height(new_root->left), height(new_root->right)) + 1;
		return new_root;
	}

	Node<T>* RLRotation(Node<T>*& curr) {
		curr->left = LLRotation(curr->left);
		curr = RRRotation(curr);
		return curr;
	}

	Node<T>* LRRotation(Node<T>*& curr) {
		curr->right = RRRotation(curr->right);
		curr = LLRotation(curr);
		return curr;
	}

	Node<T>* insert(T val, Node<T>* &curr) {
		if (curr == NULL) {
			curr = new Node<T>;
			curr->data = val;
			curr->height = 0;
			return curr;
		}

		else if (val < curr->data) {
			insert(val, curr->left);
			if (height(curr->left) -height(curr->right) == 2) {
				if (val < curr->data)
					curr = RRRotation(curr);
				else
					curr = RLRotation(curr);
			}
		}
		else if (val > curr->data) {
			insert(val, curr->right);
			if (height(curr->right) - height(curr->left) == 2) {
				if (val > curr->data)
					curr = LLRotation(curr);
				else
					curr = LRRotation(curr);
			}
		}
		curr->height = Max(height(curr->right), height(curr->left)) + 1;
		return curr;
	}
	
	bool retrieve(T d)
	{
		Node<T>* temp = root;

		while (temp != NULL)
		{
			if (temp->data == d)
			{
				return true;
			}

			else if (d < temp->data)
			{
				temp = temp->left;
			}
			else
			{
				temp = temp->right;
			}

		}
		return false;
	}

	T getmin(Node<int>* n)
	{

		if (n != NULL)
		{

			getmin(n->left);
			if (n->left == NULL)
			{
				return n->data;
			}
			else
			{
				return getmin(n->left);
			}
		}
	}

	void Make_Deletion(Node<int>*& ptr) {
		
		Node<T>* temp;
		if (ptr->right == NULL)
		{
			temp = ptr;
			ptr = ptr->left;
			delete temp;
		}
		else if (ptr->left == NULL)
		{
			temp = ptr;
			ptr = ptr->right;
			delete temp;
		}
		else
		{
			temp = ptr->right;
			while (temp->left)
			{
				temp = temp->left;
			}

			temp->left = ptr->left;
			temp = ptr;
			ptr = ptr->right;
			delete temp;
		
		}
		
		ptr->height = Max(height(ptr->right), height(ptr->left)) + 1;
		return ptr;
	}
	
	Node<T>* Delete(int val, Node<int>*& curr) {
		if (curr == NULL) {
			return;
		}

		else if (val < curr->data) {
			Delete(val, curr->left);
			if (height(curr->left) - height(curr->right) == -2) {
				if (val < curr->data)
					curr = RRRotation(curr);
				else
					curr = RLRotation(curr);
			}
		}

		else if (val > curr->data) {
			Delete(val, curr->right);
			if (height(curr->left) - height(curr->right) == -2) {
				if (val < curr->data)
					curr = RRRotation(curr);
				else
					curr = RLRotation(curr);
			}
		}
		else {
			Make_Deletion(curr);
			if (height(curr->left) - height(curr->right) == 2) {
				if (val < curr->data)
					curr = RRRotation(curr);
				else
					curr = RLRotation(curr);
			}
		}
		curr->height = Max(height(curr->right), height(curr->left)) + 1;
		return curr;
	}


	bool isempty()
	{
		bool ch = false;
		if (root == NULL)
		{
			ch = true;
		}
		else {
			ch = false;
		}

		return ch;
	}



	void LevelOrder(Node<T>* n)
	{
		Queue<T> obj;
		obj.enqueue(n);

		while (!obj.isempty())
		{
			Node<T>* tem = obj.dequeue();
			if (tem->left != NULL)
			{
				obj.enqueue(tem->left);
			}
			if (tem->right != NULL)
			{
				obj.enqueue(tem->right);
			}

			cout << tem->data << endl;

		}

	}

	void InOrderTraversal(Node<T>* n)
	{

		if (n != NULL) { 
			InOrderTraversal(n->left);
			cout << n->data << " ";
			InOrderTraversal(n->right);
		}
	}

	void Mirror(Node<T>*& curr) {
		if (curr->left == NULL && curr->right == NULL)
			return;
		else {
			if (curr->left != NULL)
				Mirror(curr->left);
			if (curr->right != NULL)
				Mirror(curr->right);

			Node<T>* temp = curr->left;
			curr->left = curr->right;
			curr->right = temp;
		}
		return;
	}

	bool insertExp(T val, Node<T>*& curr_node) {
		
		if (curr_node == NULL) {
			curr_node = new Node<T>;
			curr_node->data=val;
			return true;
		}

		if (curr_node->data >= 'A' && curr_node->data <= 'Z' || curr_node->data >= 'a' && curr_node->data <= 'z')
			return false;

		else {
			bool flag = insertExp(val,curr_node->left);
			if (flag)
				return flag;
			else
				return insertExp(val, curr_node->right);
		}


	}
};

