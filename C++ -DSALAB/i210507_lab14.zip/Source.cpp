#include<iostream>
#include"header.h"
using namespace std;

int main() {
	BSTree<int> obj;
	obj.root = obj.insert(20, obj.root);
	obj.root = obj.insert(7, obj.root);
	obj.root = obj.insert(2, obj.root);
	obj.root = obj.insert(30, obj.root);
	obj.root = obj.insert(15, obj.root);
	obj.root = obj.insert(25, obj.root);

	obj.LevelOrder(obj.root);
}