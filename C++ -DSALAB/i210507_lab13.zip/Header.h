#include <iostream>
#include"../lab_13/stack.h"
#include<queue>

using namespace std;

bool is_operator(char ch)
{
	if (ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '^' || ch == '$')
	{
		return true;
	}
	return false;
}

void output(Node<char>* temp_node)
{
	if (temp_node != NULL)
	{
		output(temp_node->Left);

		cout << temp_node->data << " ";
		
		output(temp_node->Right);
	}
	else
	{
		return;
	}

}

void convertion_to_binary(string s)
{
	stack s1;

	Node<char>* fl = new Node<char>;
	Node<char>* newnode;
	Node<char>* oprend1;
	Node<char>* oprend2;

	for (int i = 0; s[i] != '\0'; i++)
	{
		if ((s[i] == '+' || s[i] == '-' || s[i] == '*' || s[i] == '/' || s[i] == '^' || s[i] == '$'))
		{
			newnode = new Node<char>(s[i]);

			oprend2 = s1.pop();

			oprend1 = s1.pop();

			newnode->Left = oprend1;

			newnode->Right = oprend2;

			s1.push(newnode);
		}
		else
		{

			newnode = new Node<char>(s[i]);

			s1.push(newnode);

		}
		fl = newnode;


	}
	output(fl);

}









