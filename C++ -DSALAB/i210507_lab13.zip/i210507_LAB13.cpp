#include<iostream>
#include"../lab_13/Header.h"
#include"../lab_13/q1.h"
using namespace std;


int main()
{

		cout << endl<<endl ;


	cout << "Question 2";
		cout << endl<<endl ;


	string exp = "ab*c+";
	cout << "Entered Expression Is : " << exp << endl;

	cout << "Expresion converted through Binay Tree Is : " ;
	convertion_to_binary(exp);
	cout << endl;

	cout << endl<<endl ;
	cout << "Question 1";
		cout << endl<<endl ;

	cout << endl<<endl ;

	Binarytree B;
	B.insert(10);
	B.insert(12);
	B.insert(65);
	B.insert(45);
	B.insert(34);
	B.insert(87);
	B.insert(35);
	B.insert(63);
	B.insert(87);
	B.insert(37);
	B.insert(24);
	B.insert(86);
	B.insert(61);
	B.insert(98);
	B.insert(19);
	
	Reversing(B.root);

	cout << "TREE AFTER SWAPPING IS : ";
	B.InOrderTraversal(B.root);
	cout << endl << endl;

	cout << endl<<endl ;



	return 0;

}
