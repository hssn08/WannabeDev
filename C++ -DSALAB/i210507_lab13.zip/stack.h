#pragma once
#include<iostream>
#include<queue>
using namespace std;



template <typename T>

class Node
{
public:
	T data;

	Node* next;
	Node* Left;
	Node* Right;

	Node()
	{
		data = '\0';
		next = NULL;
		Left = NULL;
		Right = NULL;
	}
	Node(char value)
	{
		data = value;
		next = NULL;
		Left = NULL;
		Right = NULL;
	}
};

class stack
{
public:
	Node<char>* top;

	stack()
	{
		top = NULL;
	}

	bool isEmpty()
	{
		if (top == NULL)
		{
			return true;
		}
		return false;
	}
	void push(Node<char>* n)
	{
		if (isEmpty())
		{
			top = n;
		}
		else
		{
			n->next = top;
			top = n;
		}
	}
	Node<char>* pop()
	{
		Node<char>* new_node;

		if (isEmpty())
		{
			cout << "List is Empty" << endl;
		}
		else
		{
			new_node = top;
			top = top->next;
			return new_node;
			delete new_node;
		}

	}
};