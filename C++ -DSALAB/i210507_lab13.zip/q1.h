#include<iostream>
#include<queue>
using namespace std;

class node1
{
public:
	int val;
	node1* Left_child;
	node1* Right_child;

	node1()
	{
		val = 0;
		Left_child = NULL;
		Right_child = NULL;
	}

	node1(int d, node1* l, node1* r)
	{
		val = d;
		Left_child = l;
		Right_child = r;

	}

	node1(int d)
	{
		val = d;
		Left_child = NULL;
		Right_child = NULL;
	}
};


class Binarytree
{
public:
	node1* root;

	Binarytree()
	{
		root = NULL;
	}

	void insert(int d)
	{
		node1* n = new node1(d);
		if (root == NULL)
		{
			root = n;
		}

		else
		{
			node1* temp = root;

			while (temp != NULL)
			{
				if (d < temp->val)
				{
					if (temp->Left_child == NULL)
					{
						temp->Left_child = n;
						break;
					}
					else
						temp = temp->Left_child;
				}

				if (d > temp->val)
				{
					if (temp->Right_child == NULL)
					{
						temp->Right_child = n;
						break;
					}
					else
						temp = temp->Right_child;
				}

				if (d == temp->val)
				{
					break;
				}

			}
		}
	}
	void InOrderTraversal(node1* n)
	{
		if (n == NULL)
		{
			return;
		}

		InOrderTraversal(n->Left_child);
		cout << n->val << " ";
		InOrderTraversal(n->Right_child);

	}

};

void Reversing(node1* n)
{
	if (n == NULL)
	{
		return;
	}

	queue <node1*> q;
	q.push(n);

	while (!q.empty())
	{
		node1* n = q.front();
		q.pop();

		node1* temp;

		temp = n->Left_child;
		n->Left_child = n->Right_child;
		n->Right_child = temp;

		if (n->Left_child)
		{
			q.push(n->Left_child);
		}
		if (n->Right_child)
		{
			q.push(n->Right_child);
		}
	}
}